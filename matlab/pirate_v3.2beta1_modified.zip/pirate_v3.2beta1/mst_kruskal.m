function[ifglist_mst,connect] = mst_kruskal(ifglist,costidx)
%====================================================================
%function[ifglist_mst,connect] = mst_kruskal(ifglist,costidx)
%--------------------------------------------------------------------
%mst_kruskal: create minimum cost spanning tree using Kruskal method
%
%INPUT
%  ifglist: interferogram list, see getnml.m for its structure
%  costidx: cost index (default: 1 NaN fraction; 2: variance)
%OUTPUT
%  ifglist_mst: interferogam list on the MST. 
%  connect: connectivity matrix
% 
%Hua WANG, 15/06/2009
%
% 09/01/2012 HW: output connectivity matrix
%====================================================================
if nargin==1
  costidx=1;
end

nifgs = length(ifglist.masnum);                      %ifg number
nimages = max(max([ifglist.masnum ifglist.slvnum])); %image number

%cost: index used to select independent ifgs
if costidx==1
  cost = ifglist.nanfrac; %only use unwrap fraction
else
  cost = ifglist.maxvar./(ifglist.BaseT.^2); %use both variance
end

%sort ifglist in terms of ifgstd
id=(1:nifgs)';
sortlist=[id ifglist.masnum ifglist.slvnum cost];
ifgsort = sortrows(sortlist,4);

%initial connceted component
connect = eye(nimages);

mstlist=[];
%loop to find the maximum
for i=1:nifgs
  mas=ifgsort(i,2);
  slv=ifgsort(i,3);
  
  %locate master/slave image
  locmas = find(connect(:,mas)==1);
  locslv = find(connect(:,slv)==1);

  if locmas~=locslv
    mstlist=[mstlist;ifgsort(i,:)];
    connect(locmas,:)=connect(locmas,:)+connect(locslv,:); %add slave to MST
    connect(locslv,:)=[];                                  %remove slave from independent component list
  end
end

mstlist = sortrows(mstlist,1);

%get mst from ifglist
ifglist_mst=getsubstruct(ifglist,mstlist(:,1));

%count isolated trees
if nargout>1
  cnt=sum(connect');
  %remove missing images
  connect(cnt==1,:)=[];
  ntrees = size(connect,1);
  fprintf('%d trees generated using MST algorithm\n',ntrees);
end




