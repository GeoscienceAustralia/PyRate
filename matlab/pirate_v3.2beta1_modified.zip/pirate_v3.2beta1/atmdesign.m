function [B]=atmdesign(ifglist,dem,refpt,atmfitpar)
%==================================================================== 
%function [B]=atmdesign(ifglist,dem,refpt,atmfitpar)
%                                                                     
% Make design matrix for atm correction, both ifg-by-ifg     
%   and epoch-by-epoch methods are supported     
%                                                                     
% INPUT:                                                              
%   ifglist:     master/slave image list for each interferogram       
%   dem:         dem data                                             
%   refpt:       coordinate of the reference point                    
%   atmfitpar:   atm fit parameters
%                                                                     
% OUTPUT:                                                             
%   B:           design matrix (H, 1)                                 
%                                                                     
% Hua Wang @ Uni Leeds, 02/02/2008, following Juliet Biggs, 2006          
%
% 22/08/2011 HW: add back reference phase estimation
% 05/08/2011 HW: change input as structure
% 13/09/2009 HW: change reference phase estimation as an optional parameter
%==================================================================== 

nifgs=length(ifglist.masnum);
[rows,cols]=size(dem);
nepoch = max(max([ifglist.masnum ifglist.slvnum]));
n = rows*cols;

%total parameters number
if atmfitpar.method==2
  ncoef = nepoch; %epoch-by-epoch method
else
  ncoef = nifgs;  %ifg-by-ifg method
end

%total parameters number
npar=ncoef+nifgs;

dem = (dem-dem(refpt.y,refpt.x))/1000.0;  %using km as unit, test 30/09/2009
demv = reshape(dem',n,1);

B = zeros(n*nifgs,npar);
for i=1:nifgs
  %master/slave image epoch, using it to determine the cofficient position
  im = ifglist.masnum(i);
  is = ifglist.slvnum(i);
  %start/end line number for each interferogram in the coefficient matrix
  ib1 = (i-1)*n+1;
  ib2 = i*n;

  %coefficient for the linear atm correction
  if atmfitpar.method==2
    B(ib1:ib2,im)=-demv;
    B(ib1:ib2,is)=demv;
  else
    B(ib1:ib2,i)=demv;
  end

  %coefficients for the offsets
  joff = ncoef+i;
  B(ib1:ib2,joff)=ones(n,1);
end
