% creates a list of the epoch span for GMT Tools plotting purposes

span=epochlist.span;
out =[span];
file=char(strcat('epoch_span.dat'));
dlmwrite(file,out,' ');
