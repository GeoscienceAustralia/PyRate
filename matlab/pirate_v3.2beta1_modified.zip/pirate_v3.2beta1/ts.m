function [tsincr,tserr,tscum, tsvel]=ts(ifg,ifglist,epochlist,vcm,tspar,mstmat,cbasep,tsdir,stepincr)
%====================================================================
%function [tsincr,tserr,tscum]=ts(ifg,ifglist,epochlist,vcm,tspar,mstmat,cbasep,tsdir,stepincr)
%                                                                    
% The main function for insar time series inversion
%
% INPUT:
%   ifg:       interferograms
%   ifglist:   interferogram list
%   epochlist: epochlist
%   vcm:       temporal covariance matrix for each pixel
%   tspar:     parameters for time series inversion (pthr/smf/smorder used here)
%   mstmat:    mst matrix to identify independent ifgs (optional)
%   cbasep:    coefficients of perpendicular baseline (optional)
%   stepincr:  step flag for each incremental (optional, 0: no step; 1: step)
%
% OUTPUT:
%   tsincr: deformation time series on each incremental
%   tserr:  deformation time series uncertainty
%   tscum:  deformation time series accumunation
%
% Hua Wang @ Uni Leeds, 25/09/2008
%
%====================================================================
if nargin<5
  error('at least 5 input arguments needed')
end
if nargin<6
  mstmat=~isnan(ifg);
end
if nargin<7
  cbasep=[];
end
if nargin<8
  tsdir=[];
end
if nargin<9
  stepincr=[];
end
fprintf('tspar.method: %d\n\n', tspar.method)
switch (tspar.method)
  case 1
    % time series analysis using Laplacian smoothing method
    if tspar.smf==0
      disp('inside tspar method 1')
      [tspar.smf,lcv]=lcurve(ifg,ifglist,epochlist,vcm,tspar,1,mstmat,cbasep,tsdir,stepincr);
    end
    disp('inside tspar method 1 - lcurve or not ')
    
    [ifg_wrss,ts_rough,tsincr,tserr,tscum, tsvel]=tsinvlap(ifg,ifglist,epochlist,vcm,tspar,mstmat,cbasep,stepincr);

  case 2
    %to be updated to tsinvsvd
    % time series analysis using SVD method (not fully tested yet??)
    [tsincr,tscum]=tsinvnosm(ifg,ifglist,epochlist,tspar.pthr,mstmat);
    tserr=[]; %do not return tserr
    tsvel=[]; % dummy

  case 3
    % time series analysis using Laplacian smoothing method
    if tspar.smf==0
      [tspar.smf,lcv]=lcurve(ifg,ifglist,epochlist,vcm,tspar,1,mstmat,cbasep,tsdir,stepincr);
    end
    [ifg_wrss,ts_rough,tsincr,tserr,tscum]=tsinvbsp(ifg,ifglist,epochlist,vcm,tspar,mstmat,cbasep,stepincr);

  otherwise
    error('No such time series method defined!')
end

dummy=0
