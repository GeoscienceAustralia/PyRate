function [corrmat]= corr2d(im1,im2,wx,wy,ws)
%==============================================
%function [corrmat]= corr2d(im1,im2,wx,wy,ws)
%
% Calculate normalized cross-correlation between two images
%
% Input:
%   im1/2: image 1 and 2 in the same dimension
%   wx/y: window size for correlation
%   ws: step size for correlation (default 1)
%
% Output:
%   corrmat: correlation matrix
%
% Hua Wang, 06/08/2011
%==============================================
[nrows,ncols]=size(im1);
if (size(im2,1)~=nrows | size(im2,2)~=ncols)
  error('different size for the two images');
end

if nargin<5
  ws=1;
end

%get odd window size
dx=floor(wx/2);
dy=floor(wy/2);
wx=dx*2+1;
wy=dy*2+1;

%threshold of valid pixels is set as half of the totle number in the window
psize=wx*wy;
thr = floor(psize/3);
corrmat=NaN(nrows,ncols,'single');

for r=dy+1:ws:nrows-dy
  for c=dx+1:ws:ncols-dx
    p1=im1(r-dy:r+dy,c-dx:c+dx);
    p2=im2(r-dy:r+dy,c-dx:c+dx);
    pv1=reshape(p1,psize,1);
    pv2=reshape(p2,psize,1);
    n=find(~isnan(pv1+pv2));
    if (length(n)>=thr)
      corrmat(r,c)=abs(corr(pv1(n),pv2(n)));
    end
  end
end
