function [amp_ave]=calamp(amp,outfile)
%====================================
%function [amp_ave]=calamp(amp,outfile)
%                                                                            
% amplitude images calibration
%                                                                     
% INPUT:                                                              
%   amp:       amplitude images                                      
%   outfile:   output amplitude file
%                                                                     
% OUTPUT:                                                             
%   amp_ave:   averaged amplitude image               
%                                                                     
% Hua Wang, 22/10/2011      
%====================================

nifgs=size(amp,3);

ref=zeros(nifgs,1);

%add constant offset to amp
comp=isnan(sum(amp,3));  %find valid pixels in all ifgs
comp=reshape(comp,[],1);
for i=1:nifgs
  ampv=reshape(amp(:,:,i),[],1);
  ampv(comp==1)=[];
  ref(i)=median(ampv);
  amp(:,:,i)=amp(:,:,i)-ref(i);
end
mean_ref=mean(ref);
amp=amp+mean_ref;

%average amplitude
amp_ave=nanmedian(amp,3);

if nargin>1
  writemat(outfile,amp_ave);
end
