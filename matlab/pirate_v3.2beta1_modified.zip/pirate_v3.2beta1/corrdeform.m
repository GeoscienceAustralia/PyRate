function[deform]=corrdeform(tsincr,ifghdr,stepincr,corrpar)
%===================================================
%function[deform]=corrdeform(tsincr,ifghdr,stepincr,corrpar)
%
% Distinguish deformation from atm by correlation with multiple ifgs
%
% Input:
%   tsincr: time series including incremental displacment and atmosphere
%   ifghdr: ifg header to provide pixel size
%   stepincr: correlation operation for each incr
%   corrpar: correlation parameters, including:
%            fact - n times of the atm wavelenght (default: 1)
%            step - correlation step (default: 3 pixels)
%            slop - slop of the smoothing fuction (like locking depth,default: 20)
%            thr - correlation threshold of smoothing function (default: 0.6)
%
% Output:
%   deform: deformation
%
% Hua Wang, 06/08/2011
%===================================================
if nargin<4
  corrpar.fact=1;
  corrpar.step=3;
  corrpar.slop=20;
  corrpar.thr=0.6;
end
[rows,cols,nintv]=size(tsincr);
nstep=nnz(stepincr);
nincr=length(stepincr);
step=find(stepincr~=0);
deform=zeros(rows,cols,nintv,'single');

%calculate variance of each incremental
[maxvar_incr,alpha_incr] = make_vcm(tsincr,ifghdr.xpsize,ifghdr.ypsize);

for i=1:nstep

  iincr=step(i);

  %------------------
  %synthetic ifgs
  %------------------
  %the first step
  if i==1
    prevstep=1;
  else
    prevstep=step(i-1)+1;
  end
  im_min=max(min(prevstep,iincr-2),1); %extend at least two incrs before, but no smaller than 1

  %the last step
  if i==nstep
    nextstep=nincr;
  else
    nextstep=step(i+1)-1;
  end
  is_max=min(max(nextstep,iincr+2),nincr);%extend at least two incrs after, but no bigger than nincr

  %im_max=iincr;
  im_max=max(iincr-1,im_min);
  is_min=min(iincr+1,is_max);
 
  %form independent ifgs
  nifgs=max(is_max-is_min+1,im_max-im_min+1);
  ifg=NaN(rows,cols,nifgs);
  im=zeros(nifgs,1);
  is=zeros(nifgs,1);
  for j=1:nifgs
    im(j)=min(im_min+j-1,im_max);  %using the last incr if the number of 'im' is less than 'is'
    %is=min(is_min+j-1,is_max); %using the last incr if the number of 'is' is less than 'im'
    is(j)=max(is_max-j+1,is_min);  %using the first incr if the number of 'is' is less than 'im'
    ifg(:,:,j)=sum(tsincr(:,:,im(j):is(j)),3);
  end

  %------------------------------------------------
  fprintf('tsincr %d vs %d ifgs correlation: %d / %d\n',iincr,nifgs,i,nstep);

  %find ifgs covering current step
  %method 1: using the stacked ifgs
  %sel=find((im>=prevstep)&(is<=nextstep));
  %img=(sum(ifg(:,:,sel),3)+tsincr(:,:,iincr))/(length(sel)+1);
  %method 2: using the current incr directly
  img=tsincr(:,:,iincr);
  
  for ic=1:2 %do correlation twice
    %correlation
    corrmat=NaN(rows,cols,nifgs);
    wx=max(round(corrpar.fact/alpha_incr(iincr)/ifghdr.xpsize),10);
    wy=max(round(corrpar.fact/alpha_incr(iincr)/ifghdr.ypsize),10);
    for j=1:nifgs
      fprintf(' - correlation for the ifg %d / %d\n',j,nifgs);
      corrmat(:,:,j)=corr2d(ifg(:,:,j),tsincr(:,:,iincr),wx,wy,corrpar.step);
    end
    %mean correlation
    mcorr=nanmean(corrmat,3);
 
    %delete the pixels which have less than three coherent observations
    ncorr=sum(~isnan(corrmat),3);
    mcorr(ncorr<min(3,nifgs))=nan;
    mcorr=inpaint_nans(mcorr,2);
    mcorr(mcorr>1)=1;
    mcorr(mcorr<0)=0;
    
    %set weight using atan function like interseismic model to suppress noise
    wgt=atan(corrpar.slop*(mcorr-corrpar.thr))/pi+0.5;
    
    %filtering
    idefo=img.*wgt;
    img=img-idefo;
    tsincr(:,:,iincr)=tsincr(:,:,iincr)-idefo;
    deform(:,:,iincr)=deform(:,:,iincr)+idefo;
  end
  tsincr(:,:,iincr)=tsincr(:,:,iincr)+deform(:,:,iincr);
end
