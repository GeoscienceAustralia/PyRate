function [eqcor]=eq_correct(ifglist,epochlist,ifghdr,iopar)
%===========================================================
%function [eqcor]=eq_correct(ifglist,epochlist,ifghdr,iopar)
%
% Function to read LOS instantaneous deformation models (i.e.
% from earthquakes or volcanoes) in real*4 format and
% produce corrections for each interferogram
%
% Matt Garthwaite, 24/08/2012
%
% Revised 25/09/2012 to deal with multiple earthquake models
%===========================================================

[eqlist] = textread(iopar.eqfilelist,'%s');

neq=length(eqlist);

nifg=length(ifglist.id);

% initialise ifm correction matrix
eqcor=zeros(ifghdr.length,ifghdr.width,nifg);

% loop over all earthquake models
for i=1:neq
    % read, crop and multi-look the coseismic model to fit interferograms
    file=char(eqlist(i));
    path=char(strcat(iopar.eqdir,file));
    [eq]=imagecrop(path,ifghdr,1);
    
    % convert eq date to numeric integer date
    eqt=datenum(file(1:8),'yyyymmdd');

    %loop over all ifms
    for j=1:nifg
    % get master and slave times
    mast=datenum(num2str(epochlist.date(ifglist.masnum(j))),'yyyymmdd');
    slvt=datenum(num2str(epochlist.date(ifglist.slvnum(j))),'yyyymmdd');
    
        % if EQ falls between master and slave, add the correction
        if mast <= eqt && slvt >= eqt
             eqcor(:,:,j)=eqcor(:,:,j)+eq;
        end
    end

end
