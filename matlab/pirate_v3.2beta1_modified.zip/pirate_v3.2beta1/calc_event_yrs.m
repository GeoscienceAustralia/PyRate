function [] = calc_event_yrs(infile,epochlist)
%========================================
% function [] = calc_event_yrs(infile)
%   Work out event dates in years for plotting with pixels values in GMT Tools.
%
% Input:
%   infile: input file contains the dates of events (events.dates file)
%           (yyyymmdd)
%
% Sarah Lawrie, 08/05/2013
%========================================

[dates]=textread(infile,'%d');

%convert from yyyymmdd2year
nimages2=length(dates);
span2=zeros(nimages2,1);
for i=1:nimages2
  span2(i)=datenum(num2str(dates(i)),'yyyymmdd');
end
epoch=datenum(num2str(epochlist.date(1)),'yyyymmdd');
event_yrs=(span2-epoch)/365.25; 

dlmwrite('events.list',[dates event_yrs],'delimiter', '\t','precision',8);
