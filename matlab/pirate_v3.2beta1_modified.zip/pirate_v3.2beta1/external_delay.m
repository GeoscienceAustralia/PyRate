function [ifm_delay] = external_delay(ifglist,dir,filelist,ifghdr,wvl)
%===========================================================
%function [ifm_delay] = external_delay(ifglist,dir,filelist,ifghdr,wvl)
%
% Function to read epochal delay maps in real*4 format from 
% external code and produce corrections for each interferogram
%
% Matt Garthwaite, 23/08/2012                        
%===========================================================

[delaylist] = textread(filelist,'%s');

natm=length(delaylist);

nifg=length(ifglist.id);

% read, crop and multilook the delay maps
for i=1:natm
    [in]=imagecrop(char(strcat(dir,delaylist(i))),ifghdr,1);
    ep_delay(:,:,i)=in;
end

% from the epochal delay maps, create interferogram delay maps
for j=1:nifg
    diff=ep_delay(:,:,ifglist.masnum(j))-ep_delay(:,:,ifglist.slvnum(j));
    % convert from radians to mm
    ifm_delay(:,:,j)=diff/(4*pi)*wvl*1000;
end




