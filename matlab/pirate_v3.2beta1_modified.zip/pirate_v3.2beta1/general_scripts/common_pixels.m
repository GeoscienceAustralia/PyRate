function[]=common_pixels(ifg,ifghdr)

% Find common pixel in all ifgs for each track and overlap 
% use ifg_final

% create nan file for each ifg (for each track)
[rows,cols,nifgs]=size(ifg);

for i=1:nifgs
    ifg_temp=ifg(:,:,i);
    temp{i}=~isnan(ifg_temp);
end
ifg_nan=cat(3,temp{1:nifgs});

% add all nan files
sum_ifg=sum(ifg_nan,3);

% look for values that equal max no. ifms
ifg2=sum_ifg;
%ifg2(ifg2 < nifgs) = NaN;

% plot pixels in all ifgs
x=[ifghdr.xfirst,ifghdr.xfirst+(cols-1)*ifghdr.xstep];
y=[ifghdr.yfirst,ifghdr.yfirst+(rows-1)*ifghdr.ystep];

figure
h=imagesc(x,y,ifg2);
set(gca,'YDir','normal');
colormap(jet);
axis equal;
axis image;
set(h,'alphadata',~isnan(ifg2));

% do they fall in overlap and in both ifms?
   % save ifg2 for each track and then run overlap.m
   % find desired pixel and note coordinates

% run below manually on each org ifg to find corresponding pixels:

%lat=-27.27;
%lon=150.7;
%nrows=size(ifg,1);
%x11=ifghdr.xfirst;
%y11=ifghdr.yfirst;
%dx=ifghdr.xstep;
%dy=ifghdr.ystep;
%R=makerefmat(x11, y11, dx, dy);
%[row,col]=latlon2pix(R,lat,lon);
%cols=round(col)
%rows=nrows-round(row)




end