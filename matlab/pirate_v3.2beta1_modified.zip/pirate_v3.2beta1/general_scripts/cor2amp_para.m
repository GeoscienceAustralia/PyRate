function [amp_ave]=cor2amp_para(cfgfile)
%====================================
%function [amp_ave]=cor2amp(cfgfile)
%                                                                            
% amplitude images calibration
%                                                                     
% INPUT:                                                              
%   cfgfile:  configure file                                     
%                                                                     
% OUTPUT:                                                             
%   amp_ave:  averaged amplitude image               
%                                                                     
% Hua Wang, 07/02/2012
%====================================

[parmat] = readparfile(cfgfile);
getpars_pirate(parmat);
load pars
[ifglist] = getnml_para(iopar.ifgfilelist);
nifgs=length(ifglist.nml);

%amplitude filename
parfor i=1:nifgs
  ifgname=char(ifglist.nml(i));
  surfix = max(strfind(ifgname,'.'));
  cornml(i)=cellstr(strcat(ifgname(1:surfix-1),'.cor'));
end

%crop/fill original cor files
prepifg_para(iopar.obsdir,cornml,parmat,3,1,3);
corhdr=rsc2hdr(char(strcat(iopar.obsdir,'ifg.rsc')));

%calibration
ampfile=char(strcat(iopar.auxdir,'amp.dat'));
%[amp_ave]=calamp_para(amp,ampfile);
%read files one by one to save memory
ref=zeros(nifgs,1);
amp_ave=zeros(corhdr.length,corhdr.width,'single');
cnt=zeros(corhdr.length,corhdr.width,'single');
parfor i=1:nifgs
  if mod(i,10)==0
    fprintf('amplitude calibration %d/%-d \n',i,nifgs);
  end
  icorfile=char(strcat(iopar.obsdir,cornml(i)));
  ifgrsc=rsc2hdr(strcat(icorfile,'.rsc'));
  lksx=round(corhdr.xstep/ifgrsc.xstep);
  surfix = max(strfind(icorfile,'.'));
  icorfilefill=char(strcat(icorfile(1:surfix-1),'_',num2str(lksx),'rlks_fill',icorfile(surfix:length(icorfile))));
  icor=readmat(icorfilefill,corhdr.length,corhdr.width,1,'rmg');
  iamp=icor(:,:,1);
  icnt=~isnan(iamp);
  ampv=reshape(iamp,[],1);
  ref(i)=nanmedian(ampv);
  iamp(isnan(iamp))=0;
  cnt=cnt+icnt;
  amp_ave=amp_ave+(iamp-ref(i)).*icnt;
end
mean_ref=mean(ref);
amp_ave=amp_ave./cnt+mean_ref;
writemat(ampfile,amp_ave);

%rsc file
hdr2rsc(corhdr,strcat(ampfile,'.rsc'));

%rm pars
!rm -f pars.mat
