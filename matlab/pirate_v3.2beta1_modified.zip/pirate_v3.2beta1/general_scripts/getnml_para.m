function [ifglist,epochlist] = getnml_para(ifgfilelist,prefix_len,dateformat)
%=============================================================
%function [ifglist,epochlist] = getnml(ifgfilelist,prefix_len)
%                                                             
% Get namelist from input interferogram list file    
%                                                              
% INPUT:                                                       
%   ifgfilelist: input interferogram list                      
%                format: geo_yymmdd_yymmdd_smp.unw             
%                        (4c)(mas)  (slv) (others)             
%   prefix_len: surfix length of the filename (default: 4)
% OUTPUT:                                                      
%   ifglist: interferogram list
%   epochlist: radar image epoch list
%                                                              
% Hua Wang @ Uni Leeds, 20/04/2008                                 
%
% 24/09/2012 HW: adding prefix length
% 26/08/2011 HW: using unique function
% 06/08/2009 HW: using structure for ifglist and epochlist
%============================================================

if nargin<2
  prefix_len=4;
end

%read the interferogram file list
[ifglist.nml] = textread(ifgfilelist,'%s');
nifgs=length(ifglist.nml);
ifglist.id=(1:nifgs)';

%% get master and slave images from the interferogram namelist
mas=zeros(nifgs,1);
slv=zeros(nifgs,1);
if (dateformat==6)
  parfor i=1:nifgs
    strpair=char(ifglist.nml(i));
    strpair(1:prefix_len)=[];
    mas(i) = str2double(strpair(1:6));
    slv(i) = str2double(strpair(8:13));
  end
  mas=mas+19000000;
  slv=slv+19000000;
  %solve for the 2000 problem
  mas(mas<19500000)=mas(mas<19500000)+1000000;
  slv(slv<19500000)=slv(slv<19500000)+1000000;
elseif (dateformat==8)
  parfor i=1:nifgs
    strpair=char(ifglist.nml(i));
    strpair(1:prefix_len)=[];
    mas(i) = str2double(strpair(1:8));
    slv(i) = str2double(strpair(10:17));
  end
end

%get unique sar image date
[epochlist.date,m,n]=unique([mas;slv]);
epochlist.repeat=histc(n,[min(n):1:max(n)]);
n=reshape(n,nifgs,2);
ifglist.masnum=n(:,1);
ifglist.slvnum=n(:,2);

%convert from yyyymmdd2year
nimages=length(epochlist.date);
span=zeros(nimages,1);
parfor i=1:nimages
  span(i)=datenum(num2str(epochlist.date(i)),'yyyymmdd');
end
epochlist.span=(span-span(1))/365.25; 

%temporal baseline
ifglist.BaseT = epochlist.span(ifglist.slvnum) - epochlist.span(ifglist.masnum);

%initialize other variables
ifglist.maxvar=zeros(nifgs,1);
ifglist.alpha=zeros(nifgs,1);
ifglist.nanfrac=zeros(nifgs,1);
