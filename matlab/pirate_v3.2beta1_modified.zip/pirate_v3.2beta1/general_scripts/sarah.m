%%% General helpful scripts

% add ifg dates to images and plot for checking ifgs for unwrapping errors
temp = strcat(num2str(epochlist.date(ifglist.masnum)),'-',num2str(epochlist.date(ifglist.slvnum)));
names=cellstr(temp);
file=ifg;
plotifgs2(file(:,:,1:16),4,4,names(1:16))
plotifgs2(file(:,:,17:32),4,4,names(17:32))
plotifgs2(file(:,:,33:48),4,4,names(33:48))
plotifgs2(file(:,:,49:64),4,4,names(49:64))
plotifgs2(file(:,:,65:80),4,4,names(65:80))
plotifgs2(file(:,:,81:96),4,4,names(81:96))
plotifgs2(file(:,:,97:112),4,4,names(97:112))
plotifgs2(file(:,:,113:128),4,4,names(113:128))
plotifgs2(file(:,:,129:144),4,4,names(129:144))
plotifgs2(file(:,:,144:160),4,4,names(144:160))
plotifgs2(file(:,:,161:176),4,4,names(161:176))
plotifgs2(file(:,:,177:192),4,4,names(177:192))
plotifgs2(file(:,:,193:208),4,4,names(193:208))
plotifgs2(file(:,:,209:224),4,4,names(209:224))
plotifgs2(file(:,:,225:240),4,4,names(225:240))
plotifgs2(file(:,:,241:256),4,4,names(241:256))
plotifgs2(file(:,:,257:272),4,4,names(257:272))
plotifgs2(file(:,:,273:288),4,4,names(273:288))
plotifgs2(file(:,:,289:304),4,4,names(289:304))
plotifgs2(file(:,:,305:320),4,4,names(305:320))
plotifgs2(file(:,:,321:336),4,4,names(321:336))
plotifgs2(file(:,:,337:352),4,4,names(337:352))
plotifgs2(file(:,:,353:368),4,4,names(353:368))
plotifgs2(file(:,:,369:384),4,4,names(369:384))
plotifgs2(file(:,:,385:400),4,4,names(385:400))



% add ifg number to name list
name_list=strcat(num2str(epochlist.date(ifglist.masnum)),'-',num2str(epochlist.date(ifglist.slvnum)));
assignin('base','name_list',name_list);
[name_rows,name_cols]=size(name_list);
nums=[1:name_rows]';
[nums_rows,nums_cols]=size(nums);
name_matrix=char(zeros(nums_rows,22));
for i=1:name_rows
   num=nums(i);
   num2=sprintf('%03d',num);
   num_val=num2str(num2);
   name_val=name_list(i,:);
   temp=horzcat(num_val,': ',name_val);
   name_matrix(i,:)=temp;
end
names=cellstr(name_matrix);
file=ifg;


plotifgs2(file(:,:,1:16),4,4,names(1:16))
plotifgs2(file(:,:,17:32),4,4,names(17:32))
plotifgs2(file(:,:,33:48),4,4,names(33:48))
plotifgs2(file(:,:,49:64),4,4,names(49:64))
plotifgs2(file(:,:,65:80),4,4,names(65:80))
plotifgs2(file(:,:,81:96),4,4,names(81:96))
plotifgs2(file(:,:,97:112),4,4,names(97:112))
plotifgs2(file(:,:,113:128),4,4,names(113:128))
plotifgs2(file(:,:,129:144),4,4,names(129:144))
plotifgs2(file(:,:,144:153),4,4,names(144:153))


plotifgs2(file(:,:,1:16),4,4,names(1:16))
plotifgs2(file(:,:,17:32),4,4,names(17:32))
plotifgs2(file(:,:,33:48),4,4,names(33:48))
plotifgs2(file(:,:,49:64),4,4,names(49:64))
plotifgs2(file(:,:,65:80),4,4,names(65:80))
plotifgs2(file(:,:,81:96),4,4,names(81:96))
plotifgs2(file(:,:,97:112),4,4,names(97:112))
plotifgs2(file(:,:,113:127),4,4,names(113:127))

plotifgs2(file(:,:,1:16),4,4,names(1:16))
plotifgs2(file(:,:,17:26),4,4,names(17:26))





file=ifg;
image=file(:,:,28);
    figure
    h=imagesc(image);
    freezeColors(h);
    colormap(jet);
    colorbar;
    caxis([-30,30]);
    axis equal;
    axis image;
    z=double(~isnan(image));
    alpha(z);
    set(gcf,'Color',[1 1 1]); 
    set(gca,'Color',[.8 .8 .8]); 
    set(gcf,'InvertHardCopy','off'); 
    set(gcf,'units','normalized','outerposition',[0 0 1 1]);
    
    



file=ifg;
for i=1:nifgs
    image=file(:,:,i);
    figure
    h=imagesc(image);
    freezeColors(h);
    colormap(jet);
    colorbar;
    caxis([-30,30]);
    axis equal;
    axis image;
    z=double(~isnan(image));
    alpha(z);
    set(gcf,'Color',[1 1 1]); 
    set(gca,'Color',[.8 .8 .8]); 
    set(gcf,'InvertHardCopy','off'); 
    set(gcf,'units','normalized','outerposition',[0 0 1 1]);  % auto maximise screen
end









% to determine time gap in years between adjacent epochs:
for i=1:21
    gap(i)=epochlist.span(i+1)-epochlist.span(i);
end

% to plot the number of observations for each pixel in entire ifg dataset:
blah=zeros(size(ifg));
blah(~isnan(ifg))=1;
plotifgs(blah(:,:,1:12),3,4)
for x=1:339
    for y=1:283
        summ(x,y)=sum(blah(x,y,:));
    end
end
plotifg(summ)


% display dem histogram
demv=reshape(dem,x*y,1);
hist(demv);


% show image
image=ifg(:,:,5);
figure
h=imagesc(image);
freezeColors(h);
colormap(jet);
colorbar;
caxis([-80,80]);
axis equal;
axis image;
z=double(~isnan(image));
alpha(z);
set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');


% convert LOS to vertical for single image
inc=38.9067; % from SLC.par file in GAMMA 
factor=cos(degtorad(inc)); % convert degrees to radians first
image_vert=factor.*image;

figure
h=imagesc(image_vert);
freezeColors(h);
colormap(jet);
colorbar;
caxis([-80,80]);
axis equal;
axis image;
z=double(~isnan(image_vert));
alpha(z);
set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');


% change all tscum2 to vertical
inc=38.9556; % from SLC.par file in GAMMA (38.9556 T365A, 38.9067 T366A)
factor=cos(degtorad(inc)); % convert degrees to radians first
tscum2_vert=repmat((factor.*tscum2),1);



% extract pixel details 
icol=189;
irow=214;
for i=1:10
    plot_pixel_sq_avg(tsincr2_vert,ifghdr,epochlist,1,i,icol,irow)
end


% hold shift before starting to get square to select area
rect=getrect
xmin=rect(1)
ymin=rect(2)
width=rect(3)
height=rect(4)


% show all time series images as separate figures
npt=19;
for i=1:npt
    image=tscum2(:,:,i);
    figure
    h=imagesc(image);
    freezeColors(h);
    colormap(jet);
    colorbar;
    caxis([-80,80]);
    axis equal;
    axis image;
    z=double(~isnan(image));
    alpha(z);
    set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');
end




