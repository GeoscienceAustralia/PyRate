function [cc,cc_thres,delay,demerr,dem_org,dem_post_demerr,eqcor,ifg_atm,...
    ifg_demerr_org,ifg_eqmask,ifg_eqmask_org,ifg_eqmask_post_ifg_orb,...
    ifg_final,ifg_model,ifg_orb,ifg_org,ifg_post_atm,ifg_post_delay,...
    ifg_post_demerrest,ifg_post_eqcor,ifg_post_ifg_model2,ifg_post_orb,...
    ifg_post_psmodel,ifg_post_refphs,ifg_ts,outdata_tsincr_org,...
    outdata_tscum_org,psmodel,refphs,refphs2,ts_aps,ts_hp,ts_hp_org,...
    ts_hp_post_tsincr,tsincr,tsincr_org,tsincr_post_ts_aps,...
    tsincr_post_ts_hpdef,tsincr_post_ts_hpdef2,vcm_s,vcm_t] = load_int_files()
%================================================================
%function[]=load_int_files
%                                                                
% Load saved intermediate files created during Pirate processing
%                                                                
%                                                                
% Sarah Lawrie @ GA, 02/10/2015                                 
%
%================================================================

if exist('cc.mat', 'file')
    load('cc.mat');
    delete('cc.mat');
else
    cc=[];
end
if exist('cc_thres.mat', 'file')
    load('cc_thres.mat');
    delete('cc_thres.mat');
else
    cc_thres=[];
end
if exist('delay.mat', 'file')
    load('delay.mat');
    delete('delay.mat');
else
    delay=[];
end
if exist('demerr.mat', 'file')
    load('demerr.mat');
    delete('demerr.mat'); 
else
    demerr=[];
end
if exist('dem_org.mat', 'file')
    load('dem_org.mat');
    delete('dem_org.mat');
else
    dem_org=[];
end
if exist('dem_post_demerr.mat', 'file')
    load('dem_post_demerr.mat');
    delete('dem_post_demerr.mat');
else
    dem_post_demerr=[];
end
if exist('eqcor.mat', 'file')
    load('eqcor.mat');
    delete('eqcor.mat');
else
    eqcor=[];
end
if exist('ifg_atm.mat', 'file')
    load('ifg_atm.mat');
    delete('ifg_atm.mat');
else
    ifg_atm=[];
end
if exist('ifg_demerr_org.mat', 'file')
    load('ifg_demerr_org.mat');
    delete('ifg_demerr_org.mat');
else
    ifg_demerr_org=[];
end
if exist('ifg_eqmask.mat', 'file')
    load('ifg_eqmask.mat');
    delete('ifg_eqmask.mat');    
else
    ifg_eqmask=[];
end
if exist('ifg_eqmask_org.mat', 'file')
    load('ifg_eqmask_org.mat');
    delete('ifg_eqmask_org.mat');    
else
    ifg_eqmask_org=[];
end
if exist('ifg_eqmask_post_ifg_orb.mat', 'file')
    load('ifg_eqmask_post_ifg_orb.mat');
    delete('ifg_eqmask_post_ifg_orb.mat');    
else
    ifg_eqmask_post_ifg_orb=[];
end
if exist('ifg_final.mat', 'file')
    load('ifg_final.mat');
    delete('ifg_final.mat');    
else
    ifg_final=[];
end
if exist('ifg_model.mat', 'file')
    load('ifg_model.mat');
    delete('ifg_model.mat');  
else
    ifg_model=[];
end
if exist('ifg_orb.mat', 'file')
    load('ifg_orb.mat');
    delete('ifg_orb.mat');    
else
    ifg_orb=[];
end
if exist('ifg_org.mat', 'file')
    load('ifg_org.mat');
    delete('ifg_org.mat');    
else
    ifg_org=[];
end
if exist('ifg_post_atm.mat', 'file')
    load('ifg_post_atm.mat');
    delete('ifg_post_atm.mat');
else
    ifg_post_atm=[];
end
if exist('ifg_post_delay.mat', 'file')
    load('ifg_post_delay.mat');
    delete('ifg_post_delay.mat');    
else
    ifg_post_delay=[];
end
if exist('ifg_post_demerrest.mat', 'file')
    load('ifg_post_demerrest.mat');
    delete('ifg_post_demerrest.mat');    
else
    ifg_post_demerrest=[];
end
if exist('ifg_post_eqcor.mat', 'file')
    load('ifg_post_eqcor.mat');
    delete('ifg_post_eqcor.mat');    
else
    ifg_post_eqcor=[];
end
if exist('ifg_post_ifg_model2.mat', 'file')
    load('ifg_post_ifg_model2.mat');
    delete('ifg_post_ifg_model2.mat');  
else
    ifg_post_ifg_model2=[];
end
if exist('ifg_post_orb.mat', 'file')
    load('ifg_post_orb.mat');
    delete('ifg_post_orb.mat');   
else
    ifg_post_orb=[];
end
if exist('ifg_post_psmodel.mat', 'file')
    load('ifg_post_psmodel.mat');
    delete('ifg_post_psmodel.mat');    
else
    ifg_post_psmodel=[];
end
if exist('ifg_post_refphs.mat', 'file')
    load('ifg_post_refphs.mat');
    delete('ifg_post_refphs.mat');    
else
    ifg_post_refphs=[];
end
if exist('ifg_ts.mat', 'file')
    load('ifg_ts.mat');
    delete('ifg_ts.mat');   
else
    ifg_ts=[];
end
if exist('outdata_tsincr_org.mat', 'file')
    load('outdata_tsincr_org.mat');
    delete('outdata_tsincr_org.mat');  
else
    outdata_tsincr_org=[];
end
if exist('outdata_tscum_org.mat', 'file')
    load('outdata_tscum_org.mat');
    delete('outdata_tscum_org.mat');    
else
    outdata_tscum_org=[];
end
if exist('psmodel.mat', 'file')
    load('psmodel.mat');
    delete('psmodel.mat');
else
    psmodel=[];
end
if exist('refphs.mat', 'file')
    load('refphs.mat');
    delete('refphs.mat'); 
else
    refphs=[];
end
if exist('refphs2.mat', 'file')
    load('refphs2.mat');
    delete('refphs2.mat'); 
else
    refphs2=[];
end
if exist('ts_aps.mat', 'file')
    load('ts_aps.mat');
    delete('ts_aps.mat'); 
else
    ts_aps=[];
end
if exist('ts_hp.mat', 'file')
    load('ts_hp.mat');
    delete('ts_hp.mat'); 
else
    ts_hp=[];
end
if exist('ts_hp_org.mat', 'file')
    load('ts_hp_org.mat');
    delete('ts_hp_org.mat');  
else
    ts_hp_org=[];
end
if exist('ts_hp_post_tsincr.mat', 'file')
    load('ts_hp_post_tsincr.mat');
    delete('ts_hp_post_tsincr.mat');
else
    ts_hp_post_tsincr=[];
end
if exist('tsincr.mat', 'file')
    load('tsincr.mat');
    delete('tsincr.mat');  
else
    tsincr=[];
end
if exist('tsincr_org.mat', 'file')
    load('tsincr_org.mat');
    delete('tsincr_org.mat');    
else
    tsincr_org=[];
end
if exist('tsincr_post_ts_aps.mat', 'file')
    load('tsincr_post_ts_aps.mat');
    delete('tsincr_post_ts_aps.mat'); 
else
    tsincr_post_ts_aps=[];
end
if exist('tsincr_post_ts_hpdef.mat', 'file')
    load('tsincr_post_ts_hpdef.mat');
    delete('tsincr_post_ts_hpdef.mat'); 
else
    tsincr_post_ts_hpdef=[];
end
if exist('tsincr_post_ts_hpdef2.mat', 'file')
    load('tsincr_post_ts_hpdef2.mat');
    delete('tsincr_post_ts_hpdef2.mat');    
else
    tsincr_post_ts_hpdef2=[];
end
if exist('vcm_s.mat', 'file')
    load('vcm_s.mat');
    delete('vcm_s.mat');    
else
    vcm_s=[];
end
if exist('vcm_t.mat', 'file')
    load('vcm_t.mat');
    delete('vcm_t.mat');    
else
    vcm_t=[];
end

end