function[]=split_ifgs(ifg,epochlist,ifglist,plot_per_page)
%=================================================================
%function[]=split_fgs(ifg,m,n)
%                                                                 
% Split list of ifgs and their names into chunks for plotting 
%                                                                 
% INPUT:                                                          
%  ifg:       input interferograms in 3-d matrix (rows, cols, ifgid)   
%  epochlist: list of epochs
%  ifglist:   list of ifgs
%  plot_per page: number of subplots per page (default 20)
%                                                                 
% Sarah Lawrie @ GA, 26/10/2015 
%
%=================================================================
opengl software
[~,~,nifgs]=size(ifg);

% Create ifg name list
name_list=strcat(num2str(epochlist.date(ifglist.masnum)),'-',num2str(epochlist.date(ifglist.slvnum)));
assignin('base','name_list',name_list);

[name_rows,~]=size(name_list);

% add ifg number to name list
nums=[1:name_rows]';
[nums_rows,~]=size(nums);
name_matrix=char(zeros(nums_rows,22));
for i=1:name_rows
   num=nums(i);
   num2=sprintf('%03d',num);
   num_val=num2str(num2);
   name_val=name_list(i,:);
   temp=horzcat(num_val,': ',name_val);
   name_matrix(i,:)=temp;
end
clear  name_list;

% Split names list into increments
total_names=name_rows;
split_names=total_names / plot_per_page;

% Take integer value from split_names and split list evenly
integ_names=floor(split_names);
even_name=integ_names * plot_per_page;

for i=1:even_name
    if i==1
        w=plot_per_page;
        s=num2str(i);
        l='names';
        listname=strcat(l,s);
        listing=name_matrix(i:w,:);
        assignin('caller',listname,listing);
        eval([listname '=listing;']);
    else
        q=w + 1;
        if q > even_name
            break
        end         
        w=(q + plot_per_page) -1;
        s=num2str(i);
        l='names';
        listname=strcat(l,s);
        listing=name_matrix(q:w,:);
        assignin('caller',listname,listing);        
        eval([listname '=listing;']);        
    end
end

% Take fractional value from split_names and make list from remaining
if split_names > 1
    fract_name=split_names-integ_names;
    leftover_name=fract_name * plot_per_page;
    left_name=ceil(leftover_name);
    %if fract_name < 0.5
    %    left_name=floor(leftover_name);
    %else 
    %    left_name=ceil(leftover_name);
    %end
    fract_list_name=integ_names + 1;
    s=num2str(fract_list_name);
    l='names';
    listname=strcat(l,s);
    a=w + 1;
    b=left_name + w;
    listing=name_matrix(a:b,:);
    assignin('caller',listname,listing);    
    eval([listname '=listing;']);    
else
    fract_name=split_names-integ_names;
    leftover_name=fract_name * plot_per_page;
    left_name=ceil(leftover_name);
    fract_list_name=integ_names + 1;
    s=num2str(fract_list_name);
    l='names';
    listname=strcat(l,s);    
    listing=name_matrix(1:left_name,:);
    assignin('caller',listname,listing);    
    eval([listname '=listing;']);    
end
    
    
% Split ifg list into plot per page increments
total_ifgs=nifgs;
split_ifgs=total_ifgs / plot_per_page;

% Take integer value from split_ifgs and split list evenly
integ=floor(split_ifgs);
even=integ * plot_per_page;

for i=1:even
    if i==1
        w=plot_per_page;
        s=num2str(i);
        l='sublist';
        listname=strcat(l,s);
        listing=ifg(:,:,i:w);
        assignin('caller',listname,listing);
        eval([listname '=listing;']);   
    else
        q=w + 1;
        if q > even
            break
        end         
        w=(q + plot_per_page) -1;
        s=num2str(i);
        l='sublist';
        listname=strcat(l,s);
        listing=ifg(:,:,q:w);
        assignin('caller',listname,listing);
        eval([listname '=listing;']);         
    end
end

% Take fractional value from split_ifgs and make list from remaining
if split_ifgs > 1
    fract=split_ifgs-integ;
    leftover=fract * plot_per_page;
    left=ceil(leftover);
    %if fract < 0.5
    %    left=floor(leftover);
    %else 
    %    left=ceil(leftover);
    %end
    fract_list=integ + 1;
    s=num2str(fract_list);
    l='sublist';
    listname=strcat(l,s);
    c=w + 1;
    d=left + w;
    listing=ifg(:,:,c:d);
    assignin('caller',listname,listing);
    eval([listname '=listing;']);   
else
    fract=split_ifgs-integ;
    leftover=fract * plot_per_page;
    left=ceil(leftover);
    fract_list=integ + 1;
    s=num2str(fract_list);
    l='sublist';
    listname=strcat(l,s);    
    listing=ifg(:,:,1:left);
    assignin('caller',listname,listing);
    eval([listname '=listing;']);   
end

% Clear unnecessary variables
clear a b c cols d epochlist even even_name fract fract_list fract_list_name fract_name i ifg ifglist ifgvars ind integ integ_names l;
clear left left_name leftover leftover_name listing listname namevars name_cols name_matrix name_rows name_val nifgs num num2 num_val nums;
clear nums_cols nums_rows outStr plot_per_page q rows s split_ifgs split_names temp total_ifgs total_names w;

% Save list of variables from workspace to use in pdf_plotifgs.m
save 'split_ifgs.mat';

