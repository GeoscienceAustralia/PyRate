function [fitmodelpar,ifglist,outdata]=loop_int(ifg,ifghdr,ifglist,epochlist,dem,mstmat,cbasep)
%==================================================================
%function [fitmodelpar,ifglist,outdata]=loop(ifg,ifghdr,ifglist,epochlist,dem,mstmat,cbasep)
%
% The loop slip rate inversion program for multi-interferogram method
%
% INPUT:
%   ifg:       interferograms
%   ifghdr:    interferogram header file
%   ifglist:   interferogram list
%   epochlist: epoch list
%   dem:       dem data
%   mstmat:    flag matrix for independent interferograms
%   cbasep:    coefficient of perpendicular baseline
%
%
% OUTPUT:
%   fitmodelpar: fitted model parameters
%   ifglist:   ifglist with updated vcm
%   outdata:   structure for output data
%
% Hua Wang @ Uni Leeds, 13/03/2008
% Sarah Lawrie @ GA, 01 Oct 2015
%   - modified to save intermediate files
%==================================================================

%load processing parameters
load pars

%%%dimension of ifg
nifgs=length(ifglist.nml);

%step index
istep=1;

%------------------------------------------
%1. remove initial model
%------------------------------------------
if (inimodelpar.nmodels>0)
  fprintf('==>STEP %d: removing the initial model...\n',istep);
  istep=istep+1;
  ifg_model=zeros(size(ifg),'single');
  for i=1:nifgs
    for j=1:inimodelpar.nmodels
      ifg_model(:,:,i)=ifg_model(:,:,i)+inimodelpar.fmodel(:,:,j)*inimodelpar.rate(j)*ifglist.BaseT(i);
    end
  end
  ifg=ifg-ifg_model;
  % save files
  ifg_post_ifg_model=ifg;
  save('ifg_post_ifg_model.mat','ifg_post_ifg_model');
  save('ifg_model.mat','ifg_model');  
  clear ifg_post_ifg_model;
end

%------------------------------------------
%2. remove spatially high-pass dem errors
%------------------------------------------
if shpdemest==1
  fprintf('==>STEP %d: removing spatially uncorrelated dem errors...\n',istep);
  istep=istep+1;
  ifg_demerr=zeros(size(ifg),'single');
  fprintf('spatial low-pass filtering... \n');
  for i=1:nifgs
    ifg_demerr(:,:,i)=slpfilter(ifg(:,:,i),slpfpar,ifghdr.xpsize,ifghdr.ypsize);
  end
  % save files  
  ifg_demerr_org=ifg_demerr;
  save('ifg_demerr_org.mat','ifg_demerr_org'); 
  clear ifg_demerr_org;
  ifg_demerr=ifg-ifg_demerr;
  %remove reference phase
  [refphs,ifg_demerr]=refphsest(ifg_demerr,refpar,refpt);
  [demerr,ifg_demerrest]=demerrorest(ifg_demerr,ifglist,cbasep,stackpar.pthr,mstmat);
  ifg=ifg-ifg_demerrest;
  % save files
  ifg_post_demerrest=ifg;
  save('ifg_post_demerrest.mat','ifg_post_demerrest');  
  clear ifg_post_demerrest;
  %update dem
  dem=dem+demerr;
  dem_post_demerr=dem;
  save('demerr.mat','demerr'); 
  save('refphs.mat','refphs');
  save('dem_post_demerr.mat','dem_post_demerr');    
  clear('demerr','ifg_demerr','ifg_demerrest','dem_post_demerr');
end

%----------------------------------------------
%3. mask earthquakes for orb/atm/aps estimation
%----------------------------------------------
if iopar.eqflag==2 && apsest==1
    fprintf('==>STEP %d: Masking eq region in preparation for step deformation estimation...\n',istep);
    istep=istep+1;
    [stepincr,ifg_eqmask] = maskeq(ifg,ifglist,epochlist,iopar.eqfilelist);
end

%------------------------------------------
%4. correct orbital errors
%------------------------------------------
if orbfit==1
  fprintf('==>STEP %d: correcting orbit errors...\n',istep);
  istep=istep+1;
  if iopar.eqflag==2 && apsest==1
    [ifg_orb] = orbcorrect(ifg_eqmask,ifglist,orbfitpar,refpt,ifghdr);
    % save files
    ifg_eqmask_org=ifg_eqmask;
    save('ifg_eqmask_org.mat','ifg_eqmask_org');     
    clear ifg_eqmask_org;
    ifg_eqmask=ifg_eqmask-ifg_orb;
    ifg_eqmask_post_ifg_orb=ifg_eqmask;    
    save('ifg_eqmask_post_ifg_orb.mat','ifg_eqmask_post_ifg_orb');  
    clear ifg_eqmask_post_ifg_orb;
  else
    [ifg_orb] = orbcorrect(ifg,ifglist,orbfitpar,refpt,ifghdr);
  end
  ifg=ifg-ifg_orb;
  % save files
  ifg_post_orb=ifg;
  save('ifg_orb.mat','ifg_orb');
  save('ifg_post_orb.mat','ifg_post_orb');
  clear ('ifg_orb','ifg_post_orb');
end

%------------------------------------------
%5. correcting DEM derived atmospheric delay errors
%------------------------------------------
if atmfit==1
  fprintf('==>STEP %d: correcting topo-correlated atmospheric delay errors...\n',istep);
  istep=istep+1;
  if iopar.eqflag==2 && apsest==1
    [ifg_atm] = atmcorrect(ifg_eqmask,ifglist,dem,atmfitpar,refpt);
    ifg_eqmask=ifg_eqmask-ifg_atm;
  else
    [ifg_atm] = atmcorrect(ifg,ifglist,dem,atmfitpar,refpt);
  end
  ifg=ifg-ifg_atm;
  % save files
  ifg_post_atm=ifg;
  save('ifg_atm.mat','ifg_atm');
  save('ifg_post_atm.mat','ifg_post_atm');  
  clear ('ifg_atm','ifg_post_atm');
end

%------------------------------------------
%6. remove reference phase
%------------------------------------------
fprintf('==>STEP %d: removing reference phase...\n',istep);
istep=istep+1;
if iopar.eqflag==2 && apsest==1
  [refphs,ifg_eqmask] = refphsest(ifg_eqmask,refpar,refpt);
  for i=1:nifgs
    ifg(:,:,i)=ifg(:,:,i)-refphs(i);
  end
  % save files
  ifg_post_refphs=ifg;
  refphs2=refphs;
  save('refphs2.mat','refphs2');
  save('ifg_post_refphs.mat','ifg_post_refphs');   
  clear ('ifg_post_refphs','refphs2');
else
    [refphs,ifg] = refphsest(ifg,refpar,refpt);
    % save files
    ifg_post_refphs=ifg;
    save('ifg_post_refphs.mat','ifg_post_refphs');     
    clear ifg_post_refphs;
end

%------------------------------------------
%7. APS filter
%------------------------------------------
if apsest==1
  fprintf('==>STEP %d: APS estimation ...\n',istep);
  istep=istep+1;

  %time-series analysis without smoothing, just get raw ts
  fprintf('raw time series inversion ... \n');
  [tsincr]=tsinvnosm(ifg,ifglist,epochlist,tspar.pthr,mstmat);
  
  %find step displacements, and remove from original tsincr
  if iopar.eqflag==2
    [ts_hpdef]=corrdeform(tsincr,ifghdr,stepincr,corrpar);
    % save files
    tsincr_org=tsincr;
    tsincr=tsincr-ts_hpdef;    
    tsincr_post_ts_hpdef=tsincr;
    save('tsincr_org.mat','tsincr_org'); 
    save('tsincr_post_ts_hpdef.mat','tsincr_post_ts_hpdef'); 
    clear ('tsincr_org','tsincr_post_ts_hpdef');    
  end
  % save files
  tsincr_org=tsincr;
  save('tsincr_org.mat','tsincr_org');   
  clear tsincr_org;
  
  %temporal low-pass filter and then high-pass
  [ts_hp] = tlpfilter(tsincr,epochlist,thpfpar);
  % save files
  ts_hp_org=ts_hp;
  ts_hp=tsincr-ts_hp;  
  ts_hp_post_tsincr=ts_hp;
  save('ts_hp_org.mat','ts_hp_org');  
  save('ts_hp.mat','ts_hp');
  save('ts_hp_post_tsincr.mat','ts_hp_post_tsincr'); 
  clear ('ts_hp_org','ts_hp_post_tsincr');
 
  %spatial low-pass filter
  fprintf('spatial low-pass filtering... \n');
  ts_aps=zeros(size(ts_hp),'single');
  nincr=size(ts_aps,3);
  for i=1:nincr
    ts_aps(:,:,i) = slpfilter(ts_hp(:,:,i),slpfpar,ifghdr.xpsize,ifghdr.ypsize);
  end

  %remove aps
  tsincr=tsincr-ts_aps;
  % save files
  tsincr_post_ts_aps=tsincr;
  save('ts_aps.mat','ts_aps');
  save('tsincr_post_ts_aps.mat','tsincr_post_ts_aps'); 
  clear tsincr_post_ts_aps;
  
  %add back high-pass deformation if it will be estimated in ts analysis
  if iopar.eqflag==2 && tspar.stepest==1
    tsincr=tsincr+ts_hpdef;
    % save files
    tsincr_post_ts_hpdef2=tsincr;
    save('tsincr_post_ts_hpdef2.mat','tsincr_post_ts_hpdef2');     
    clear tsincr_post_ts_hpdef2;
  end

  %convert from ts to ifgs
  ifg_ts=ts2ifgs(tsincr,ifglist);
  %interpolation in raw ts inversion, so mask nans here again
  ifg(~isnan(ifg))=ifg_ts(~isnan(ifg));
  save('ifg_ts.mat','ifg_ts');
  save('tsincr.mat','tsincr');

  clear('tsincr','ts_hp','ts_aps','ifg_ts');
end

%------------------------------------------
%8. calculate covariance matrix for each interferogram
%------------------------------------------
fprintf('==>STEP %d: making variance-covariance matrix...\n',istep);
istep=istep+1;
if iopar.eqflag==2 && apsest==1
  ifg_eqmask(~isnan(ifg_eqmask))=ifg(~isnan(ifg_eqmask));
  [ifglist.maxvar,ifglist.alpha,vcm_t,vcm_s] = make_vcm(ifg_eqmask,ifghdr.xpsize,ifghdr.ypsize,ifglist,vcmpar);
  % save files
  save ('ifg_eqmask.mat','ifg_eqmask');
  clear ifg_eqmask;
else
  [ifglist.maxvar,ifglist.alpha,vcm_t,vcm_s] = make_vcm(ifg,ifghdr.xpsize,ifghdr.ypsize,ifglist,vcmpar);
end
% save files
save('vcm_s.mat','vcm_s');
save('vcm_t.mat','vcm_t');

%------------------------------------------
%9. add back the initial model
%------------------------------------------
if inimodelpar.nmodels>0
  fprintf('==>STEP %d: adding back models...\n',istep);
  istep=istep+1;
  ifg=ifg+ifg_model;
  % save files
  ifg_post_ifg_model2=ifg;
  save('ifg_post_ifg_model2.mat','ifg_post_ifg_model2'); 
  clear('ifg_model','ifg_post_ifg_model2');
end

%------------------------------------------
%10. final time series analysis
%------------------------------------------
if tspar.tscal==1
  fprintf('==>STEP %d: final time series analysis (it may take a few minutes) ...\n',istep);
  istep=istep+1;
  if exist('stepincr')==0
      stepincr=[];
  end
  [outdata.tsincr,outdata.tserr,outdata.tscum]=ts(ifg,ifglist,epochlist,vcm_t,tspar,mstmat,cbasep,iopar.tsdir,stepincr);
  %add back the high-pass deformation if it is not estimated by ts
  if (tspar.stepest==0) && (~isempty(stepincr))
    outdata_tsincr_org=outdata.tsincr;
    outdata_tscum_org=outdata.tscum;
    outdata.tsincr=outdata.tsincr+ts_hpdef;
    outdata.tscum=outdata.tscum+cumsum(ts_hpdef,3);    
    % save files
    save('outdata_tsincr_org.mat','outdata_tsincr_org');    
    save('outdata_tscum_org.mat','outdata_tscum_org');     
    save('ts_hpdef.mat','ts_hpdef');
    clear('outdata_tsincr_org','outdata_tscum_org','ts_hpdef');
  end
end

%------------------------------------------
%11. final ifgs stacking
%------------------------------------------
fprintf('==>STEP %d: final stacking (it may take a few minutes) ...\n',istep);
istep=istep+1;
[outdata.stackmap,outdata.errormap,outdata.coh_sta,demerr]=stack(ifg,ifglist,vcm_t,stackpar,mstmat,cbasep);
%update dem
if ~isempty(demerr)
  % save files    
  dem=dem+demerr;
  dem_post_demerr=dem;  
  save('dem_post_demerr.mat','dem_post_demerr');
  clear dem_post_demerr;
end
outdata.dem=dem;

% save files
ifg_final=ifg;
save('ifg_final.mat','ifg_final'); 
clear ifg_final;

clear ifg;

%------------------------------------------
%13. estimates slip rate from stacked rate map
%------------------------------------------
if inimodelpar.nmodels>1
  fprintf('==>STEP %d: inverting slip rate...\n',istep);
  [s,stds,outdata.ratemap,outdata.resmap]=slipinv(outdata.stackmap,outdata.errormap,vcm_s,refpt,ifghdr,inimodelpar,vcmpar,orbfitpar.degree,dem);
  fitmodelpar.rate=s(1:inimodelpar.nmodels); 
  fitmodelpar.stds=stds(1:inimodelpar.nmodels);
else
  fitmodelpar=[];
end
