function[]=create_geotiff(ifg,nsig,ifghdr,filename)

%================================================================
%function[]=create_geotiff(ifg,nsig,ifghdr,filename)
%                                                                
% Creates a geotiff of an output file (eg. ratemap) in WGS 84 coords
%      - designed to be used in ArcGIS
%                                                                
% INPUT:                                                         
%   ifg:      input interferogram/ratemap                                     
%   nsig:     flag for the range of output values                    
%             - nsig:  plot within [mean - nsig*sigma, mean + nsig*sigma]
%   ifghdr:   ifg header
%   filename: name of output geotiff file (eg. 'ratemap_final')
%                                                                
% Sarah Lawrie @ GA, 29/07/2015                                 
%
%================================================================

opengl software
[rows,cols]=size(ifg);

% Min and max values for ifg
minval=min(ifg(:));
maxval=max(ifg(:));

% Open empty figure screen
figure

% Calculate std and mean
if nsig>0
  ifgv = reshape(ifg',rows*cols,1);
  ifgv(isnan(ifgv))=[];
  std_ifg=std(ifgv);
  mean_ifg=mean(ifgv);
  clims = [mean_ifg-nsig*std_ifg mean_ifg+nsig*std_ifg];
else
  clims = [min(min(ifg)) max(max(ifg))];
end

% Calculate geographic coordinates
x=[ifghdr.xfirst,ifghdr.xfirst+(cols-1)*ifghdr.xstep];
y=[ifghdr.yfirst,ifghdr.yfirst+(rows-1)*ifghdr.ystep];

% Set figure boundaries
h=imagesc(x,y,ifg);
freezeColors(h);
set(gca,'YDir','normal');
colormap(jet);
colorbar;
axis equal;
axis image;

% Set the alpha map for the NaN region
z=double(~isnan(ifg));
alpha(z);
set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');
hold on

% Create png file for quick reference
print('-dpng','-r300',num2str(filename));

% Remove axes from figure for tif
set(gca,'xtick',[],'xticklabel',[]);
set(gca,'ytick',[],'yticklabel',[]);
set(gca, 'visible', 'off');

% Create initial tif
in_tif=([(filename) '.tif']);
out_tif=([(filename) '_geo.tif']);
t = Tiff(in_tif, 'w'); 
tagstruct.ImageLength = size(ifg, 1); 
tagstruct.ImageWidth = size(ifg, 2); 
tagstruct.Compression = Tiff.Compression.None; 
tagstruct.SampleFormat = Tiff.SampleFormat.IEEEFP; 
tagstruct.ExtraSamples = Tiff.ExtraSamples.AssociatedAlpha;
tagstruct.Photometric = Tiff.Photometric.MinIsBlack; 
tagstruct.BitsPerSample = 64; 
%tagstruct.BitsPerSample = 1; 
tagstruct.SamplesPerPixel = 1; 
tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky; 
t.setTag(tagstruct); 
t.write(ifg); 
t.close();

% Preview initial tif
%figure
%imshow(in_tif);

% Create geotif
img=imread(in_tif);
% Convert nan to max value that's rounded up to (for ArcGIS to show no data as a transparency properly)
if maxval < 0
    rnd=ceil(maxval)-1;
else
    rnd=ceil(maxval)+1;
end
img(isnan(img))=rnd;
% Coordinates for tif
lon_w=x(1);
lat_s=y(2);
lon_e=x(2);
lat_n=y(1);
R = georasterref('RasterInterpretation','cells');
R.RasterSize = [rows cols];
R.LatitudeLimits  = [lat_s lat_n];
R.LongitudeLimits = [lon_w lon_e];
R.ColumnsStartFrom = 'north';
R.RowsStartFrom = 'west';
% Write geotif
geotiffwrite (out_tif,img, R);

% Preview geotif
%figure
%imshow(out_tif);

% Clean up files
delete(in_tif);

end