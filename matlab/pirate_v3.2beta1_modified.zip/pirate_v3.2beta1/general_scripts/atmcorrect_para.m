function [ifg_atm,atmparams]=atmcorrect_para(ifg,ifglist,dem,atmfitpar,refpt)
%============================================================================
%function [ifg_atm,atmparams]=atmcorrect(ifg,ifglist,dem,atmfitpar,refpt)
%                                                                            
% Function for atm correction, both ifg-by-ifg and epoch-by-epoch methods are supported
%                                                                     
% INPUT:                                                              
%   ifg:       interferograms                                       
%   ifglist:   master/slave image list for each interferogram       
%   dem:       dem data                                             
%   atmfitpar: atm fit parameters including
%              lksx/lksy - looks number (x: east, y: north)                     
%              refx/refy - coordinate of the reference point                    
%              method    - atm errors fitting method                           
%                          1: ifg-by-ifg method; 2: epoch-by-epoch method       
%   refpt:     reference point
%                                                                     
% OUTPUT:                                                             
%   ifg_atm:     topographically-correlated atm errors                
%                                                                     
% Hua Wang @ Uni Leeds, 02/02/2008, following Juliet Biggs, 2006      
%
% 22/10/2011 HW: move reference phase estimation to refphsest.m
% 05/08/2011 HW: change input as structure
% 30/09/2010 HW: change reference phase as the median of the common pixels in all ifgs
% 10/08/2010 HW: fix a bug for the ifgs whose pixels are all NaNs after masking
% 12/09/2009 HW: fitting all ifgs for ifg-by-ifg method, to be improved
% 09/08/2009 HW: added ifglist_mst to fit orbital errors using independent
%                ifgs, but forward calculation for all the ifgs.
%============================================================================

[rows,cols,nifgs]=size(ifg);

%get independant ifg using mst algorithm, added on 10/08/2010, HW
ifglist.nanfrac=ifgnanfrac_para(ifg); 
%remove the ifg from ifglist whose nanfrac is zero
indx=find(ifglist.nanfrac<0.99);
ifglist = getsubstruct(ifglist,indx);

if atmfitpar.method==2
  [ifglist_mst]=mst_kruskal(ifglist);
else
  ifglist_mst=ifglist;
end
nifgs_mst = length(ifglist_mst.id);

%% multilook interferogram
parfor i=1:nifgs_mst
  [ifg_lowres(:,:,i)]=looks_para(ifg(:,:,ifglist_mst.id(i)),atmfitpar.lksx,atmfitpar.lksy);
end

[dem_lowres]=looks_para(dem,atmfitpar.lksx,atmfitpar.lksy);
[rows_lowres,cols_lowres]=size(dem_lowres);
refptlks.y=floor(refpt.y/atmfitpar.lksy);
refptlks.x=floor(refpt.x/atmfitpar.lksx);
n_lowres=rows_lowres*cols_lowres;

%%observations from matrix to vector
obsv=zeros(nifgs_mst*n_lowres,1);
for i=1:nifgs_mst
  i1 = (i-1)*n_lowres+1;
  i2 = i*n_lowres;
  obsv(i1:i2,1)=reshape(ifg_lowres(:,:,i)',n_lowres,1);
end
clear ifg_lowres;

%%design matrix
%% using independent ifgs, 10/08/2009, HW
[B]=atmdesign(ifglist_mst,dem_lowres,refptlks,atmfitpar);

%delete NaN data points
B(isnan(obsv)==1,:)=[];
obsv(isnan(obsv)==1,:)=[];

%calculate atm parameters
%atmparams=B\obsv;
if atmfitpar.method==2
  atmparams=pinv(B,1.0e-3)*obsv;
else
  atmparams=inv(B'*B)*(B'*obsv);
end

clear('B','obsv');

%forward calculation atm errors in full resolution one by one considering the memory
[ifg_atm0]=atmfwd_para(ifglist,dem,refpt,atmfitpar.method,atmparams);

%add atm for the ifgs whose nanfrac<0.005, added on 10/08/2010, HW
ifg_atm=zeros(rows,cols,nifgs,'single');
ifg_atm(:,:,indx)=ifg_atm0;
clear ifg_atm0;

%set NaNs 
%switch off in case mask manually
%ifg_atm(isnan(ifg))=NaN;

%calculate offset of forward ifgs by the median of original ifgs
parfor i=1:nifgs
  offset=nanmedian(reshape(ifg(:,:,i)-ifg_atm(:,:,i),[],1));
  ifg_atm(:,:,i)=ifg_atm(:,:,i)+offset;
end

%reshape the parameter and output
%calculate atm parameters, without the constant offset
%used for atm error simulation
ncoefline = length(atmparams)-nifgs_mst;
atmparams=atmparams(1:ncoefline);
