% coherence average - Camden ifgs

% use shortest time span (ifglist.BaseT)
% exclude 2, use 1 and 3 only


% save cc_thres and ifghdr first then clear workspace and load saved
% cc_thres and ifghdr

save 'cc_thres.mat' cc_thres
save 'ifghdr.mat' ifghdr
clear
load ('cc_thres.mat')
load ('ifghdr.mat')

%track=t081 or t246
track='t081';
lks='5lks';
thres='04';

% copy cc_thres
newVarName1=strcat('cc_',track,'_',lks,'_',thres,'c');
eval([newVarName1 '=cc_thres;']);
%output_name1=sprintf(newVarName1,'.mat');
%save(output_name1,newVarName1);

% save ifghdr file
newVarName2=strcat('ifghdr_',track,'_',lks);
eval([newVarName2 '=ifghdr;']);
%output_name2=sprintf(newVarName2,'.mat');
%save(output_name2,newVarName2);

image_set=eval(newVarName1);

num1=1;
eval(['cc_' track '_' lks '_' thres '_thres_' num2str(num1) '=image_set(:,:,num1);']);
num2=3;
eval(['cc_' track '_' lks '_' thres '_thres_' num2str(num2) '=image_set(:,:,num2);']);

%for i=1:3
%    eval(['cc_' track '_' lks '_' thres '_' num2str(i) '=image_set(:,:,i);']);
%    eval(['cc_' track '_' lks '_' thres '_thres_' num2str(i) '=image_set(:,:,i);']);
%end

pre=char(strcat('cc_',track,'_',lks,'_',thres,'_thres*'));
files=who(pre);

temp1=eval((char(files(1,1)))); image_set(:,:,1);
temp3=eval((char(files(2,1)))); image_set(:,:,3);
%temp2=eval((char(files(2,1)))); image_set(:,:,2);
%temp3=eval((char(files(3,1)))); image_set(:,:,3);

%temp4=(temp1+temp2+temp3)/3;
temp4=(temp1+temp3)/2;
newVarName3=strcat('cc_',track,'_',lks,'_',thres,'_avg');
eval([newVarName3 '=temp4;']);

temp5=temp4;
temp5(temp5 == 0) = NaN;
temp6=~isnan(temp5);
newVarName4=strcat('cc_',track,'_',lks,'_',thres,'_avg_nan');
eval([newVarName4 '=temp6;']);

% view image
image=eval((char(newVarName4))); temp6;
figure
h=imagesc(image);
freezeColors(h);
colorbar;
axis equal;
axis image;

% save all variables
newVarName5=strcat('cc_',track,'_',lks,'_',thres,'c_results');
output_name4=sprintf(newVarName5,'.mat');
save(output_name4,newVarName1,newVarName2,newVarName3,newVarName4); 

% save image to geotiff (for ArcGIS)
create_geotiff(image,5,ifghdr,newVarName5);
%save_single_image(image,ifghdr,newVarName5);

% file cleanup
delete('cc_thres.mat');
delete('ifghdr.mat');


% find overlapping coherent regions 

% same no. rows and cols, but coords slightly different so overlap.m
% doesn't work properly

% do in arcGIS with each track geotiffed:
%     Spatial Analyst,Local,Cell Statistics











% old script:

track='t246';
thres=0.1;
image_set=eval(sprintf('cc_%s', track));

for i=1:3
    eval(['cc_' track '_' num2str(i) '=image_set(:,:,i);']);
    eval(['cc_' track '_thres_' num2str(i) '=image_set(:,:,i);']);
end

pre=char(strcat('cc_',track,'_thres*'));
files=who(pre);

temp1=eval((char(files(1,1)))); image_set(:,:,1);
temp2=eval((char(files(2,1)))); image_set(:,:,2);
temp3=eval((char(files(3,1)))); image_set(:,:,3);

temp1(temp1 < thres) = 0;
temp2(temp2 < thres) = 0;
temp3(temp3 < thres) = 0;

temp4=(temp1+temp2+temp3)/3;
temp5=temp4;
newVarName=strcat('cc_',track,'_avg');
assignin('base',newVarName,temp4);

temp5(temp5 == 0) = NaN;
temp6=~isnan(temp5);
newVarName2=strcat('cc_',track,'_avg_nan');
assignin('base',newVarName2,temp6);

image=eval((char(newVarName2))); temp6;

clear('temp1');
clear('temp2');
clear('temp3');
clear('temp4');
clear('temp5');
clear('temp6');
clear('newVarName');
clear('newVarName2');
clear('newVarName3');
clear('files');
clear('image_set');
clear('pre');
clear('track');
clear('i');
clear('ans');

figure
h=imagesc(image);
freezeColors(h);
colorbar;
axis equal;
axis image;


% find overlapping coherent regions 

% same no. rows and cols, but coords slightly different so overlap.m
% doesn't work properly

% do in arcGIS with each track geotiffed:
%     Spatial Analyst,Local,Cell Statistics










%below doesn't work because of differnt image sizes
cc_avg_nan_comb=cc_t081_avg_nan+cc_t246_avg_nan;

figure
h=imagesc(cc_avg_nan_comb);
freezeColors(h);
colorbar;
axis equal;
axis image;


% all values (0 to 1)
cc_all=cc1+cc2+cc3;
temp4=cc_all/3;

temp=temp4;
temp(temp == 0) = NaN;
cc_avg_nan=~isnan(temp);

figure
h=imagesc(cc_avg_nan);
freezeColors(h);
colorbar;
axis equal;
axis image;
