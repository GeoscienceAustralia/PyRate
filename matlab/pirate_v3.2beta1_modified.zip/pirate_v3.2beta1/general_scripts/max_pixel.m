function[]=max_pixel(ifg,nifgs,epochlist,ifglist)
%=======================================================
%function[]=max_pixel(ifg,nifgs,epochlist,ifglist)
%
% Determine pixel/s which are coherent in all ifgs (for refpt)
% If pixel/s isn't coherent in all ifgs, the pixel which has a value in
% the majority of ifgs will be identified and a list of those ifgs
% produced (variable A).
%
% INPUT:
%   ifg:       input interferograms
%   nifgs:     number of interferograms
%   epochlist: list of epochs
%   ifglist:   list of interferograms
%
% Sarah Lawrie @ GA, 28/10/2015
%
%======================================================


% create cell array for each ifg, 1=value 0=NaN
for i=1:nifgs
    ifg1=ifg(:,:,i);
    temp1{i}=~isnan(ifg1);
end

% convert cell array to matrix
temp2=zeros([size(temp1{1}) size(temp1,2)]);
for i=1:nifgs
    temp3=temp1{i};
    temp4=double(temp3);
    temp2(:,:,i)=temp4;
end
temp5=sum(temp2,3); % sum third dimension (= no. ifgs) 
[M,I]=max(temp5(:)) % M is the max value, I is the index containing the max value
[I_row, I_col]=ind2sub(size(temp5),I) % extract the row and column indices

% show image of sum of pixels
image=temp5;
figure
h=imagesc(image);
freezeColors(h);
colormap(jet);
colorbar;
caxis([0,M]);
axis equal;
axis image;
z=double(~isnan(image));
alpha(z);
set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');

% get value at the indice for each ifg
temp6=permute(temp2,[3,2,1]);
for i=1:nifgs
    temp7=temp6(:,I_col,I_row);
end
sum(temp7(:)); % check gives same as earlier sum 
data2=num2cell(temp7);

% get ifg names
temp8 = strcat(num2str(epochlist.date(ifglist.masnum)),'-',num2str(epochlist.date(ifglist.slvnum)));     
names1=cellstr(temp8);

temp9=regexp(names1,'-','split'); % calculate difference between mas and slv
temp10=str2double(vertcat(temp9{:}));
mas_slv=num2cell(temp10);

for i=1:nifgs
    temp11=num2str(mas_slv{i,1});
    temp12=strcat(temp11(1:4),'.',temp11(5:6),'.',temp11(7:8));
    res1=datenum(temp12,'yy.mm.dd');
    
    temp13=num2str(mas_slv{i,2});
    temp14=strcat(temp13(1:4),'.',temp13(5:6),'.',temp13(7:8));
    res2=datenum(temp14,'yy.mm.dd');
    
    diff{i}=(res2-res1);
end
diff2=vertcat(diff{:});
diff3=num2cell(diff2);

header={'Pixel_Value','Master','Slave','Time_Diff'};
temp15=[data2 mas_slv diff3];
ifg_values=[header;temp15]; % list of values and ifg dates

A=ifg_values; % remove nan values (= 0)
A(any(cellfun(@(x) any(x==0),A),2),:) = []; % list of final ifgs

