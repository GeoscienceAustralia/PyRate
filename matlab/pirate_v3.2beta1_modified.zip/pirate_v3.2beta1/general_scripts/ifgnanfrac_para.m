function[frac]=ifgnanfrac_para(ifg) 
%==========================================
%function[frac]=ifgnanfrac(ifg) 
%                                                          
% Calcualte the fraction of NaN pixels
%                                                          
% INPUT:                                                   
%   ifg:  3-d matrix for the interferograms         
% OUTPUT:                                                  
%   frac: fraction of NaN pixels
%                                                       
% Hua Wang @ Uni Leeds, 13/03/2008                         
%==========================================

[nrows,ncols,nifgs] = size(ifg);

% read interferograms 
parfor i=1:nifgs
  nanmat = isnan(ifg(:,:,i));
  n=sum(sum(nanmat));
  frac(i,1)=n/nrows/ncols;
end
