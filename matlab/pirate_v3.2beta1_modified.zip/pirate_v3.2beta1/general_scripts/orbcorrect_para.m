function [ifg_orb,tiltpar]=orbcorrect_para(ifg,ifglist,orbfitpar,refpt,ifghdr)
%=====================================================================
%function [ifg_orb,tiltpar]=orbcorrect(ifg,ifglist,orbfitpar,refpt,ifghdr)
%                                                                     
% Function for orbit correction, both ifg-by-ifg method and epoch-by-epoch method are supported  
%                                                                     
% INPUT:                                                              
%   ifg:       interferograms
%   ifglist:   master/slave image list for each interferogram       
%   orbfitpar: orbital fitting parameters including:
%              degree    - degree of the polynomial for fitting orbital error   
%              lksx/lksy - looks number (x: east, y: north)                     
%              method    - orbital errors fitting method                
%                          1: ifg-by-ifg method; 2: epoch-by-epoch method       
%   ifghdr:    ifg header          
%   refpt:     coordinate of the reference point                    
%                                                                     
% OUTPUT:                                                             
%   ifg_orb:   orbital errors                                       
%   tiltpar:   tilt parameters used for orbital error simulation in pcmc_orb.m
%                                                                     
% Hua Wang @ Uni Leeds, 02/02/2008, following Juliet Biggs, 2006          
%                                                                     
% 22/10/2011 HW: move reference phase estimation to refphsest.m
% 05/08/2011 HW: change input as structurals
% 30/09/2010 HW: change reference phase as the median of the common pixels in all ifgs
% 10/08/2010 HW: moving mask outside of this function, so that atm correction can use the mask as well
% 06/10/2009 HW: add mask option
% 13/09/2009 HW: fitting all ifgs for ifg-by-ifg method
%                change reference phase offset as an optional parameter
% 09/09/2009 HW: change input argument from psize to xpsize&ypsize
% 09/08/2009 HW: added ifglist_mst to fit orbital errors using independent
%                ifgs, but forward calculation for all the ifgs.
%=====================================================================

[rows,cols,nifgs]=size(ifg);

if orbfitpar.method==2
  %get independant ifg using mst algorithm
  [ifglist_mst]=mst_kruskal(ifglist);
else
  ifglist_mst=ifglist;
end

nifgs_mst = length(ifglist_mst.id);

%% multilook interferogram 
for i=1:nifgs_mst % can't be parfor because 'looks_para' is creating new variables
  [ifg_lowres(:,:,i)]=looks_para(ifg(:,:,ifglist_mst.id(i)),orbfitpar.lksx,orbfitpar.lksy);
end

ifghdrlks = ifghdrlooks(ifghdr,orbfitpar.lksx,orbfitpar.lksy);
n_lowres=ifghdrlks.length*ifghdrlks.width;
refptlks.y=floor(refpt.y/orbfitpar.lksy);
refptlks.x=floor(refpt.x/orbfitpar.lksx);

%%observations from matrix to vector
obsv=zeros(nifgs_mst*n_lowres,1);
for j=1:nifgs_mst
  j1 = (j-1)*n_lowres+1;
  j2 = j*n_lowres;
  obsv(j1:j2,1)=reshape(ifg_lowres(:,:,j)',n_lowres,1);
end
clear ifg_lowres;

%%design matrix for orbit correction in low resolution
[B]=orbdesign(ifglist_mst,orbfitpar,ifghdrlks,refptlks);

%delete NaN data points
B(isnan(obsv)==1,:)=[];
obsv(isnan(obsv)==1,:)=[];

%calculate orbit parameters, including 2 tilt parameters for each epoch and 1 offset for each interferogram
%orbparams=B\obsv;
if orbfitpar.method==2
  orbparams=pinv(B,1.0e-6)*obsv;
else
  invNbb = inv(B'*B);
  orbparams=invNbb*(B'*obsv);
end

clear('B','obsv');

%forward calculation of all the interferograms in full resolution
[ifg_orb] = orbfwd(ifglist,orbfitpar,ifghdr,refpt,orbparams);

%calculate offset of forward ifgs by the median of original ifgs
for k=1:nifgs
  offset=nanmedian(reshape(ifg(:,:,k)-ifg_orb(:,:,k),[],1));
  ifg_orb(:,:,k)=ifg_orb(:,:,k)-offset;
end

%reshape the parameter and output
%calculate orbit parameters, without the constant offset
%used for orbital error simulation
ncoef = (orbfitpar.degree+1)*(orbfitpar.degree+2)/2-1;
ncoefline = floor((length(orbparams)-nifgs_mst)/ncoef);
tiltpar = reshape(orbparams(1:ncoefline*ncoef),ncoef,ncoefline);
tiltpar=tiltpar';
%stdtiltpar = std(tiltpar);
