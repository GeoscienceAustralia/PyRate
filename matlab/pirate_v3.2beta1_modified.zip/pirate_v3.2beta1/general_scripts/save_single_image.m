function []=save_single_image(image,ifghdr,file_name)

%=================================================================
%function[]=save_single_image(image)
%                                                                 
% Create a .dat file of a single image such as ratemap, errormap.
% Also creates a header file (*_header.txt) with coordinates that
% are used by GMT Tools when plotting *.dat file.
%                                                                 
% INPUT:                                                          
%  image:     input file (eg. outdata.stackmap)
%  ifghdr:    ifg header
%  file_name: name of image (eg. 'ratemap')
%                                                                 
% Sarah Lawrie @ GA, 24/08/2015 
%
%=================================================================

% Create separate header file
[rows,cols]=size(image);
x=[ifghdr.xfirst,ifghdr.xfirst+(cols-1)*ifghdr.xstep];
y=[ifghdr.yfirst,ifghdr.yfirst+(rows-1)*ifghdr.ystep];

width=horzcat('width:',' ',num2str(ifghdr.width));
length=horzcat('length:',' ',num2str(ifghdr.length));
x_min=horzcat('x_min:',' ',num2str(x(1)));
x_max=horzcat('x_max:',' ',num2str(x(2)));
y_min=horzcat('y_min:',' ',num2str(y(1)));
y_max=horzcat('y_max:',' ',num2str(y(2)));
x_inc=horzcat('x_inc:',' ',num2str(ifghdr.xstep));
y_inc=horzcat('y_inc:',' ',num2str(ifghdr.ystep));

fid=fopen(char(strcat(file_name,'_header.txt')),'w');
fprintf(fid, [file_name '\n']);
fprintf(fid, [width '\n']);
fprintf(fid, [length '\n']);
fprintf(fid, [x_min '\n']);
fprintf(fid, [x_max '\n']);
fprintf(fid, [y_min '\n']);
fprintf(fid, [y_max '\n']);
fprintf(fid, [x_inc '\n']);
fprintf(fid, [y_inc '\n']);
fclose(fid);

% Write image file
output_name=char(strcat(file_name,'.dat'));
writemat(char(strcat(output_name)),image);
