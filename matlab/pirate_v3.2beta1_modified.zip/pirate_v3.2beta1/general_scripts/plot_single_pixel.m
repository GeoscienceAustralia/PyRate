function[]=plot_single_pixel(ts,ifghdr,epochlist,flag,icol,irow)
%==================================================================
%function[]=plot_single_pixel(ts,ifghdr,epochlist,flag,icol,irow)
%
% Function to plot a single pixel from a time series that is selected by the user.
%                                                                  
% INPUT:                                                           
%   ts:        time series in 3D matrix (eg. outdata.tscum)
%   ifghdr:    ifg header
%   epochlist: epochlist   
%   flag:      flag for time series plot                     
%                1: plot displacements (for tscum/tsincr) 
%                2: plot velocities (for tsincr) 
%   icol/irow: column and row number (optional, can select from image)
% OUTPUT:                                                          
%   Text file with values for plotting in GMT         
%
% Sarah Lawrie @ GA, 24/09/2015
%
%==================================================================

% Set default flag if none identified
if nargin<4
  flag=1;
end

[nrows,ncols,nts]=size(ts);

% Identify pixel point from image (if not already identified)
if nargin<5
    figure
    image=ts(:,:,nts);
    h=imagesc(image);
    freezeColors(h);
    colormap(jet);
    colorbar;
    axis equal;
    axis image;
    z=double(~isnan(image));
    alpha(z);
    set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');
    fprintf('\n click pixel for time-series plot, enter to end')
    [icol,irow]=getpts(gcf);
end

% If selected from image, initial values have decimals, these need to be rounded to enable data extraction
icol=round(icol); 
irow=round(irow);

% Re-order time series columns to: num, col, row
ts=permute(ts,[3,2,1]);

% Convert epoch span into year increments
span=diff(epochlist.span); %unit in year

if flag~=1
  ts=ts./repmat(span,[1,ncols,nrows]);
end

% Plot graph
figure
npt=length(icol);
for i=1:npt
  data=ts(:,icol(i),irow(i));
  date=epochlist.span(2:nts+1);
  date(isnan(data))=[];
  data(isnan(data))=[];
  plot(date,data,'-bo','LineWidth',1,'MarkerEdgeColor','r','MarkerFaceColor','g','MarkerSize',6);
  hold on
end
axis square
grid on
hold off

% Calculate geographic coordinates for pixel
x11=ifghdr.xfirst;
y11=ifghdr.yfirst;
dx=ifghdr.xstep;
dy=ifghdr.ystep;
R=makerefmat(x11, y11, dx, dy);

%pixel coordinates
[lat,lon]=pix2latlon(R,irow,icol);

% Create text file with pixel values and coordinates (for plotting in GMT)
val_pix_title='Values to select in Matlab to replicate results (col, row):';
val_pix=horzcat(num2str(icol),',',num2str(irow));
coord_title='Pixel Coordinates (X,Y):';
coord=horzcat(num2str(lon),',',num2str(lat));
year=epochlist.span(2:nts+1);
h1='Year';
h2='Pixel_Value';
fid=fopen(char(strcat('pixel_point_values_',(num2str(icol)),'c',(num2str(irow)),'r.txt')),'w');
fprintf(fid, [val_pix_title '\n']);
fprintf(fid, [val_pix '\n']);
fprintf(fid, [coord_title '\n']);
fprintf(fid, [coord '\n']);
fprintf(fid,'%f \n','');
fprintf(fid, [ h1 ' ' h2 '\n']);
fprintf(fid, '%f %f \n', [year data]');
fclose(fid);

end





