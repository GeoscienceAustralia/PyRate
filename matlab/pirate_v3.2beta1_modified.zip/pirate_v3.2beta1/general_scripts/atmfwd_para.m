function [ifg_atm]=atmfwd_para(ifglist,dem,refpt,atmfitmethod,atmparams)
%=====================================================================
%function [ifg_atm]=atmfwd(ifglist,dem,refpt,atmfitmethod,atmparams)
%                                                                     
% Function for forward calculation of atm errors in full resolution,     
%           both ifg-by-ifg method and epoch-by-epoch method are used 
%                                                                     
% INPUT:                                                              
%   ifglist:     master/slave image list for each interferogram       
%   dem:         dem data                                             
%   refpt:       coordinate of the reference point                    
%   atmfitmethod: atm errors fitting method                
%                1: ifg-by-ifg method; 2: epoch-by-epoch method       
%   atmparams:   atm delay parameters                                 
%                                                                     
% OUTPUT:                                                             
%   ifg_atm:     topographically-correlated atm errors                
%                                                                     
% Hua Wang @ Uni Leeds, 02/02/2008, following Juliet Biggs, 2006      
%
% 10/08/1009 HW: not fitting consant offset for redundant ifgs because
%                it was not fitted, this step will be furtherly
%                considered during removing reference phase.
%=====================================================================

nifgs=length(ifglist.masnum);
nepoch = max(max([ifglist.masnum ifglist.slvnum]));

%total parameters number
if atmfitmethod==2
  ncoef = nepoch; %epoch-by-epoch method
else
  ncoef = nifgs;  %ifg-by-ifg method
end

dem = (dem-dem(refpt.y,refpt.x))/1000.0;  %using km as unit, test 30/09/2009

[rows,cols]=size(dem);
ifg_atm=zeros(rows,cols,nifgs,'single');
parfor i=1:nifgs

  %coefficient for the linear atm correction
  if atmfitmethod==2
    %master/slave image epoch, using it to determine the cofficient position
    im = ifglist.masnum(i);
    is = ifglist.slvnum(i);
    parm=atmparams(im);
    pars=atmparams(is);
    par = pars - parm;
  else
    par = atmparams(i);
  end

  %do not calculate offsets, because the offsets of the redundant ifgs are not available, 10-aug-09, HW
  %coefficients for the offsets
  %joff = ncoef+i;
  %offset = atmparams(joff);
   offset = 0;

  %atm
  ifg_atm(:,:,i) = dem*par + offset;
end
