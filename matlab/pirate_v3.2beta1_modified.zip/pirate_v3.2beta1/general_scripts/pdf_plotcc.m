function[]=pdf_plotcc(cc,epochlist,ifghdr,ifglist,ccthr)
%=================================================================
%function[]=pdf_plotcc(cc,epochlist,ifghdr,ifglist)
%                                                                 
% Create a PDF of all coherence files (assume 4x5 plot per page)
%                                                                 
% INPUT:                                                          
%  cc:        input coherence files in 3-d matrix (rows, cols, ccid)   
%  epochlist: list of epochs
%  ifghdr:    ifg header
%  ifglist:   list of ifgs
%  ccthr:     coherence threshold (optional)
%                                                                 
% Sarah Lawrie @ GA, 12/08/2015 
%
%=================================================================
opengl software
[rows,cols,ncc]=size(cc);

if nargin < 4
    ccthr=0;
end

% Parameters for subplot sizes
plotheight=30;
plotwidth=16;
subplotsx=4;
subplotsy=5;   
leftedge=0.4;
rightedge=0.4;   
topedge=1.5;
bottomedge=1.5;
spacex=0.1;
spacey=0.1;
sub_pos=subplot_pos(plotwidth,plotheight,leftedge,rightedge,bottomedge,topedge,subplotsx,subplotsy,spacex,spacey);

% Split list of ifgs and their names into 20 ifgs per page
plot_per_page=subplotsx * subplotsy;
split_ifgs(cc,epochlist,ifglist,plot_per_page)
load('split_ifgs.mat');

% Get list of split files (names and ifgs) and match them together
outStr = regexpi(data, 'names');
ind = ~cellfun('isempty',outStr);
namevars = data(ind);
assignin('base','namevars',namevars);

outStr = regexpi(data, 'sublist');
ind = ~cellfun('isempty',outStr);
ccvars = data(ind);
assignin('base','ccvars',ccvars);

cc_groups=horzcat(namevars,ccvars);
assignin('base','cc_groups',cc_groups);

% Calculate geographic coordinates
x=[ifghdr.xfirst,ifghdr.xfirst+(cols-1)*ifghdr.xstep];
y=[ifghdr.yfirst,ifghdr.yfirst+(rows-1)*ifghdr.ystep];

% Create PDF per ifg group
[group_rows,group_cols]=size(cc_groups);

for i=1:group_rows
    % Set page to A4 for printing
    f=figure('visible','off');
    clf(f);
    set(gcf, 'PaperUnits', 'centimeters');
    set(gcf, 'PaperType', 'a4');
    set(gcf, 'PaperPositionMode', 'manual');
    set(gcf, 'PaperPosition', [0 0 21 29.2]);

    % add page number to bottom for PDF
    page_no=i;
    page=num2str(page_no);
    TextBox = uicontrol('style','text');
    set(TextBox,'String',page,'Position',[270 15 5 5],'BackgroundColor',[1 1 1],'fontname','Arial','fontweight','normal','fontsize',8);

    % Create main title from file path
    file=pwd;
    [path1,track]=fileparts(file);
    [path2,pirate]=fileparts(path1);
    [path3,sensor]=fileparts(path2);
    [path4,project]=fileparts(path3);
    main_title=[project,' ',sensor,' ',track,' ',pirate,' Coherence'];
    print_title=[project,'_',sensor,'_',track,'_',pirate,'_Coherence_',page];

    % load saved name lists
    title1=cc_groups(i);
    newstring=strcat(title1,'.mat');
    mat_file=char(newstring);  
    list='listing';
    cc_name=load(mat_file,list);
    cc_name=cc_name.(list);
    
    % load saved cc files
    title2=cc_groups(i,2);
    newstring=strcat(title2,'.mat');
    mat_file=char(newstring);
    list='listing';
    cc_figs=load(mat_file,list);
    cc_figs=cc_figs.(list);

    % reorder cell array so plots start at top left corner of page
    plot_pos=cell(subplotsx,subplotsy);
    plot_pos{1}=sub_pos{17};
    plot_pos{2}=sub_pos{18};
    plot_pos{3}=sub_pos{19};
    plot_pos{4}=sub_pos{20};
    plot_pos{5}=sub_pos{13};
    plot_pos{6}=sub_pos{14};
    plot_pos{7}=sub_pos{15};
    plot_pos{8}=sub_pos{16};
    plot_pos{9}=sub_pos{9};
    plot_pos{10}=sub_pos{10};
    plot_pos{11}=sub_pos{11};
    plot_pos{12}=sub_pos{12};
    plot_pos{13}=sub_pos{5};
    plot_pos{14}=sub_pos{6};
    plot_pos{15}=sub_pos{7};
    plot_pos{16}=sub_pos{8};
    plot_pos{17}=sub_pos{1};
    plot_pos{18}=sub_pos{2};
    plot_pos{19}=sub_pos{3};
    plot_pos{20}=sub_pos{4};

    %loop to create plots
    [name_rows,name_cols]=size(cc_name);
    for ii=1:name_rows
        coords=plot_pos{ii};
        subplot('position',coords);
        imagesc(x,y,cc_figs(:,:,ii));
        set(gca,'YDir','normal');
        colormap(gray);
        colorbar('fontname','Arial','fontsize',7);
        axis equal;
        axis image;
        set(gca,'xtick',[],'xticklabel',[]);
        set(gca,'ytick',[],'yticklabel',[]);
       
        % Add ifg names to plots  
        strpair=char(cc_name(ii,:));
        title(strpair,'fontname','Arial','fontweight','normal','fontsize',7);

        % Apply coherence threshold to mask values under threshold
        temp=cc(:,:,ii);        
        if nargin > 4
            temp(temp < ccthr) = NaN;
        end
                
        % Change 0 to NaN, set alpha map for the NaN region and background
        % colour to off white
        temp(temp == 0) = NaN;
        z=double(~isnan(temp));
        alpha(z);
        set(gcf,'Color',[1 1 1]); set(gca,'Color',[0.9792 0.9180 0.8398]); set(gcf,'InvertHardCopy','off');
    end
    figtitle(main_title,'fontname','Arial','fontweight','normal','color','black','fontsize',14);
    print('-dpdf',num2str(print_title));
   
end


% join pdfs

%command = 'gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile=out.pdf in1.pdf in2.pdf';
%[status,cmdout] = system(command)

%Clean up files
delete names*.mat
delete sublist*.mat

