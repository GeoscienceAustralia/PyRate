



% extract pixel details 
icol=189;
irow=214;
for i=1:10
    plot_pixel_sq_avg(tsincr2_vert,ifghdr,epochlist,1,i,icol,irow)
end


icol=195;
irow=273;
plot_pixel_sq_avg(tsincr2_vert,ifghdr,epochlist,1,1,icol,irow)




icol=144;
irow=194;
for i=1:19
    list{i}=tscum2_vert(irow,icol,i);
end
list2=vertcat(list{:});

image2=tscum2_vert(:,:,19);
figure
h=imagesc(image2);
freezeColors(h);
colormap(jet);
colorbar;
caxis([-80,80]);
axis equal;
axis image;
z=double(~isnan(image2));
alpha(z);
set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');


% hold shift before starting to get square 
rect=getrect
xmin=rect(1)
ymin=rect(2)
width=rect(3)
height=rect(4)


hold on;


p=[128,93];
plot(p(1),p(2),'mo')
hold on;


% show all time series images as separate figures
npt=19;
for i=1:npt
    image=tscum2(:,:,i);
    figure
    h=imagesc(image);
    freezeColors(h);
    colormap(jet);
    colorbar;
    caxis([-80,80]);
    axis equal;
    axis image;
    z=double(~isnan(image));
    alpha(z);
    set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');
end

