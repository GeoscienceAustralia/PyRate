function [ext_nml] = getextnml_para(ifg_nml,ext)
%===================================================================
%function [ext_nml] = getextnml(ifg_nml,ext)
% Get namelist for the other unw files from ifg namelist
%
% INPUT:
%   ifg_nml: interferogram file namelist
%   ext: extent keyword, (default: '_basep')
%
% OUTPUT:
%   ext_nml: new file namelist
%
% Hua Wang @ Uni Leeds, 19/08/2009
%===================================================================
if nargin<2
  ext='_basep';
end

nifgs=length(ifg_nml);
parfor i=1:nifgs
  ifgfile=char(ifg_nml(i));
  ext_nml(i)=cellstr(strcat(ifgfile(1:17),ext,ifgfile(18:length(ifgfile))));
end
