function []=save_ifg_images(image_set,ifghdr,epochlist,ifglist,type,dir_name)

%=================================================================
%function[]=save_ifg_images(image_set,ifghdr,dir_name)
%                                                                 
% Create a set of .dat files for a set of images such as 
% interferograms, orbital corrections, etc. 
% Also creates a header file (*_header.txt) with coordinates that
% are used by GMT Tools when plotting the *.dat files.
% Will create directory to store images if not already created.
%  
%
% INPUT:                                                          
%  image:     input file (eg. ifg)
%  ifghdr:    ifg header
%  epochlist: list of epochs
%  ifglist:   list of ifgs
%  type:      image type (ie. 'time' or 'ifg')
%  dir_name:  directory to store images (eg. 'ifg_org_images')
%                                                                 
% Sarah Lawrie @ GA, 28/08/2015 
%
%=================================================================

% Make directory to store files
if ~exist(dir_name,'dir')
    mkdir(dir_name);
end
addpath(dir_name);

% Create separate header file
[rows,cols]=size(image_set(:,:,1));
x=[ifghdr.xfirst,ifghdr.xfirst+(cols-1)*ifghdr.xstep];
y=[ifghdr.yfirst,ifghdr.yfirst+(rows-1)*ifghdr.ystep];

width=horzcat('width:',' ',num2str(ifghdr.width));
length=horzcat('length:',' ',num2str(ifghdr.length));
x_min=horzcat('x_min:',' ',num2str(x(1)));
x_max=horzcat('x_max:',' ',num2str(x(2)));
y_min=horzcat('y_min:',' ',num2str(y(1)));
y_max=horzcat('y_max:',' ',num2str(y(2)));
x_inc=horzcat('x_inc:',' ',num2str(ifghdr.xstep));
y_inc=horzcat('y_inc:',' ',num2str(ifghdr.ystep));

fid=fopen(char(strcat(dir_name,'_header.txt')),'w');
fprintf(fid, [dir_name '\n']);
fprintf(fid, [width '\n']);
fprintf(fid, [length '\n']);
fprintf(fid, [x_min '\n']);
fprintf(fid, [x_max '\n']);
fprintf(fid, [y_min '\n']);
fprintf(fid, [y_max '\n']);
fprintf(fid, [x_inc '\n']);
fprintf(fid, [y_inc '\n']);
fclose(fid);
headerfile=char(strcat(dir_name,'_header.txt'));
movefile(headerfile,dir_name);

% Determine corresponding dates for images (ie, mas-slv ifg or epoch date)
if strcmp(type,'time')
    [num,~]=size(epochlist.date);
    name_list=num2str(epochlist.date(2:num));  
    namefile=char('date_list');
    dlmwrite(namefile,name_list,'delimiter','');
    movefile(namefile,dir_name);
else
    name_list=strcat(num2str(epochlist.date(ifglist.masnum)),'-',num2str(epochlist.date(ifglist.slvnum)));
    namefile=char('date_list');
    dlmwrite(namefile,name_list,'delimiter','');
    movefile(namefile,dir_name);
end

% Write image files
nts=size(image_set,3);
for i=1:nts
    output_name=char(strcat(dir_name,'_',num2str(i),'.dat'));
    writemat(char(output_name),image_set(:,:,i));
    movefile(output_name,dir_name);
end
  
  
