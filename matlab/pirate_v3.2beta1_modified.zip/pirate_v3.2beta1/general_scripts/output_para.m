function [] = output_para(outdata,ifghdr,ifglist,epochlist,fitmodelpar,gmtfaultfile)
%====================================================================
%function [] = output(outdata,ifghdr,ifglist,epochlist,fitmodelpar,gmtfaultfile)
% Funtion to write output files and make profiles
%
% INPUT:
%   outdata:     output data
%   ifghdr:      ifg header to get pixel size
%   ifglist:     ifg list
%   epochlist:   epoch list (optional)
%   fitmodelpar: fitted model parameters (optional)
%   gmtfaultfile: fault file in gmt format (optional)
%
% OUTPUT:
%   None
%
% Hua Wang @ Uni Leeds, 27/09/2008
%
% 21/10/2012 MG: output lat and lon for profiles and binned profiles
% 26/03/2012 HW: set lksx/y as 1 if initial model is not used
%====================================================================

load pars

%if inimodelpar.nmodels>0
%  lksx=vcmpar.lksx;
%  lksy=vcmpar.lksy;
%else
  lksx=1;
  lksy=1;
%end

%-----------------------
%wirte binary files
%-----------------------
disp('writing output files...');
writemat(char(strcat(iopar.ratemapdir,'stackmap.dat')),outdata.stackmap);
writemat(char(strcat(iopar.ratemapdir,'errormap.dat')),outdata.errormap);
writemat(char(strcat(iopar.ratemapdir,'dem.dat')),outdata.dem);
writemat(char(strcat(iopar.ratemapdir,'coh_sta.dat')),outdata.coh_sta);
if isfield(outdata,'ratemap')
  writemat(char(strcat(iopar.ratemapdir,'ratemap.dat')),outdata.ratemap);
  writemat(char(strcat(iopar.ratemapdir,'resmap.dat')),outdata.resmap);
end
hdr2rsc(ifghdr,char(strcat(iopar.ratemapdir,'ifg.rsc'))); %write rsc file, 12/04/2011, HW

save(char(strcat(iopar.auxdir,'ifglist.mat')),'ifglist');
save(char(strcat(iopar.auxdir,'epochlist.mat')),'epochlist');

%time series
if tspar.tscal==1
  nts=size(outdata.tsincr,3);
  parfor i=1:nts
    incrfile=strcat(iopar.tsdir,'tsincr_',num2str(epochlist.date(i+1)),'.dat');
    cumfile=strcat(iopar.tsdir,'tscum_',num2str(epochlist.date(i+1)),'.dat');
    writemat(char(incrfile),outdata.tsincr(:,:,i));
    writemat(char(cumfile),outdata.tscum(:,:,i));
    if ~isempty(outdata.tserr)
      errorfile=strcat(iopar.tsdir,'tserr_',num2str(epochlist.date(i+1)),'.dat');
      writemat(char(errorfile),outdata.tserr(:,:,i));
    end
  end
  hdr2rsc(ifghdr,char(strcat(iopar.tsdir,'ifg.rsc')));
end

%-----------------------
% calculating profiles
%-----------------------
if profflag ~= 1
  return
end

%make folder for profiles
ma=mean(ifglist.alpha);

%extract profiles, and save it to the current directory
profdef=char('profdef.dat');
if ~exist(profdef,'file')
  %[fault]=gmt2mat_faults(char(gmtfaultfile));
  plotifg(outdata.stackmap,0,'stackmap',0,ifghdr);
  extractprof(prof.swath,prof.step);
end
[prof]=profdefine(profdef);
nprof=length(prof);

%multi-look processing
[ifghdr_lowres]=ifghdrlooks(ifghdr,lksx,lksy);

%stackmap profile
display('calculating profile of stackmap ...');
[stackmap_lowres]=looks_para(outdata.stackmap,lksx,lksy);
[errormap_lowres]=looks_para(outdata.errormap,lksx,lksy);
parfor i=1:nprof
    if prof(i).conv==1
        % get direction perpendicular to profile azimuth - i.e. fault azimuth
       ang=atan2((prof(i).y1-prof(i).y0),(prof(i).x1-prof(i).x0));
       %faz=(ang-(pi/2));
       if ang<0
           faz=abs(ang);
       elseif ang>0
           faz=pi-ang;
       end
       [stackmap_conv,errormap_conv]=convert_LOS(stackmap_lowres,errormap_lowres,faz);
    else 
        stackmap_conv=stackmap_lowres;
        errormap_conv=errormap_lowres;
    end
  [prof_stack,stackprof]=make_prof(stackmap_conv,prof(i),ifghdr_lowres,errormap_conv,1);
  % save all points within swath
  fid = fopen(char(strcat(iopar.profdir,'stack.prof_',num2str((i)),prof(i).id)),'w');
  fprintf(fid,'distance \t lon \t lat \t rate \t sig_rate \n');
  fprintf(fid,'%-6.2f %-6.2f %-6.2f %-6.2f %-6.2f \n',stackprof');
  fclose(fid);
  % save binned profile
  fid = fopen(char(strcat(iopar.profdir,'stack.prof_points_',num2str((i)),prof(i).id)),'w');
  fprintf(fid,'par_dist \t perp_dist \t lon \t lat \t rate \t sig_rate \n');
  fprintf(fid,'%-6.2f %-6.2f %-6.2f %-6.2f %-6.2f %-6.2f \n',prof_stack');
  fclose(fid);
end

%plotstack(outdata.stackmap,prof_stack,stackprof,2);

%ratemap profile
if isfield(outdata,'ratemap')
  display('calculating profile of ratemap ...');
  [ratemap_lowres]=looks_para(outdata.ratemap,lksx,lksy);
  parfor i=1:nprof
    [prof_stack,rateprof]=make_prof(ratemap_lowres,prof(i),ifghdr_lowres,errormap_lowres,1);
    fid = fopen(char(strcat(iopar.profdir,'rate.prof',prof(i).id)),'w');
    fprintf(fid,'distance \t lon \t lat \t rate \t sig_rate \n');
    fprintf(fid,'%-6.2f %-6.2f %-6.2f %-6.2f %-6.2f \n',rateprof');
    fclose(fid);
    %plotstack(ratemap,prof_stack,rateprof,1);
  end
end

% model profile
if inimodelpar.nmodels>0
  display('calculating profile of model ...');

  %fmodel=zeros(size(ratemap_lowres));
  for j=1:inimodelpar.nmodels
    imodel=looks_para(inimodelpar.fmodel(:,:,j),lksx,lksy);
    fmodel=imodel*inimodelpar.rate(j);
  %end
  %fmodel(isnan(ratemap_lowres))=NaN;
    parfor i=1:nprof
      prof(i).step=1;
      prof(i).swath=5;
      prof(i).overlap=1;
      [prof_stack,modelprof]=make_prof(fmodel,prof(i),ifghdr_lowres);
      fid = fopen(char(strcat(iopar.profdir,'model',num2str(j),'.prof_',num2str((i)),prof(i).id)),'w');
      fprintf(fid,'distance \t lon \t lat \t model \t sig_model \n');
      fprintf(fid,'%-6.2f %-6.2f %-6.2f %-6.2f %-6.2f\n',modelprof');
      fclose(fid);
    end
  end
end

%dem profile
if atmfit==1 || shpdemest==1
  display('calculating profile of dem ...');
  parfor i=1:nprof
    prof(i).step=1;
    prof(i).swath=1;
    prof(i).overlap=1;
    [prof_stack,demprof]=make_prof(outdata.dem,prof(i),ifghdr);
    fid = fopen(char(strcat(iopar.profdir,'dem.prof_',num2str((i)),prof(i).id)),'w');
    fprintf(fid,'distance \t lon \t lat \t topo \t sig_topo \n');
    fprintf(fid,'%-6.2f %-6.2f %-6.2f %-6.2f %-6.2f \n',demprof');
    fclose(fid);
  end
end
