function [decor]=decor_time_para(cc,ifglist,model,ccthr)
%==================================================================
%function [decor]=decor_time(cc,ifglist,model,ccthr)
%
% Function to do pixel-by-pixel temporal decorrelation analysis on a stack of
% interferometric coherence images
%                                                                  
% INPUT:                                                           
%   decor: structure containing results of temporal decorrelation analysis
%   cc: coherence images
%   ifglist: ifglist structure containing ifm timespans
%   model: model to fit 1: exp(-a*t) 2: exp(-a*t+b)
%   ccthr: coherence threshold to determine decorrelation time
% OUTPUT:                                                          
%   decor.tdc: temporal decorrelation time map
%   decor.rsq: R^2 statistic map (pseudo-error map)
%   decor.a:   'a' parameter of exponential model
%   decor.b:   'b' parameter of exponential model (if applicable)
%   decor.avgcc: pixel-by-pixel average coherence map
%   decor.model: model applied
%                                                                  
% Matt Garthwaite @ GA, 6/08/2015                                
%==================================================================

% convert nans to zeros to be ignored by analysis
cc(isnan(cc))=0;

[len wid ncc]=size(cc);

sumcc=zeros(len,wid);
tdc=sumcc;
rsq=sumcc;
%rsq1=sumcc;
%a1=sumcc;
a=sumcc;
b=sumcc;

% generate average coherence across all interferograms
parfor n=1:ncc
  sumcc=sumcc+cc(:,:,n);
end

avgcc=sumcc./ncc;

ccp=permute(cc,[3 1 2]);

parfor i=1:len
    if mod(i,10)==0
            fprintf('analysing temporal decorrelation for the %d/%-d line\n',i,len);
    end
    for j=1:wid        
        
        %only do analysis for pixels with average coherence not equal to
        %zero, e.g. not sea areas
        if avgcc(i,j)~=0
            cor=ccp(:,i,j);
            t=round(ifglist.BaseT*365.25);
            t(cor==0)=[];
            cor(cor==0)=[];
            
            data=[t cor];
            [vals ind]=sort(data,1);
            data=data(ind(:,1),:);
            data=double(data);

            tmod=1:11000; % approx 30 years
            %options = optimset('MaxFunEvals',5000,'MaxIter',1000);
            options = optimoptions('fmincon','Display','off');
            %% calculate best fit function maxvar*exp(-alpha*r)
            if model==1
                out = fminsearch(@(x) tempdecorexp(x,data,model),[0.1],options);
                a(i,j)=out;
                fit=exp(-out.*data(:,1));
                rsq(i,j)=rsquared(data(:,2),fit);
                cormod=exp(-out.*tmod);
            elseif model==2
                %out = fminsearch(@(x) tempdecorexp(x,data,model),[0.1 0],options);
                out = fmincon(@(x) tempdecorexp(x,data,model),[0.01 0],[],[],[],[],[0,0],[0.1,1],[],options);
                %fun=@(x)norm(data(:,2) - (exp(-var(1).*data(:,1))+var(2)));
                %out = lsqnonlin(@(x) tempdecorexp(x,data,model),[0.1,0],[0,0],[100,1]);
                a(i,j)=out(1);
                b(i,j)=out(2);
                fit=exp(-out(1).*data(:,1))+out(2);
                rsq(i,j)=rsquared(data(:,2),fit);
                cormod=exp(-out(1).*tmod)+out(2);
            elseif model==3
                out = fminsearch(@(x) tempdecorexp(x,data,model),[0.1],options);
                a(i,j)=out;
                fit=exp(-out(1).*(data(:,1).^2));
                rsq(i,j)=rsquared(data(:,2),fit);
                cormod=exp(-out(1).*(tmod.^2));
            else
                error('ERROR: not such options!');
            end
            
            tmod(cormod>ccthr)=[];
            %if i==114 && j==63
            %fprintf(' i j: %d %d\n',i,j);
            %end
            
            %% test for pixels where model is not sensible
            if out(1)<0 || isempty(tmod)                
                tdc(i,j)=NaN;
            else
                tdc(i,j)=min(tmod);                
            end
                        
        end
        
    end
end

tdc(tdc==0)=NaN;
rsq(rsq==0)=NaN;
%rsq1(rsq1==0)=NaN;
%a1(a1==0)=NaN;
a(a==0)=NaN;
b(b==0)=NaN;

decor.tdc=tdc;
decor.rsq=rsq;
decor.a=a;
decor.b=b;
decor.avgcc=avgcc;
decor.model=model;
