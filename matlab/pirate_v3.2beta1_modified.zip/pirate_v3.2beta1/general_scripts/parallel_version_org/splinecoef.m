function [A,base,breaks,dA] = splinecoef(x,pieces,n,periodic)
%=====================================================
% Function to make design matrix of LS spline fitting
%
% Input:
%   x:          Noisy data x-locations (1 x mx)
%   pieces:     pieces of polynomial coefficients
%   n:          Spline order
%   periodic:   periodic boundary conditions
%
% Output:
%   A: design matrix for the given x
%   base: basis of the spline function
%   breaks: breaks
%   dA: second deviation of A
%
% Hua Wang, 19/07/2011
%
% based on splinefit function copyrighted by 
% jonas.lundgren@saabgroup.com, 2010.
%=====================================================

if nargin<3
  n = 4;        % Cubic splines
end
if nargin<4
  periodic = 0; % Not use periodic boundary conditions
end

% Interpolate breaks linearly from x-data
mx=length(x);
x=reshape(x,1,mx);
dx = diff(x);
ibreaks = linspace(1,mx,pieces+1);
[junk,ibin] = histc(ibreaks,[0,2:mx-1,mx+1]); %#ok
breaks = x(ibin) + dx(ibin).*(ibreaks-ibin);

%=========================
% design matrix
%=========================
base = splinebase(breaks,n);
A = ppval(base,x);

%second deviation of base
dbase = ppdiff(base,2);
dA = ppval(dbase,x);

% Bin data
[junk,ibin] = histc(x,[-inf,breaks(2:end-1),inf]); %#ok

% Sparse system matrix
ii = [ibin; ones(n-1,mx)];
ii = cumsum(ii,1);
jj = repmat(1:mx,n,1);
if periodic
  ii = mod(ii-1,pieces) + 1;
  A = sparse(ii,jj,A,pieces,mx);  
  dA = sparse(ii,jj,dA,pieces,mx);
  
else
  A = sparse(ii,jj,A,pieces+n-1,mx);
  dA = sparse(ii,jj,dA,pieces+n-1,mx);
end

% Don't use the sparse solver for small problems
if pieces < 20*n/log(1.7*n)
  A = full(A);
  dA = full(dA);
end
A=A';
dA=dA';

%--------------------------------------------------------------------------
function pp = splinebase(breaks,n)
%SPLINEBASE Generate B-spline base PP of order N for breaks BREAKS

breaks = breaks(:);     % Breaks
breaks0 = breaks';      % Initial breaks
h = diff(breaks);       % Spacing
pieces = numel(h);      % Number of pieces
deg = n - 1;            % Polynomial degree

% Extend breaks periodically
if deg > 0
    if deg <= pieces
        hcopy = h;
    else
        hcopy = repmat(h,ceil(deg/pieces),1);
    end
    % to the left
    hl = hcopy(end:-1:end-deg+1);
    bl = breaks(1) - cumsum(hl);
    % and to the right
    hr = hcopy(1:deg);
    br = breaks(end) + cumsum(hr);
    % Add breaks
    breaks = [bl(deg:-1:1); breaks; br];
    h = diff(breaks);
    pieces = numel(h);
end

% Initiate polynomial coefficients
coefs = zeros(n*pieces,n);
coefs(1:n:end,1) = 1;

% Expand h
ii = [1:pieces; ones(deg,pieces)];
ii = cumsum(ii,1);
ii = min(ii,pieces);
H = h(ii(:));

% Recursive generation of B-splines
for k = 2:n
    % Antiderivatives of splines
    for j = 1:k-1
        coefs(:,j) = coefs(:,j).*H/(k-j);
    end
    Q = sum(coefs,2);
    Q = reshape(Q,n,pieces);
    Q = cumsum(Q,1);
    c0 = [zeros(1,pieces); Q(1:deg,:)];
    coefs(:,k) = c0(:);
    % Normalize antiderivatives by max value
    fmax = repmat(Q(n,:),n,1);
    fmax = fmax(:);
    for j = 1:k
        coefs(:,j) = coefs(:,j)./fmax;
    end
    % Diff of adjacent antiderivatives
    coefs(1:end-deg,1:k) = coefs(1:end-deg,1:k) - coefs(n:end,1:k);
    coefs(1:n:end,k) = 0;
end

% Scale coefficients
scale = ones(size(H));
for k = 1:n-1
    scale = scale./H;
    coefs(:,n-k) = scale.*coefs(:,n-k);
end

% Reduce number of pieces
pieces = pieces - 2*deg;

% Sort coefficients by interval number
ii = [n*(1:pieces); deg*ones(deg,pieces)];
ii = cumsum(ii,1);
coefs = coefs(ii(:),:);

% Make piecewise polynomial
pp = mkpp(breaks0,coefs,n);
