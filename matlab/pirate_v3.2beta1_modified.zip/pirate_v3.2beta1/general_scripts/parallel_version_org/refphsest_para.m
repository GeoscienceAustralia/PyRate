function[refphs,ifg]=refphsest_para(ifg,refpar,refpt)
%=======================================================
%function[refphs,ifg]=refphsest(ifg,refpar,refpt)
%                                                                    
% Estimate reference phase for interferograms
%
% INPUT:
%   ifg:  input interferograms
%   refpar: reference phase estimation parameters, including
%     refest - estimation method (1: average of the whole image; 2: average of a patch around the refpt)
%     chipsize - window size to calculate reference phase (optional, only used if refest=2)
%     minfrac - minimum fraction of coherent pixels (optional, only used if refest=2)
%   refpt: reference point coordinate (optional, only used if refest=2)
%
% OUTPUT:
%   refphs: output reference phase
%   ifg: ifg after removal of reference phase
%
% Hua Wang @ Uni Leeds, 04/03/2008
%
% 22/10/2011 HW: estimate reference phase by the average of the whole image
%======================================================
nifgs=size(ifg,3);
refphs=zeros(nifgs,1);
%set reference phase as the average of the whole image (recommended)
if refpar.refest==1
  comp=isnan(sum(ifg,3));  %find valid pixels in all ifgs
  comp=reshape(comp,[],1);
  parfor i=1:nifgs
    ifgv=reshape(ifg(:,:,i),[],1);
    ifgv(comp==1)=[];

    %reference phase
    refphs(i)=nanmedian(ifgv);
  end

%set reference phase as the average of the patch surrounding the reference point
else
  psz=floor(refpar.chipsize/2);
  chipsize=2*psz+1;
  thr = chipsize*chipsize*refpar.minfrac;

  parfor i=1:nifgs
    patch=ifg(refpt.y-psz:refpt.y+psz,refpt.x-psz:refpt.x+psz,i);
    patch=reshape(patch,[],1);
    patch(isnan(patch))=[];    %get a patch around the reference point
    
    %valid pixel number within the patch
    if length(patch)<thr
      error('the reference pixel is not in high coherent area!'); 
    end

    %reference phase
    refphs(i)=median(patch);
  end
end

%remove reference phase
if nargout>1
  parfor i=1:nifgs
    ifg(:,:,i)=ifg(:,:,i)-refphs(i);
  end
end
