function[ifg]=readifgs_para(obsdir,ifg_nml,rows,cols,talk) 
%==========================================================
%function[ifg]=readifgs(obsdir,ifg_nml,rows,cols,talk) 
%                                                          
% Read multiple interferograms from a folder    
%                                                          
% INPUT:                                                   
%   obsdir:  directory of input interferograms             
%   ifg_nml: namelist of input interferograms              
%   rows: rows of input interferogram                      
%   cols: cols of input interferogram                      
%   talk: display processing information (default 1: display, 0: no)
% OUTPUT:                                                  
%   ifg:  output 3-d matrix for the interferograms         
%                                                          
% Hua Wang @ Uni Leeds, 13/03/2008                         
%
% 01/08/2011 HW: out of date, prepifg has reading function
%==========================================================

nifgs = length(ifg_nml);

if nargin<5
  talk=1;
end

parfor i=1:nifgs
  if talk==1
    fprintf('reading data: %3d/%-3d - %s ...\n',i,nifgs,char(ifg_nml(i)));
  end
  ifgname = char(strcat(obsdir,ifg_nml(i)));
  ifg(:,:,i)=readmat(ifgname,rows,cols,1);
end
