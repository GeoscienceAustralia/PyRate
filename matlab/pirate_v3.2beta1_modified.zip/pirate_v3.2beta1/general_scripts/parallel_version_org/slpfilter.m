function [out] = slpfilter(ifg,lppar,xpsize,ypsize)
%====================================================
%function [out] = slpfilter(ifg,lppar,xpsize,ypsize)
% spatial low pass filter
%
% INPUT:
%   ifg: input interferogram
%   lppar: a structure of low-pass filter parameters, including method/cutoff/order
%          method - filter method (default 1: butterworth; 2: Gaussian)
%          cutoff - cutoff distance in the same unit with pixel size (default km)
%          order - Butterworth filter order: >=1 (Default: 1)
%   xpsize: pixel size in x direction (unit: km)
%   ypsize: pixel size in y direction (unit: km)
%
% OUTPUT:
%   out: filtered interferogram
%
% Hua Wang, 13/08/2010
%
% 05/01/2012 HW: fix a bug for filtering a pure NaN matrix
%====================================================

%return for NaN matrix, 05/01/2012 HW
if nnz(~isnan(ifg))==0
  out=ifg;
  return
end

if lppar.cutoff==0
  [maxvar,alpha] = make_vcm_para(ifg,xpsize,ypsize);
  lppar.cutoff=1/alpha;
end

%find the center of the image
[rows,cols] = size(ifg);
cx = floor(cols/2)+1;  
cy = floor(rows/2)+1;

%fft for the input image
%im=fillnan(ifg);
im=inpaint_nans(double(ifg),2);
%im=fillnan_interp(ifg,'linear');
%im(isnan(im))=0;
imf=fftshift(fft2(im));

%calculate distance
[xx,yy] = meshgrid(1:cols,1:rows) ;
xx=(xx-cx)*xpsize;
yy=(yy-cy)*ypsize;
d=sqrt(yy.^2+xx.^2);

if lppar.method==1
  %butterworth low pass filter
  H=1./(1+((d./lppar.cutoff).^(2*lppar.order)));
else
  %Gaussian lowpass filter
  H = exp(-(d.^2)/(2*lppar.cutoff^2));
end

outf = imf .* H;
out = real(ifft2(ifftshift(outf)));
out(isnan(ifg))=nan;
