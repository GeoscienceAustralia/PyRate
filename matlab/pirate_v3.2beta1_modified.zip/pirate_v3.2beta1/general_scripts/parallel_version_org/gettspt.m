function [] = gettspt(infile,outdir)
%========================================
% function [] = gettspt(infile,outdir)
%   Get time series for the given points
%
% Input:
%   infile: input file contains the row/col of the given points
%           (col,row,name)
%
% Output:
%   None
%
% Hua Wang, 30/03/2012
%========================================

[col,row,ptname]=textread(infile,'%d %d %s');

load(char(strcat(outdir,'aux/epochlist.mat')));

%read ts
ifghdr=rsc2hdr(strcat(outdir,'ratemap/ifg.rsc'));
nts=length(epochlist.date)-1;
ts=zeros(ifghdr.length,ifghdr.width,nts);
tserr=zeros(ifghdr.length,ifghdr.width,nts);
for i=1:nts
  tsfile = strcat(outdir,'timeseries/tscum_',num2str(epochlist.date(i+1)),'.dat');
  ts(:,:,i)=readmat(tsfile,ifghdr.length,ifghdr.width,1);
  tserrfile = strcat(outdir,'timeseries/tserr_',num2str(epochlist.date(i+1)),'.dat');
  tserr(:,:,i)=readmat(tserrfile,ifghdr.length,ifghdr.width,1);
end

%read stackmap and errormap
stackfile = strcat(outdir,'ratemap/stackmap.dat');
stackmap=readmat(stackfile,ifghdr.length,ifghdr.width,1);
errmapfile = strcat(outdir,'ratemap/errormap.dat');
errormap=readmat(errmapfile,ifghdr.length,ifghdr.width,1);

npt = length(row);
for i=1:npt
  irow=row(i);
  icol=col(i);
  ilon=ifghdr.xfirst+(icol-1)*ifghdr.xstep;
  ilat=ifghdr.yfirst+(irow-1)*ifghdr.ystep;
  its=ts(irow,icol,:); 
  its=permute(its,[3,1,2]);
  itserr=tserr(irow,icol,:); 
  itserr=permute(itserr,[3,1,2]);

  %fitted data
  A=epochlist.span(2:nts+1);
  d=its;
  v=A\d;
  %fitcum = stackmap(irow,icol)*epochlist.span(2:nts+1);
  fitcum = v*A;

  %ofile=char(strcat(outdir,'/timeseries/',ptname(i),'.ts'));
  ofile=char(strcat(ptname(i),'.ts'));
  fid=fopen(ofile,'w');
  fprintf(fid,'%d %d %f %f %f %f %f \n',icol,irow,ilon,ilat,stackmap(irow,icol),errormap(irow,icol),v);
  for j=1:nts
    fprintf(fid,'%s %f %f %f %f\n',num2str(epochlist.date(j+1)),its(j),itserr(j),fitcum(j),its(j)-fitcum(j));
  end
  fclose(fid);

  %fit annual and semi-annual terms
  res=its-fitcum;
  T=[sin(4*pi*A) cos(4*pi*A) sin(2*pi*A) cos(2*pi*A) ones(length(A),1)];
  tscoef=T\res;
  dT=[0:0.1:epochlist.span(nts+1)]';
  T=[sin(4*pi*dT) cos(4*pi*dT) sin(2*pi*dT) cos(2*pi*dT) ones(length(dT),1)];
  cycfit=T*tscoef;

  ofile=char(strcat(ptname(i),'.tscyc'));
  fid=fopen(ofile,'w');
  %fprintf(fid,'%f %f %f %f %f\n',tscoef(1),tscoef(2),tscoef(3),tscoef(4),tscoef(5));
  dTstr=datestr(datenum(num2str(epochlist.date(1)),'yyyymmdd')+round(dT*365.25),'yyyymmdd');
  for j=1:length(dT)
    fprintf(fid,'%s %f\n',dTstr(j,:),cycfit(j));
  end
  fclose(fid);
end
