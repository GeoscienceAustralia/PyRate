function [stepincr,ifg] = maskeq(ifg,ifglist,epochlist,eqlistfile)
%=====================================================================
%function [stepincr,ifg] = maskeq(ifg,ifglist,epochlist,eqlistfile)
%                                                                     
%Function to mask co-/post-seismic deformation area
%                                                                     
% INPUT:                                                              
%   ifg:         interferograms
%   ifglist:     master/slave image list for each interferogram       
%   epochlist:   epochlist
%   eqlistfile:  filename for earthquake date list (e.g. 20080230 \n 20090101)                                 
%                                                                     
% OUTPUT:                                                             
%   stepincr:    step flag for each incremental (1: step; 0: no step)
%   ifg:         masked ifg (optional)
%                                                                     
% Hua Wang @ GDUT, 22/03/2010
%=====================================================================
if isempty(eqlistfile)
  stepincr=[];
  ifg=[];
  return
end

%eqdate: earthquake epoch
%doff: date offset (sometimes sar has the same epoch with the earthquake)
%       1 - earthquake was later than sar;
%      -1 - earthquake was earlier than sar;
%       0 - earthquake and sar were not the same date;
%psmask: mask postseismic deformation (default 0: not mask; 1: mask)
[eqdate doff psmask] = textread(eqlistfile,'%d %d %d');
neqs = length(eqdate);
nifgs=size(ifg,3);
if ~exist('mask','dir')
  mkdir('mask');
end

%make mask file
for ieq = 1:neqs
  maskfile = strcat('mask/eqmask_',num2str(eqdate(ieq)),'.mat');
  if ~exist(maskfile,'file')~=0
    %find proper coseismic ifg
    for i=1:nifgs
      masdate=epochlist.date(ifglist.masnum(i));
      slvdate=epochlist.date(ifglist.slvnum(i));
      if (masdate-eqdate(ieq)-doff(ieq))*(slvdate-eqdate(ieq)-doff(ieq))<0  %coseismic pair
        break;
      end
    end
    %plot the first if no coseismic pair exist
    if i==nifgs+1  
      i=1;
    end
    plotifg(wrap(ifg(:,:,i)));
    [eqmask]=removearea;
    close(gcf);
    save(maskfile,'eqmask')
  end
end

%mask coseismic and postseismic area
maskmat=zeros(size(ifg),'uint8');
for ieq=1:neqs
  maskfile = strcat('mask/eqmask_',num2str(eqdate(ieq)),'.mat');
  load(maskfile);
  for i=1:nifgs
    masdate=epochlist.date(ifglist.masnum(i));
    slvdate=epochlist.date(ifglist.slvnum(i));
    if psmask(ieq)==1
      %mask post/co-seismic deformation
      if (masdate > eqdate(ieq)+doff(ieq)) || (slvdate > eqdate(ieq)+doff(ieq))
        imask=zeros(size(eqmask),'uint8');
        imask(isnan(eqmask))=1;
        imask(maskmat(:,:,i)==1)=1; %keep previous masks
        maskmat(:,:,i)=imask;
      end
    else
      %mask coseismic only
      if (masdate-eqdate(ieq)-doff(ieq))*(slvdate-eqdate(ieq)-doff(ieq))<0
        imask=zeros(size(eqmask),'uint8');
        imask(isnan(eqmask))=1;
        imask(maskmat(:,:,i)==1)=1; %keep previous masks
        maskmat(:,:,i)=imask;
      end
    end
  end
end

%set step flag for each epoch
nincrs=length(epochlist.date)-1;
stepincr=zeros(1,nincrs,'uint8');
for i=1:nincrs
  for ieq=1:neqs
    if (epochlist.date(i)<eqdate(ieq)+doff(ieq) & epochlist.date(i+1)>eqdate(ieq)+doff(ieq))
      stepincr(i)=1;
    end
  end
end
if nnz(stepincr)==0
  stepincr=[];
end

if nargout>1
  ifg(maskmat==1)=nan;
end
