function [prof] = profdefine(filename)
%===============================================================
%function [prof] = profdefine(filename)
%                                                                       
% Function to read profile coordinates from a text file
%                                                                       
% INPUT:                                                     
%   filename: filename whose format is defined as following:
%             profile no.   x0     y0     x1     y1  swath  step overlap conv id
%        e.g.   1         79.07  30.70  81.87  37.83  0.5    0 1 0 T248
%               2         78.57  31.59  80.15  37.83  0.5    0 2 0 T291
%               3         79.45  30.06  77.42  38.09  0.5    0 3 1 T012
%   ifghdr: ifg header (optional)
%
% OUTPUT:
%   prof: structure of profile (x0,y0,x1,y1,swath,step,overlap,conv,id)
%
% 14/10/2012 MCG added flag for converting LOS values to profile
% perpendicular values
% 4/11/2012 MCG added overlap parameter for overlapping profile bins
% Hua Wang @ Uni Leeds, 12/11/2009
%===============================================================

[number x0 y0 x1 y1 swath step overlap conv id]=textread(filename,'%d %f %f %f %f %f %f %f %f %s');
nprof = length(number);
for i=1:nprof
  prof(i).x0=x0(i);
  prof(i).y0=y0(i);
  prof(i).x1=x1(i);
  prof(i).y1=y1(i);
  prof(i).swath=swath(i);
  prof(i).step=step(i);
  prof(i).overlap=overlap(i);
  prof(i).conv=conv(i);
  prof(i).id=id(i);
end
