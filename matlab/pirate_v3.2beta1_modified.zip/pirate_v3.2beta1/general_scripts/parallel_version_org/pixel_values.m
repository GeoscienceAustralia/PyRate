% This script is based on gettspt.m and produces data files required for
% plotting pixel data in GMT Tools.

% For plotting in GMT Tools, the Y value for each pixel value must be subtracted
% from the total image length. This is due to the Y axis in Matlab starting 
% at the bottom left corner, while in GMT it starts at the top left corner.

% Files created are: pixel_#.ts (pixel values), pixel_coord_#.ts
% (correct coordinates for plotting), and epoch_span.txt (epochs in yrs for X axis).

function [] = pixel_values(infile,iopar,outdata)
%========================================
% function [] = pixel_values(infile,outdir)
%   Get incremental time series and velocity values for the given points.
%   Get coordinates of pixels for plotting in GMT Tools.
%   Get list of epochs in years.
%
% Input:
%   infile: input file contains the row/col of the given points
%   (pixels.list)
%           (col,row,pixel number)
%
% Output:
%   None
%
% Sarah Lawrie, 08/05/2013
%========================================

outdir=iopar.outdir;
infile='pixels.list';
map=outdata.stackmap;

% read pixel locations
[col,row,ptnum]=textread(infile,'%d %d %d');

% convert pixel locations to get correct coordinates for GMT Tools (creates
% new list)
row2=length(map)-row;
dlmwrite('pixel_coords.list',[col row2 ptnum],'delimiter', '\t');

% read pixel locations for coordinates
[col,row2,ptnum]=textread('pixel_coords.list','%d %d %d');

% read epoch list
load(char(strcat(iopar.auxdir,'epochlist.mat')));

%read ts
ifghdr=rsc2hdr(strcat(iopar.ratemapdir,'ifg.rsc'));
nts=length(epochlist.date)-1;
ts=zeros(ifghdr.length,ifghdr.width,nts);
tserr=zeros(ifghdr.length,ifghdr.width,nts);
for i=1:nts
  tsfile = strcat(iopar.tsdir,'tscum_',num2str(epochlist.date(i+1)),'.dat');
  ts(:,:,i)=readmat(tsfile,ifghdr.length,ifghdr.width,1);
  tserrfile = strcat(iopar.tsdir,'tserr_',num2str(epochlist.date(i+1)),'.dat');
  tserr(:,:,i)=readmat(tserrfile,ifghdr.length,ifghdr.width,1);
end

%read stackmap and errormap
stackfile = strcat(iopar.ratemapdir,'stackmap.dat');
stackmap=readmat(stackfile,ifghdr.length,ifghdr.width,1);
errmapfile = strcat(iopar.ratemapdir,'errormap.dat');
errormap=readmat(errmapfile,ifghdr.length,ifghdr.width,1);

npt = length(row);
for i=1:npt
  irow=row(i);
  icol=col(i);
  ilon=ifghdr.xfirst+(icol-1)*ifghdr.xstep;
  ilat=ifghdr.yfirst+(irow-1)*ifghdr.ystep;
  its=ts(irow,icol,:); 
  its=permute(its,[3,1,2]);
  itserr=tserr(irow,icol,:); 
  itserr=permute(itserr,[3,1,2]);

  %fitted data
  A=epochlist.span(2:nts+1);
  d=its;
  v=A\d;
  %fitcum = stackmap(irow,icol)*epochlist.span(2:nts+1);
  fitcum = v*A;

  %ofile=char(strcat(outdir,'/timeseries/',ptname(i),'.ts'));
  ofile=char(strcat('pixel_',num2str(ptnum(i)),'.ts'));
  fid=fopen(ofile,'w');
  fprintf(fid,'%d %d %f %f %f %f %f \n',icol,irow,ilon,ilat,stackmap(irow,icol),errormap(irow,icol),v);
  for j=1:nts
    fprintf(fid,'%s %f %f %f %f\n',num2str(epochlist.date(j+1)),its(j),itserr(j),fitcum(j),its(j)-fitcum(j));
  end
  fclose(fid);
end

% calculate coordinates from pixel_coords.list
for i=1:npt
  irow2=row2(i);
  icol2=col(i);
  ilon2=ifghdr.xfirst+(icol2-1)*ifghdr.xstep;
  ilat2=ifghdr.yfirst+(irow2-1)*ifghdr.ystep;

  ofile=char(strcat('pixel_',num2str(ptnum(i)),'_coords.ts'));
  fid=fopen(ofile,'w');
  fprintf(fid,'%d %d %f %f \n',icol2,irow2,ilon2,ilat2);
  fclose(fid);  
end

% create a list of the epoch span
span=epochlist.span;
out =[span];
file=char(strcat('epoch_span.txt'));
dlmwrite(file,out,' ');




