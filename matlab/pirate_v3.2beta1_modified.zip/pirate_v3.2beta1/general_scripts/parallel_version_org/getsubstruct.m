function[substruct] = getsubstruct(fullstruct,rec)
%======================================================
%function[substruct] = getsubstruct(fullstruct,rec)
%                                                                    
% Get subset from a struct variable
%
% INPUT
%   fullstruct: full structure variable
%   rec: the record numbers which will be selected
%
% OUTPUT
%   substruct: subset of the structure
% 
% Hua WANG, 13/08/2009
%======================================================

names = fieldnames(fullstruct);
nfields = length(names);
substruct=[];
for i=1:nfields
  ifield = char(names(i));
  substruct.(ifield)=fullstruct.(ifield)(rec);
end

