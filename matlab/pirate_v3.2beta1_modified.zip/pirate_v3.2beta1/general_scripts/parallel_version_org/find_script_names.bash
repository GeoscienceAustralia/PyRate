#!/bin/bash


list=list2
list2=para_list2

output=results2.txt
echo "Script" > temp1
echo "Found" > temp2
paste temp1 temp2 > $output

while read script; do
    while read find; do
	search_in_script=$script.m
	search_for=$find
	if grep -Fq "$search_for" $search_in_script
	then
	    echo $search_in_script > temp4
	    echo $search_for > temp5
	    paste temp4 temp5 >> $output
	else
	    :
	fi
    done < $list2
done < $list


while read script; do
    search_in_script=$script.m
    search_for=refpixel
    if grep -Fq "$search_for" $search_in_script
    then
	echo $search_in_script > temp4
	echo $search_for > temp5
	paste temp4 temp5 >> $output
    else
	:
    fi
done < $list

rm -f temp1 temp2 temp3 temp4 temp5