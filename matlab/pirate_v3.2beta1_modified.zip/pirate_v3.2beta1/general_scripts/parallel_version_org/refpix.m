function[refpt]=refpixel(ifg,refpar)
%====================================================================
%function[refpt]=refpixel(ifg,refpar)
%                                                                    
% Find reference pixel coordinate from multi-ifgs
%
% INPUT:
%   ifg:  input multiple interferogram
%   refpar: parameters to find reference point (nx,ny,chipsize,minfrac)
%
% OUTPUT:
%   refpt: output reference pixel
%
% Hua Wang @ Uni Leeds, 13/08/2009
%====================================================================
psz=floor(refpar.chipsize/2);   %half patch size
chipsize=psz*2+1;
nx=refpar.nx;   %search window number
ny=refpar.ny;   %search window number
thr = chipsize*chipsize*refpar.minfrac; %threshold

refpt.x=0;
refpt.y=0;

[rows,cols,nifgs]=size(ifg);

xstep=floor(cols/nx); %search step length in x
ystep=floor(rows/ny); %search step length in y

sigma0=realmax;

for iy=psz+1:ystep:rows-psz
  for ix=psz+1:xstep:cols-psz
    %get a patch, and reshape it to a column vector for each ifg
    patch=ifg(iy-psz:iy+psz,ix-psz:ix+psz,:);
    patch=reshape(patch,chipsize*chipsize,nifgs);

    %valid pixel number for all ifgs
    valid=sum(~isnan(patch));
    n=zeros(1,nifgs);
    n(valid<thr)=1;

    %all the ifgs are valid on the reference point
    if nnz(n)==0
      %calculate variance for each ifg
      for i=1:nifgs
        ifgv=patch(:,i);
        ifgv(isnan(ifgv))=[];
        sigma(i)=std(ifgv);
      end
      %select reference point with the minimum std 
      msigma=mean(sigma);
      if msigma<sigma0
        refpt.x=ix;
        refpt.y=iy;
        sigma0=msigma;
      end
    end
  end
end
  
if refpt.x==0 || refpt.y==0
  error('can not find a proper reference points');
end
