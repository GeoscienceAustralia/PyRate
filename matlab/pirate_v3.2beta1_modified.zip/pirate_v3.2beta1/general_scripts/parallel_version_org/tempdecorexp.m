function [f] = tempdecorexp(var,data,model)
%==================================================================
% function [f] = tempdecorexp(var,data,model)
% 
% returns L2 norm for difference between coherence data
% and prediction of exponential model
%
% model = 1: exp(-a.*t)
% model = 2: exp(-a.*t+b)
% model = 3: exp(-a.*(t^2))
%
% data(:,1) = interferometric time-span
% data(:,2) = coherence 
%                                                                  
% Matt Garthwaite @ GA, 6/08/2015                                
%==================================================================

if model==1
    f = norm(data(:,2) - exp(-var.*data(:,1)));
elseif model==2
    f = norm(data(:,2) - (exp(-var(1).*data(:,1))+var(2)));
elseif model==3
    f = norm(data(:,2) - exp(-var.*(data(:,1).^2)));
else
    error('ERROR: not such options!');
end

