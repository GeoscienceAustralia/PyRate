function[]=plotstack(ifg,prof,sumprof,clim)
%==================================================================
%function[]=plotstack(ifg,prof,sumprof,clim)
%------------------------------------------------------------------
% plotstack.m: plot the stacked interferogram and one profile      
%                                                                  
% INPUT:                                                           
%   ifg: input stacked interferogram                               
%   prof: all pixels along the profile                             
%   sumprof: values after suming pixels within a bin               
%   clim: flag for the range of output values                      
%         1:       plot within [mean - 2*sigma, mean + 2*sigma]    
%         default: plot within [min, max]                          
% OUTPUT:                                                          
%   NO                                                             
%                                                                  
% Hua Wang @ Uni Leeds, 02/02/2008                                
%                                                                  
% NOTE: distance and axis ranges are hard-wired for the profile    
%==================================================================


[rows,cols]=size(ifg);

figure

if clim==1
  %calculate std and mean
  ifgv = reshape(ifg',rows*cols,1);
  obsv = ifgv;
  obsv(isnan(ifgv))=[];
  std_ifg=std(obsv);
  mean_ifg=mean(obsv);
  clims = [mean_ifg-2*std_ifg mean_ifg+2*std_ifg];
else
  clims = [min(min(ifg)) max(max(ifg))];
end

subplot(1,2,1);
imagesc(ifg,clims);  
colormap(jet);
colorbar('Location','SouthOutSide');
axis equal;
axis image;
set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])

%Now set the alpha map for the NaN region
z=double(~isnan(ifg));
alpha(z);
set(gca, 'color', [0.5 0.5 0.5]);

%plot profiles
subplot(1,2,2);
prof(:,1)=prof(:,1)-200;
sumprof(:,1)=sumprof(:,1)-200;
plot(prof(:,1),prof(:,3),'.');
hold on
plot(sumprof(:,1),sumprof(:,2),'*','color','r');
axis([-300,300,-8,8]);
axis square;
grid on
hold off
