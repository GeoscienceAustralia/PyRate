function [ifg] = ts2ifgs_para(ts,ifglist)
%====================================================
%function [ifg] = ts2ifgs(ts,ifglist,intp)
% convert from time series (epoch) to ifgs
%
% INPUT:
%   ts: input time series
%   ifglist: interferogram list
%
% OUTPUT:
%   ifg: interferograms
%
% Hua Wang, 05/08/2011
%====================================================

%epoch number
im=min([ifglist.masnum ifglist.slvnum]');
is=max([ifglist.masnum ifglist.slvnum]');
%% change the sign if slave is earlier than master
isign=find(ifglist.masnum>ifglist.slvnum);

[rows,cols,nvel]=size(ts);
nifgs=length(ifglist.masnum);
ifg=NaN([rows,cols,nifgs],'single');
parfor i=1:nifgs
  ifg(:,:,i)=sum(ts(:,:,im(i):is(i)-1),3);
end
ifg(isign,:)=-ifg(isign,:);
