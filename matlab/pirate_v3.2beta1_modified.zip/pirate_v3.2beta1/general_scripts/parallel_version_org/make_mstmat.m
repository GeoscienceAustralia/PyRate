function [mstmat]=make_mstmat(ifg,ifglist,pthr,app)
%==================================================================== 
%function [mstmat]=make_mstmat(ifg,ifglist,pthr,app)
%                                                                     
% Function to make a matrix to identify independent ifgs using mst method
%                                                                     
% INPUT:                                                              
%   ifg:      interferograms                                         
%   ifglist:  interferogram list                                     
%   pthr:     minimum number of coherent ifgs for each pixel         
%   app:      append mst from the other branches (optional, default 1)
% OUTPUT:                                                             
%   mstmat:   mst matrix
%                                                                     
% Hua Wang @ Uni Leeds, 26/08/2009
%==================================================================== 

if nargin<4
  app=1;
end

[rows,cols,nifgs]=size(ifg);
nanifg=isnan(ifg);
clear ifg;

%find initial independent ifgs
mstmat=nanifg;        %get logical format
mstmat(nanifg==1)=0;  %fill in zeros for all elements
[ifglist_mst]=mst_kruskal(ifglist);
ifgid=ifglist_mst.id;

if app==1
  nanifg = permute(nanifg,[3,1,2]);
  for i=1:rows
    if mod(i,200)==0
      fprintf('creating mst matrix for the %d/%-d line\n',i,rows);
    end
 
    for j=1:cols
 
      nanv = nanifg(ifgid,i,j);
      if nnz(nanv)>0
        %if there is nan value in the independent ifglist, redo mst search
        nanv = nanifg(:,i,j);
        m=nifgs-nnz(nanv);
        if m>=pthr
          %get all valid ifgs from ifglist, and then select the independent ones
          ifglist_valid=getsubstruct(ifglist,nanv==0);
          [ifglist_mst_valid]=mst_kruskal(ifglist_valid);
          mstmat(i,j,ifglist_mst_valid.id)=1;
        end
      else
        %otherwise, fill in mstmat using initial mst
        mstmat(i,j,ifgid)=1;
      end
 
    end
  end
else
  mstmat(:,:,ifgid)=1;
  mstmat(nanifg)=0;
end
