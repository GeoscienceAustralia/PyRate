function w=wrap(unw,wvl)
%===========================================================
%function w=wrap(unw,wvl)
%
% Calculate a wrapped version of an unwrapped InSAR image
%
% Input:
% unw: unwrapped InSAR image
% wvl: half wavelength to be wrapped, default wvl=28.1mm
%
% output: 
% w:   wrapped InSAR image
%
% note: the same unit should be used for unw/wvl and wphs
%
% Hua Wang @ Uni Leeds, 10/09/2009
%===========================================================

if nargin<2
  wvl=28.1;
end

w = unw-floor(unw/wvl)*wvl;
