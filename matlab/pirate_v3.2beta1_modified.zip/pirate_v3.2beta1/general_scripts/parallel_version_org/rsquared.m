function rsq=rsquared(y,yfit)
%==================================================================
%function rsq=rsquared(y,yfit)
%
% Function to calculate the R-squared goodness of fit statistic
%                                                                  
% Matt Garthwaite @ GA, 6/08/2015                                
%==================================================================

resid=y-yfit;
SSresid = sum(resid.^2);
SStotal = (length(y)-1) * var(y);
rsq=1-SSresid/SStotal;