function[]=plotdecor(decor,cc,ifglist,irow,icol)
%==================================================================
%function[]=plotdecor(decor,cc,ifglist,irow,icol)
%
% Function to plot temporal decorrelation plots
%                                                                  
% INPUT:                                                           
%   decor: structure containing results of temporal decorrelation analysis
%   cc: coherence images
%   ifglist: ifglist structure containing ifm timespans
%   irow/icol: row and column number (optional, can select from image)
% OUTPUT:                                                          
%   NO                                                             
%                                                                  
% Matt Garthwaite @ GA, 6/08/2015                                
%==================================================================

%get points if not on command line
if nargin<4
  plotifg(decor.tdc,2)
  fprintf('\n click pixel for plot, enter to end\n')
  [icol,irow]=getpts(gcf);
end

% set NaN pixels to zero for later discarding
cc(isnan(cc))=0;

a=decor.a;
b=decor.b;

%prepare data
[nrows,ncols,ncc]=size(cc);
icol=round(icol);
irow=nrows-round(irow);
cc=permute(cc,[3,1,2]);
%span=diff(epochlist.span); %unit in year

npt=length(icol);
for i=1:npt
  data=cc(:,irow(i),icol(i));
  % time in days, round to ensure integer number of days
  date=round(ifglist.BaseT*365.25);
  % remove zero values of coherence
  date(data==0)=[];
  data(data==0)=[];
  [date,ind]=sort(date);
  data=data(ind);
  
  % calculate mean coherence for each interferometric time span
  for z=1:length(date)
    val=date(z);
    flag=zeros(length(date),1);
    flag(date==val)=1;
    data1=data.*flag;
    data1(data1==0)=[];
    avg(z,1)=mean(data1);
  end
  
  % daily time points for modelled data
  tmod=1:1000;
  
  % calculate modelled data
  if decor.model==1
    fit=exp(-a(irow(i),icol(i)).*date);
    cormod=exp(-a(irow(i),icol(i)).*tmod);
  elseif decor.model==2
    fit=exp(-a(irow(i),icol(i)).*date)+b(irow(i),icol(i));
    cormod=exp(-a(irow(i),icol(i)).*tmod)+b(irow(i),icol(i));
  end
  
  % plot results
  figure;
  subplot(2,1,1); 
  plot(date,data,'o','MarkerEdgeColor','r','MarkerSize',6); hold on
  plot(date,avg,'o','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',4);
  plot(tmod,cormod,'b');
  axis([0 max(tmod) 0 1]);
  ylabel('Coherence');
  xlabel('Time span (days)');
  legend('obs','mean','model');
  %title('Pixel X = %d Y = %d', icol, irow)
  grid on;
  hold off;
  
  % calculate and plot residuals
  resid=data-fit; 
  residavg=avg-fit;
  subplot(2,1,2); 
  plot(date,resid,'o','MarkerEdgeColor','r','MarkerSize',6); hold on
  plot(date,residavg,'o','MarkerEdgeColor','k','MarkerFaceColor','k','MarkerSize',4);
  axis([0 max(tmod) -0.5 0.5]);
  ylabel('Residuals');
  xlabel('Time span (days)');
  legend('obs','mean');
  grid on
  hold off;
  
end