function x = lscov_mg(A,b,V)
%LSCOV Least squares with known covariance.
%   X = LSCOV(A,B,V), where V is an M-by-M symmetric (or hermitian) positive
%   definite matrix, returns the generalized least squares solution to the
%   linear system A*X = B with covariance matrix proportional to V, i.e., X
%   minimizes (B - A*X)'*inv(V)*(B - A*X).
%
%   More generally, if V is full, it can be positive semidefinite, and LSCOV
%   returns X that is a solution to the constrained minimization problem
%
%      minimize E'*E subject to A*X + T*E = B
%        E,X
%
%   where T*T' = V.  When V is semidefinite, this problem will have a
%   solution only if B is consistent with A and V (i.e., in the column
%   space of [A T]), otherwise LSCOV returns an error.
%
%   By default, LSCOV computes the Cholesky decomposition of V and, in
%   effect, inverts that factor to transform the problem into ordinary
%   least squares.  However, if LSCOV determines that V is semidefinite, it
%   uses an orthogonal decomposition algorithm that avoids inverting V.
%

[nobs,nvar] = size(A); % num observations, num predictor variables
nrhs = size(b,2);      % num right-hand sides

% Assume V is full rank until we find out otherwise.  Decide later whether or not
% to factor V using Cholesky, unless it has been specified.
rankV = nobs;
if nargin < 4, alg = ''; end

% V given as a matrix.
if isequal(size(V),[nobs nobs])
     % Use Cholesky to factor V as T'*T, with T upper triangular, if V is
    % positive definite.
    [T,p] = chol(V);

    %if p == 0 Make V = T*T', with T lower triangular
        T = T';
end

  
    % Positive definite covariance matrix, incorporate its inverse into
    % the design matrix and response vector.
    % V was permuted prior to Cholesky, do the same to rows of A
    % and b.  No outputs depend on the order, so we won't have to
    % undo it.
        A = T \ A;
        b = T \ b;
    % Factor the design matrix, incorporate covariances or weights into the
    % system of equations, and transform the response vector.
        [Q,R,perm] = qr(A,0);
        z = Q'*b;

        % Use the rank-revealing QR to remove dependent columns of A.
        keepCols = (abs(diag(R)) > abs(R(1)).*max(nobs,nvar).*eps(class(R)));
    rankA = sum(keepCols);
    if rankA < nvar
        warning(message('MATLAB:lscov:RankDefDesignMat'));
    %THROW AN ERROR AND QUIT
    end

    % Compute the LS coefficients, filling in zeros in elements corresponding
    % to rows of R that were thrown out.
    xx = R \ z;
    x = zeros(nvar,nrhs);
    x(perm,1:nrhs) = xx;





