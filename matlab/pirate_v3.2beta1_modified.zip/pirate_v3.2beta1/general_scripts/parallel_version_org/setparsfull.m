function [] = setparsfull(conf,realdata)
%======================================================
%function [] = setparsfull(conf,realdata)
%
% Function to set configure parameters for PIRATE  
%                                                      
% INPUT:                                               
%   conf:  configure file 
%   realdata: default 1: real data; 0: synthetic data
% OUTPUT:                                              
%   None                            
%                                                      
% Hua Wang, 12/05/2010                         
%======================================================

if nargin<1
  conf='pirate.conf';
end
if nargin<2
  realdata=1;
end

fid = fopen(conf,'w');
if fid<0
  error(['Fail to open configure file:' conf]);
end
sepstr='#------------------------------------\n';

%-------------------------
% input/output parameters
%-------------------------
fprintf(fid,sepstr);
fprintf(fid,'# input/output parameters\n');
fprintf(fid,'# prjflag: projection flag (optional, default 3)\n');
fprintf(fid,'# (1: los->vertical, 2: los -> horizontal, 3: no projection)\n');

root=pwd;
obsdir=strcat(root,'/obs/');
printpar(fid,'obsdir:',obsdir);
printpar(fid,'ifgfilelist:','ifg.list');
printpar(fid,'ifgname_prefix_len:','4');

printpar(fid,'external_delay:','0');
printpar(fid,'delaydir:',strcat(root,'/delay/'));
printpar(fid,'delayfilelist:','delay.list');

printpar(fid,'demfile:','/home/hwang/demdata/wtibet/wtibet_5rlks.dem');
printpar(fid,'basepflag:','1');
printpar(fid,'ampflag:','0');
printpar(fid,'prjflag:','3');
printpar(fid,'unwflag:','1');

%% earthquake list file to step estimation
printpar(fid,'eqlistfile:',strcat(root,'/eq.list'));

outdir=strcat(root,'/out/');
printpar(fid,'outdir:',outdir);

%------------------------------------
%% simulation parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# simulation parameters\n');
fprintf(fid,'# nsets: number of sets of data (1: real data; >1: multiple sets from Monte Carlo simulation)\n');
if realdata==1
  printpar(fid,'nsets:','1');
else
  printpar(fid,'nsets:','100');
  simdir=strcat(root,'/sets/');
  printpar(fid,'simdir:',simdir);
end

%--------------------------------
% interferogram crop paramters
%--------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# interferogram crop options\n');
fprintf(fid,'# 1: minimum 2: maximum 3: customize\n');
fprintf(fid,'# lksx,lksy: looks in x-/y-axis direction respectively\n');
fprintf(fid,'# xstep,ystep: pixel size in degree\n');
fprintf(fid,'# xfirst,yfirst: x,y of top-left corner\n');
fprintf(fid,'# xlast,ylast: x,y of bottom-right corner\n');
printpar(fid,'ifgcropopt:','3');
printpar(fid,'#ifglksx:','5');
printpar(fid,'#ifglksy:','5');
printpar(fid,'xstep:','0.000833333333333');
printpar(fid,'ystep:','-0.000833333333333');
printpar(fid,'ifgxfirst:','76.758331430');
printpar(fid,'ifgxlast:','79.669163599');
printpar(fid,'ifgyfirst:','38.0');
printpar(fid,'ifgylast:','32.5');

%------------------------------------
%% model parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# initial model parameters\n');
fprintf(fid,'# slip rate for the initial forward model in mm/yr\n');
fprintf(fid,'# add more models following nmodels if nmodels>0\n');
printpar(fid,'nmodels:','0');
printpar(fid,'inisliprate_m1:','0');
fmodelfile=strcat(root,'/fmodels/fmodel_ss.dat');
printpar(fid,'fmodelfile_m1:',fmodelfile);

%------------------------------------
%% reference point coordinate
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# reference point options\n');
fprintf(fid,'# refx/y: coordinates of reference points\n');
fprintf(fid,'# refest: estimation method (1: average of the whole image; 2: average of a patch around the refpt)\n');
fprintf(fid,'# refchipsize: chip size of the reference point window\n');
fprintf(fid,'# refminfrac: minimum fraction of coherence pixels\n');
fprintf(fid,'# refnx/y: number tie points in x/y direction\n');
printpar(fid,'refx:','0');
printpar(fid,'refy:','0');
printpar(fid,'refest:','1');
printpar(fid,'refchipsize:','21');
printpar(fid,'refminfrac:','0.8');
printpar(fid,'refnx:','50');
printpar(fid,'refny:','50');

%------------------------------------
%% dem errors estimation parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# shpdemest - spatial high-pass dem error estimation \n');
printpar(fid,'shpdemest:','0');

%------------------------------------
%% orbital errors fitting parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# orbital errors fitting parameters\n');
fprintf(fid,'# orbfit: 1-correct orbital errors; 0-not\n');
fprintf(fid,'# orbfitmethod = 1: interferogram by interferogram; orbatmfitmethod = 2: epoch by epoch\n');
fprintf(fid,'# degrees: polynomial degrees for the orbital error fitting (1: planar; 2: quadratic)\n');
fprintf(fid,'# orbfitlooksx/y: multi-look pocessing for orbital correction\n');
%fprintf(fid,'# orbmaskflag: mask some patches for orbital correction\n');
printpar(fid,'orbfit:','1');
printpar(fid,'orbfitmethod:','2');
printpar(fid,'orbfitdegrees:','1');
printpar(fid,'orbfitlksx:','10');
printpar(fid,'orbfitlksy:','10');
%printpar(fid,'orbmaskflag:','0');

%------------------------------------
%% atmospheric delay errors fitting parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# atmospheric delay errors fitting parameters\n');
fprintf(fid,'# atmfit: 1-correct topo-correlated atm errors; 0-not\n');
fprintf(fid,'# atmfitmethod = 1: interferogram by interferogram; atmfitmethod = 2, epoch by epoch\n');
fprintf(fid,'# atmfitlooksx/y: multi-look pocessing for atm correction\n');
%fprintf(fid,'# atmmaskflag: mask some patches for atm correction\n');
printpar(fid,'atmfit:','1');
printpar(fid,'atmfitmethod:','2');
printpar(fid,'atmfitlksx:','10');
printpar(fid,'atmfitlksy:','10');
%printpar(fid,'atmmaskflag:','0');

%------------------------------------
%% vcm estimation parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# vcm estimation parameters\n');
fprintf(fid,'# vcmtmethod = 1: general method; 2: network estimation for vcm_t\n');
fprintf(fid,'# vcmsmethod = 1: general method; 2: sparse matrix for the first line; 3: sparse matrix for vcm_s\n');
fprintf(fid,'# vcmslksx/y: the same looks also used for slip rate estimation\n');
printpar(fid,'vcmtmethod:','1');
printpar(fid,'vcmsmethod:','2');
printpar(fid,'vcmslksx:','10');
printpar(fid,'vcmslksy:','10');

%------------------------------------
% APS parameters
%------------------------------------
%apsest: (1: APS estimation; 0: not)
fprintf(fid,sepstr);
fprintf(fid,'# apsest: (1: APS estimation; 0: not)\n');
printpar(fid,'apsest:','0');

%------------------------------------
%% abrupt displacement correlation parameters
%------------------------------------
% slop: slop of the smoothing fuction (like locking depth,default: 20)
% thr: correlation threshold of smoothing function (default: 0.7)
% fact: fact: correlation window size = corrfact * the atm wavelength (default: 1)
% step: step of the correlation window (default: 3 pixels)
fprintf(fid,sepstr);
fprintf(fid,'# abrupt displacement correlation parameters\n');
fprintf(fid,'# slop: slop of the smoothing fuction (like locking depth,default: 20)\n');
fprintf(fid,'# thr: correlation threshold of smoothing function (default: 0.6)\n');
fprintf(fid,'# fact: correlation window size = corrfact * the atm wavelength (default: 1)\n');
fprintf(fid,'# step: step of the correlation window (default: 3 pixels)\n');
printpar(fid,'corrslop:','20');
printpar(fid,'corrthr:','0.6');
printpar(fid,'corrfact:','1.0');
printpar(fid,'corrstep:','3');

%------------------------------------
%% temporal high-pass filter parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# temporal high-pass filter parameters\n');
fprintf(fid,'# thpfmethod: 1-Gaussian 2-Triangular 3-Mean filter \n');
fprintf(fid,'# thpfcutoff: cutoff t0 for gaussian filter in year\n');
printpar(fid,'thpfmethod:','2');
printpar(fid,'thpfcutoff:','0.5');

%------------------------------------
%% spatially correlated noise filter parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# spatially correlated noise low-pass filter parameters\n');
fprintf(fid,'# slpfmethod: filter method (1: butterworth; 2: gaussian)\n');
fprintf(fid,'# slpfcutoff: cutoff d0 for both butterworth and gaussian filters in the same unit with pixel size\n');
fprintf(fid,'#             if slpfcutoff=0, using the wavelength from vcm estimation\n');
fprintf(fid,'# slpforder: order n for butterworth filter (default 1)\n');
printpar(fid,'slpfmethod:','1');
printpar(fid,'slpfcutoff:','0');
printpar(fid,'slpforder:','1');

%------------------------------------
% time series parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# time series parameters\n');
fprintf(fid,'# tscal: time series calculation (1: ts calculation; 0: no)\n');
fprintf(fid,'# tsmethod: time series method (1: Laplacian smoothing, 2: SVD, 3: B-Spline)\n');
fprintf(fid,'# smorder: order of Laplacian smoothing operator(1: first-order difference; 2: second-order difference)\n');
fprintf(fid,'# smfactor: smoothing factor(0: calculate & plot L-curve; others: using the specific smoothing factor)\n');
fprintf(fid,'# smf_min/max/int: region of smoothing factors for L-curve calculation, the exact region will be calculated by 10.^(smf)\n');
fprintf(fid,'# lcurve_lksx/lksy: looks number for L-curve calculation\n');
fprintf(fid,'# ts_interp: do interpolation by Laplacian smoothing for epoch gaps\n');
fprintf(fid,'# stepest: estimate step in ts analysis\n');
printpar(fid,'tscal:','0');
printpar(fid,'tsmethod:','1');
printpar(fid,'smorder:','1');
printpar(fid,'smfactor:','0');
printpar(fid,'smf_min:','-3');
printpar(fid,'smf_max:','1');
printpar(fid,'smf_int:','0.2');
printpar(fid,'lcurv_lksx:','10');
printpar(fid,'lcurv_lksy:','10');
printpar(fid,'ts_interp:','0');
printpar(fid,'stepest:','0');

%------------------------------------
%% stacking parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# stacking parameters\n');
fprintf(fid,'# pthr: minimum number of coherent ifgs for each pixel\n');        
fprintf(fid,'# nsig: n-sigma used as residuals threshold for ILSM stacking\n');
fprintf(fid,'# maxsig: maximum residual used as threshold for the stacked interferogram\n');   
stackpar = struct('nsig',{2},'pthr',{10},'maxsig',{2});
printpar(fid,'nsig:','3');
printpar(fid,'pthr:','18');
printpar(fid,'maxsig:','3');

%------------------------------------
%% profile parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# profile parameters\n');
fprintf(fid,'# swath/step: unit (km)\n');
printpar(fid,'make_prof:','0');
printpar(fid,'profswath:','15');
printpar(fid,'profstep:','1');
printpar(fid,'gmtfaultfile:','/home/hwang/catalogue/com/HimaTibetMap-1.0-gmt/asia.gmt');

%------------------------------------
%iterative algorithm parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# iterative algorithm parameters\n');
fprintf(fid,'# tol: tolerance for the convergence\n');
fprintf(fid,'# maxiter: maximam iterative number\n');
printpar(fid,'tol:','0.2');
printpar(fid,'maxiter:','10');

fclose(fid);

%--------------------------------------------
function printpar(fid,parname,parval)
fprintf(fid,'%-25s %-25s\n',parname,parval);
