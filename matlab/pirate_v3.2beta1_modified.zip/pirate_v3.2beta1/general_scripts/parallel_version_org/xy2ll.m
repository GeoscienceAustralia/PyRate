function [lon,lat] =  xy2ll(x,y,ifghdr)
%=======================================================================
%function [lon,lat] =  xy2ll(x,y,ifghdr)
%
% Function to convert unit from pixel to lon/lat
%
% INPUTS:
%   x/y: pixel number if x/y direction
%   ifghdr: image header file
%
% OUTPUTS:
%   lon,lat: longitude and latitude
%
% Hua Wang, 20/04/2010
%=======================================================================

lon = (x-1)*ifghdr.xstep+ifghdr.xfirst;
lat = (y-1)*ifghdr.ystep+ifghdr.yfirst;
