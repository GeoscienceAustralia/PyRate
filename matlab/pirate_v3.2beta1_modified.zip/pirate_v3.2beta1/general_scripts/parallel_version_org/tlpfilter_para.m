function [tsfilt_incr] = tlpfilter_para(tsincr,epochlist,tlpfpar,xpsize,ypsize)
%====================================================
%function [tsfilt_incr] = tlpfilter(tsincr,epochlist,tlpfpar,xpsize,ypsize)
% temporal low pass filter
%
% INPUT:
%   tsincr: input interferogram
%   epochlist: epoch list
%   tlpfpar: temporal low-pass filter parameters, including cutoff in year
%   x/y-psize: pixel size in x/y
%
% OUTPUT:
%   tsfilt_incr: low-pass filtered time-series
%
% Hua Wang, 13/08/2010
%
% 05/08/2011 HW: don't output ifg, and move it to function ts2ifgs.
% 
% NOTE: smoothing based on velocity? displacement?
%       velocity: epoch with high atm will affect its neighbors too much
%====================================================

%epoch number
[rows,cols,nvel]=size(tsincr);
intv=diff(epochlist.span); %time interval for the neighboring epoch
span=epochlist.span(1:nvel)+intv/2; %accumulated time spanning

%calculate vcm of each epoch
if nargin>3
  parfor i=1:nvel
    [maxvar(i),alpha(i)] = cvdcalc(tsincr(:,:,i),cols,rows,xpsize,ypsize,1);
  end
end

tsincr=permute(tsincr,[3,1,2]);
nanmat = isnan(tsincr);
tsfilt_incr=NaN([nvel,rows,cols],'single');

%tsincr=tsincr./repmat(intv,[1,rows,cols]); %convert from displacement to velocity

%temporal low-pass filter
for i=1:rows
  if mod(i,200)==0
    fprintf('temporal low-pass filtering for the %d/%-d line\n',i,rows);
  end

  for j=1:cols
    %check valid epochs
    sel=find(nanmat(:,i,j)==0);
    m=length(sel);

    %filtering
    if (m>=tlpfpar.pthr)
      for k=1:m
        yr=span(sel)-span(sel(k));
        if tlpfpar.method==1
          %gaussian filter
          wgt=exp(-(yr/tlpfpar.cutoff).^2/2);
        elseif tlpfpar.method==2
          %triangular filter
          %wgt=tlpfpar.cutoff/2-abs(yr);
          wgt=tlpfpar.cutoff-abs(yr);
          wgt(wgt<0)=0;
        else
          %mean filter
          wgt=ones(m,1);
        end

        if nargin>3
          %wgt=wgt./maxvar(sel)';
          wgt=1./maxvar(sel)';
        end

        wgt=wgt/sum(wgt);
     
        %tsfilt_incr(sel(k),i,j)=sum(tsincr(sel,i,j).*wgt)*intv(sel(k));
        tsfilt_incr(sel(k),i,j)=sum(tsincr(sel,i,j).*wgt);
      end
    end
  end
end
        
tsfilt_incr=permute(tsfilt_incr,[2,3,1]);
