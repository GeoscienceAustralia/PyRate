function[]=plotifgs(ifg,m,n,ifgnml,ifghdr,clim)
%=================================================================
%function[]=plotifgs(ifg,m,n,ifgnml,ifghdr,clim)
%                                                                 
% plotifgs.m: plot multiple interferograms using subplot function 
%                                                                 
% INPUT:                                                          
%   ifg: input interferograms in 3-d matrix (rows, cols, ifgid)   
%   m:   rows for output subplots                                 
%   n:   cols for output subplots                                 
%   ifgnml: ifg namelist used for title of each interferogram     
%   ifghdr: ifg header
%   clim: clim of the images [min, max]
% OUTPUT:                                                         
%   NO                                                            
%                                                                 
% Hua Wang @ Uni Leeds, 02/02/2008                                
%
% 07/08/2011 HW: add clim to plot a single colorbar for all subplots
% 20/04/2010 HW: plot in geographic coordinate
%                set coordinate origin as bottom-left corner
%=================================================================
opengl software
[rows,cols,nifgs]=size(ifg);

%% plot the interferogram
figure

if nargin<4
  ifgnml=[];
end
if nargin<5
  ifghdr=[];
end
if nargin<6
  clim=[];
end

if ~isempty(ifghdr)
  x=[ifghdr.xfirst,ifghdr.xfirst+(cols-1)*ifghdr.xstep];
  y=[ifghdr.yfirst,ifghdr.yfirst+(rows-1)*ifghdr.ystep];
else
  x=[1,cols];
  y=[rows,1];
end

for i=1:nifgs
  ax(i)=subplot(m,n,i);
  if ~isempty(clim)
    imagesc(x,y,ifg(:,:,i),clim);
  else
    imagesc(x,y,ifg(:,:,i));
  end
  
  set(gca,'YDir','normal')
  colormap(jet);
  %colormap(gray);

  if isempty(clim)
    colorbar;
  end

  axis equal;
  axis image;
  set(gca,'xtick',[],'xticklabel',[])
  set(gca,'ytick',[],'yticklabel',[])

  if ~isempty(ifgnml)
    strpair=char(ifgnml(i,:)); 
    %replace underscore by minus
    strpair(find(strpair=='_'))='-';
    if length(strpair)>17
      title(strpair(5:17));
    else
      title(strpair);
    end
  end

  %Now set the alpha map for the NaN region
  z=double(~isnan(ifg(:,:,i)));
  alpha(z);
  set(gca, 'color', [0.5 0.5 0.5]);
end

%put a single colorbar for all subplots
if ~isempty(clim)
  h=colorbar;
  pos=get(ax(nifgs), 'Position');
  pos1=get(ax(1),'Position');
  poscbar=get(h,'Position');
  set(h, 'Position', [pos(1)+pos(3)+0.08 poscbar(2) poscbar(3)*m poscbar(4)+pos1(2)-pos(2)])
  for i=1:nifgs
    pos=get(ax(i), 'Position');
    set(ax(i), 'Position', [pos(1)-0.05 pos(2) pos(3) pos(4)]);
  end
end
