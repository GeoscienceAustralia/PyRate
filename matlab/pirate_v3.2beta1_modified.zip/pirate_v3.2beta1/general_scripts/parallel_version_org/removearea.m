function [mask] = removearea
%function [mask] = removearea
% Function to mask out region selected with mouse
%
% Input: 
%   None
% Output: 
%   mask: NaN means mask, and 1 means non-mask

fprintf(1,'Select the polygon using the mouse...\n');

[mask] = roipoly;
mask=single(~mask);
mask(mask==0)=nan;
