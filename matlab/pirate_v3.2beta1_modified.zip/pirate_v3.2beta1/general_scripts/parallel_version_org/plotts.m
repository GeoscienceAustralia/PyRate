function[]=plotts(ts,epochlist,flag,irow,icol)
%==================================================================
%function[]=plotts(ts,epochlist,flag,irow,icol)
%
% Function to plot time series
%                                                                  
% INPUT:                                                           
%   ts: time series in 3D matrix                           
%   epochlist: epochlist                             
%   flag: flag for time series plot (default 1)                     
%         1: plot displacements (for tscum/tsincr)  
%         2: plot velocities (for tsincr) 
%   irow/icol: row and column number (optional, can select from image)
% OUTPUT:                                                          
%   NO                                                             
%                                                                  
% Hua Wang @ Uni Leeds, 17/08/2010                                
%==================================================================

if nargin<3
  flag=1;
end
%get points
[x y n]=size(ts);

if nargin<4
  plotifg(ts(:,:,n))
  fprintf('\n click pixel for time-series plot, enter to end')
  [icol,irow]=getpts(gcf);
end

irow
icol


%prepare data
[nrows,ncols,nts]=size(ts);
icol=round(icol);
irow=nrows-round(irow);
ts=permute(ts,[3,1,2]);
span=diff(epochlist.span); %unit in year
if flag~=1
  ts=ts./repmat(span,[1,nrows,ncols]);
end

irow
icol

figure
npt=length(icol);
for i=1:npt
  data=ts(:,irow(i),icol(i));
  %date=epochlist.date(2:nts+1);
  date=epochlist.span(2:nts+1);
  date(isnan(data))=[];
  data(isnan(data))=[];
  plot(date,data,'-bo','LineWidth',1,'MarkerEdgeColor','r','MarkerFaceColor','g','MarkerSize',6);
  hold on
end
axis square
grid on
hold off
