function [vcm_t] = make_vcmt(ifglist,maxvar,method)
%===============================================================
%function [vcm_t] = make_vcmt(ifglist,maxvar,method)
%                                                               
% make_vcmt: make variance-covariance matrix in time domain
% INPUT:
%   ifglist: interferogram list, see getnml.m for its format
%   maxvar: maximum variance vectors
%   method: method used to calculate vcm_t
%
% OUTPUT:
%   vcm_t: temporal vcm
% Hua Wang @ Uni Leeds, 02/02/2008, following Juliet Biggs 2006
%
% 10/08/2009 HW: modified from make_vcm.m
%===============================================================

[nifgs]=length(ifglist.nml);

%%% make the covariance matrix in time domain
disp('calculating vcm in time domain ...');

%%% set up template for variance-covariance matrix. 
if method==1
  %%% c=0.5 for common master or slave; c=-0.5 if master of one matches slave of another
  vcm_pat=diag(ones(nifgs,1));
  for i = 1:nifgs-1
    mas1 = ifglist.masnum(i);
    slv1 = ifglist.slvnum(i);
    for j = i+1:nifgs
      mas2 = ifglist.masnum(j);
      slv2 = ifglist.slvnum(j);
      if (mas1==mas2 || slv1==slv2)
        vcm_pat(i,j) = 0.5;
      end
      if (mas1==slv2 || slv1==mas2)
        vcm_pat(i,j) = -0.5;
      end
      vcm_pat(j,i)=vcm_pat(i,j);
    end
  end
  %%% make covariance matrix in time domain
  var = sqrt(maxvar);
  vcm_t = var*var';
  vcm_t = vcm_t.*vcm_pat;

else
  % calculate maximum variance for each epoch using pinv method
  nepoch = max(max([ifglist.masnum ifglist.slvnum]));

  B = zeros(nifgs,nepoch);
  for i=1:nifgs
    %master/slave image epoch, using it to determine the cofficient position
    im = ifglist.masnum(i);
    is = ifglist.slvnum(i);
    %fill in the design matrix
    B(i,im)=1;
    B(i,is)=1;
  end

  % using non-negative method
  %varobs = maxvar-1;
  %varepoch = lsqnonneg(B,varobs);
  %varepoch = varepoch+0.5;

  % using the constrained linear least-squares method
   lb=ones(nepoch,1);  %supposing the variance is larger than 1 mm
   varepoch = lsqlin(B,maxvar,[],[],[],[],lb,[]);

  % generate the covariance matrix
  %vcm_t=diag(maxvar);
  vcm_t=zeros(nifgs,nifgs);
  for i = 1:nifgs-1
    %master/slave image name
    mas1 = ifglist.masnum(i);
    slv1 = ifglist.slvnum(i);
    for j = i+1:nifgs
      %master/slave image name
      mas2 = ifglist.masnum(j);
      slv2 = ifglist.slvnum(j);
      if mas1==mas2
        vcm_t(i,j) = varepoch(mas1);
      elseif slv1==slv2
        vcm_t(i,j) = varepoch(slv1);
      elseif mas1==slv2
        vcm_t(i,j) = -varepoch(mas1);
      elseif mas2==slv1
        vcm_t(i,j) = -varepoch(mas2);
      end
      vcm_t(j,i)=vcm_t(i,j);
    end
  end
  %diagular variance
  for i=1:nifgs
    mas1 = ifglist.masnum(i);
    slv1 = ifglist.slvnum(i);
    vcm_t(i,i) = varepoch(mas1)+varepoch(slv1);
  end
end
