function[ifg,closure] = sum_closure_para(mloop,epochlist,ifg,iwrite,imask)
%====================================================================
%function[ifg,closure] = sum_closure(mloop,epochlist,ifg,iwrite,imask)
%
% calculate closures for the loops identified by MST & Dijkstra algorithms
%
% INPUT:
%   mloop: structure of the loops, including epochs and ifgs
%   epochlist: epoch list
%   ifg: 3d matrix of input data
%   iwrite: output network and closures (default 1: output closure; 0: not)
%   imask: mask the original interferograms (1: mask ifgs; default 0)
%
% OUTPUT:
%   ifg: masked ifg
%   closure: closure of the loops
% 
% Hua Wang, 31/07/2011
%====================================================================
if isempty(mloop)
  return
end

[nrows,ncols,nifgs]=size(ifg);

if nargin<4
  iwrite=0;
end
if nargin<5
  imask=0;
end

nloops=length(mloop);
closure=zeros(nrows,ncols,nloops);
for i=1:nloops
  %closure
  nlines=length(mloop(i).ifg); %ifg number of this loop
  for j=1:nlines
    iline = abs(mloop(i).ifg(j));
    closure(:,:,i)=closure(:,:,i)+sign(mloop(i).ifg(j))*ifg(:,:,iline);
  end

  %remove medium
  closure(:,:,i)=closure(:,:,i)-nanmedian(reshape(closure(:,:,i),nrows*ncols,1));

  %mask
  if imask==1
    mask=ones(nrows,ncols);
    mask(closure(:,:,i)>pi | closure(:,:,i)<-pi)=nan;
    for j=1:nlines
      iline = abs(mloop(i).ifg(j));
      tmp=ifg(:,:,iline);
      tmp(isnan(mask))=nan;
      ifg(:,:,iline)=tmp;
    end
  end
end

%output loops
if iwrite==1
  parfor i=1:nloops
    outfile='closure_';
    npts=length(mloop(i).epoch);
    for j=1:npts-2
      outfile=strcat(outfile,num2str(epochlist.date(mloop(i).epoch(j))),'-');
    end
    outfile=strcat(outfile,num2str(epochlist.date(mloop(i).epoch(j+1))),'.dat');
    writemat(outfile,closure(:,:,i));
  end
end
