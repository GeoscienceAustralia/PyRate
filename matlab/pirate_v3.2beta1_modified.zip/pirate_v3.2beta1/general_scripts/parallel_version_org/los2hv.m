function [hv]=los2hv(ifg,los,fmt,prj)
%====================================
%function [hv]=los2hv(ifg,los,fmt,prj)
%                                                                            
% project from los to horizontal or vertical displacement
%                                                                     
% INPUT:                                                              
%  ifg: input ifg                                     
%  los: line-of-sight angle in degree (positive from vertical)
%  fmt: format (1: roi-pac (default), 2: gamma)
%  prj: projection (default 1: los->vertical, 2: los->horizontal)
%                                                                     
% OUTPUT:                                                             
%  hv:  horizontal or vertical displacement               
%                                                                     
% Hua Wang, 06/01/2012      
%====================================
if nargin<3
  fmt=1;
end
if nargin<4
  prj=1;
end

%calculate unit vector
if fmt==1
  los = los*pi/180.0;
else
  los = pi/2-los;
end

if prj==1
  hv=ifg./cos(los);
else
  hv=ifg./sin(los);
end
