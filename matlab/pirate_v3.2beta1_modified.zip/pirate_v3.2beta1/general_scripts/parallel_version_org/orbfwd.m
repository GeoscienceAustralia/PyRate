function [ifg_orb]=orbfwd(ifglist,orbfitpar,ifghdr,refpt,orbparams)
%=====================================================================
%function [ifg_orb]=orbfwd(ifglist,orbfitpar,ifghdr,refpt,orbparams)
%                                                                     
% Forward calculation of orbital errors in full resolution, 
%  both ifg-by-ifg method and epoch-by-epoch method are supported 
%                                                                     
% INPUT:                                                              
%   ifglist:   master/slave image list for each interferogram       
%   orbfitpar: structure of orbit fitting parameters including
%              degree - degree of the polynomial for fitting orbital error   
%              method - orbital/atm errors fitting method                
%                       1: ifg-by-ifg method; 2: epoch-by-epoch method       
%   ifghdr:    ifg header
%   orbparams: parameters of orbital errors                         
%                                                                     
% OUTPUT:                                                             
%   ifg_orb:   orbital errors                                       
%                                                                     
% Hua Wang @ Uni Leeds, 02/02/2008, following Juliet Biggs, 2006          
%
% 05/08/2011 HW: change input as structure
% 10/08/2009 HW: not fitting offset for redundant ifgs because 
%                it was not fitted, this step will be furtherly 
%                considered during removing reference phase.
%=====================================================================

nifgs=length(ifglist.masnum);

%cofficients number for each epoch
%degree=1: x, y
%degree=2: x^2, y^2, xy, x, y
ncoef = (orbfitpar.degree+1)*(orbfitpar.degree+2)/2-1;

%epoch number
nepoch = max(max([ifglist.masnum ifglist.slvnum]));

%total parameters number (epoch parameters + offsets)
if orbfitpar.method==2
  npolypar = nepoch*ncoef; %epoch-by-epoch method
else
  npolypar = nifgs*ncoef;  %ifg-by-ifg method
end

%make grid (x,y coordinates)
n=ifghdr.length*ifghdr.width;
[yy,xx]=meshgrid(1:ifghdr.length,1:ifghdr.width);
xxv=reshape(xx,n,1);
yyv=reshape(yy,n,1);
%subtract the reference coordinates
xxv = (xxv-refpt.x)*ifghdr.xpsize/100.0;   %using 100km, test 30/09/2009
yyv = (yyv-refpt.y)*ifghdr.ypsize/100.0;   %using 100km, test 30/09/2009
clear xx,yy;

if orbfitpar.degree==1
  B=[xxv yyv];
else                              %degree == 2
  xxv2 = xxv.*xxv;
  yyv2 = yyv.*yyv;
  xyv  = xxv.*yyv;
  B=[xxv2  yyv2  xyv  xxv  yyv];
end

clear('xxv','yyv');

ifg_orb=zeros(ifghdr.length,ifghdr.width,nifgs,'single');
for i=1:nifgs
  %epoch-by-epoch method design matrix
  if orbfitpar.method==2
    %master/slave image epoch, using it to determine the cofficient position
    im = ifglist.masnum(i);
    is = ifglist.slvnum(i);
    %coefficients for the master/slave image
    jbm=(im-1)*ncoef+1;
    jbs=(is-1)*ncoef+1;
    parmm = orbparams(jbm:jbm+ncoef-1);
    parms = orbparams(jbs:jbs+ncoef-1);
    parm = parms - parmm;
  %ifg-by-ifg method design matrix
  else
    jb1 = (i-1)*ncoef+1;
    jb2 = i*ncoef;
    parm = orbparams(jb1:jb2);
  end

  %coefficients for the offsets
  %%do not calculate offsets because the offsets for the redundant ifgs are not available, 10-aug-09, HW
  %joff = npolypar+i;
  %offset = orbparams(joff);
   offset=0;

  fullorb = B*parm + offset;
  fullorb=single(fullorb); %modified to save memory, 11/08/2009, HW
  ifg_orb(:,:,i)=reshape(fullorb,ifghdr.width,ifghdr.length)';

  clear fullorb;
end
