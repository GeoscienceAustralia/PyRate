function [y,stdy] = splineval(x,u,breaks,base,periodic,vcmu)
%=====================================================
% Evaluation for a spline function
%
% Input:
%   x:          Noisy data x-locations (1 x mx)
%   u:          solution of control points
%   periodic:   periodic boundary conditions
%   breaks:     breaks
%   base:       basis of the spline function
% 
% Output:
%   y:          evalutated output
%   stdy:       standard deviation of y
%
% Hua Wang, 22/07/2011
%
% based on splinefit function copyrighted by 
% jonas.lundgren@saabgroup.com, 2010.
%=====================================================

if nargin<5
  periodic = 0; % Not use periodic boundary conditions
end

%pieces
pieces=length(breaks)-1;
n=base.order;

% Periodic expansion of solution
if periodic
  jj = mod(0:pieces+n-2,pieces) + 1;
  u = u(:,jj);
end

% Compute polynomial coefficients
ii = [repmat(1:pieces,1,n); ones(n-1,n*pieces)];
ii = cumsum(ii,1);
jj = repmat(1:n*pieces,n,1);
C = sparse(ii,jj,base.coefs,pieces+n-1,n*pieces);

% convert from basis to the coefficients of x
coef = C'*double(u);

% for each evaluation site, compute its breakpoint interval
[~,index] = histc(x,[-inf,breaks(2:pieces),inf]);

% now go to local coordinates ...
xb=breaks(index);
x = x-xb';

% design matrix of polynomial
xmat=x.^(n-1);
for i=n-1:-1:1
  xmat=[xmat x.^(i-1)];
end

% vcm of the design matrix
nx=length(x);
if nargout>1
  vcm = C'*vcmu*C;
  stdy=zeros(nx,1);
end

% evaluate y and sigma-y
y=zeros(nx,1);
for i=1:nx
  sel=[index(i):pieces:index(i)+(n-1)*pieces]; %index of selected coefficients
  xi=xmat(i,:);
  y(i)=xi*coef(sel);
  if nargout>1
     stdy(i)=sqrt(xi*vcm(sel',sel)*xi');
  end
end
