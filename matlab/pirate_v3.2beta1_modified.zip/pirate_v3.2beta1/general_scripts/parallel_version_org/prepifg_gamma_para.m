function [phsout,ifghdr,ccout,ampout] = prepifg_gamma_para(obsdir,ifg_nml,parmat,convflag,ampflag,prjflag,ccflag)
%===================================================================
%function [phsout,ifghdr,ampout] = prepifg(obsdir,ifg_nml,parmat,convflag,ampflag,prjflag)
%                                                                   
% Prepare a serial of data by filling NaN for smaller ifgs.
%
% INPUT:
%   obsdir: directory of the input data
%   ifg_nml: input data namelist, the first 17 characters my be                      
%                format: geo_yymmdd_yymmdd....
%                        (4c)(mas)  (slv) (others)
%   parmat: a two column matrix to save all the configure parameters (optional)
%   convflag: unit conversion flag (optional, default 1)
%           (1: radius -> mm, 2: metre -> radius, 3: no conversion)
%   ampflag: calculate amplitude (optional, 1-calculate, default 0)
%   prjflag: projection flag (optional, default 3)
%           (1: los->vertical, 2: los -> horizontal, 3: no projection)
%
% OUTPUT:
%   phsout: output phase data
%   ifghdr: header parameters for the output data
%   ampout: output amplitude data
%
% Note: Assuming the last band is unwrapped phase
%
% Hua Wang @ Uni Leeds, 06/02/2009
%
% 24/09/2012 HW: read 'real' data for gamma outputs
% 10/02/2012 HW: make all output optional to save memory
% 06/01/2012 HW: project los to h/v for multi-tracks/-satellites processing
% 16/07/2011 HW: replace ifghdr.mat as ifg.rsc
% 16/07/2011 HW: check date and size of the cropped ifgs instead of using ifghdr.mat
% 10/05/2011 HW: make parmat as optional
% 27/04/2011 HW: replace 'multibandread' by 'readmat' to save space
% 30/01/2010 HW: calculate mean amplitude
% 09/09/2009 HW: calculate approximate pixel size (km) using utm projection
%
%
% MODIFIED TO ENABLE PARALLEL PROCESSING WHERE POSSIBLE (SL 03 Nov 2015)
%   - one section turned off due to incompatibility with parfor (line 371)
%
%===================================================================
%load mask.mat
%unit conversion, added on 19/08/2009 by HW to be compatible with baseline file
if nargin<4
  convflag=1;
end

%calculate amplitude data
if nargin<5
  ampflag=0;
end

%projection, added on 06/01/2012 for multiple tracks processing
if nargin<6
  prjflag=3;
end

%coherence flag added by MG on 5/8/2015 for coherence analysis
if nargin<7
  ccflag=0;
end

%get parameters from the configure file
%   opt: options for the output data
%        (1: minimum extension; 2: maximum extension; 3: customize)
if nargin<3 
  parmat=[];
end
if isempty(parmat)
  opt=2;
  lksx0=1;
  lksy0=1;
else
  opt = getpar('ifgcropopt:',parmat,'n');
  lksx0 = getpar('ifglksx:',parmat,'n',0);
  lksy0 = getpar('ifglksy:',parmat,'n',0);
end

%read the data file list
nifgs = length(ifg_nml);

%-------------------------------------------------------------------
%import parameters in the resource file for each data
%only compatible for roi_pac format
%X_FIRST: topleft east
%Y_FIRST: topleft north
  %rscname = char(strcat(obsdir,ifg_nml(i),'.rsc'));
  parfile=getpar('parfile:',parmat,'s');
  [rscmat] = readparfile_gamma(parfile);
  for i=1:nifgs
    ifgrsc(i).width  = getpar('width:',rscmat,'n');
    ifgrsc(i).length = getpar('nlines:',rscmat,'n');
    ifgrsc(i).xfirst = getpar('corner_lon:',rscmat,'n'); 
    ifgrsc(i).xstep  = getpar('post_lon:',rscmat,'n');
    ifgrsc(i).yfirst = getpar('corner_lat:',rscmat,'n');
    ifgrsc(i).ystep  = getpar('post_lat:',rscmat,'n');
    %ifgrsc(i).wvl    = getpar('WAVELENGTH',rscmat,'n');
    ifgrsc(i).xlast  = ifgrsc(i).xfirst + (ifgrsc(i).width-1)*ifgrsc(i).xstep;
    ifgrsc(i).ylast  = ifgrsc(i).yfirst + (ifgrsc(i).length-1)*ifgrsc(i).ystep;
    %clear rscmat;
  end

%check xstep, ystep
xsteps=abs([ifgrsc.xstep]);
ysteps=abs([ifgrsc.ystep]);
minxstep=min(xsteps);
minystep=min(ysteps);
remstep=nnz(abs(xsteps-round(xsteps/minxstep)*minxstep)>1e-6)+nnz(abs(ysteps-round(ysteps/minystep)*minystep)>1e-6);
if remstep>0
  error('pixel size of input files are not consistent');
end

if lksx0==0 | lksy0==0  %using x/y-step if the pixel sizes are different for the original ifgs
  ifghdr.xstep = getpar('xstep:',parmat,'n');
  ifghdr.ystep = getpar('ystep:',parmat,'n');
  ifghdr.xstep = round(ifghdr.xstep/minxstep)*minxstep; %more precise to be integer times of mininum step
  ifghdr.ystep = round(ifghdr.ystep/minystep)*minystep;
else %using looks number if the pixel sizes are the same for all the data
  ifghdr.xstep = ifgrsc(1).xstep*lksx0;
  ifghdr.ystep = ifgrsc(1).ystep*lksy0;
end

%-------------------------------------------------------------------
%find new data locations
if opt==1    %minimum extension
  ifghdr.xfirst=max([ifgrsc.xfirst]);
  ifghdr.yfirst=min([ifgrsc.yfirst]);
  xlast=min([ifgrsc.xlast]);
  ylast=max([ifgrsc.ylast]);
elseif opt==2  %maximum extension
  ifghdr.xfirst=min([ifgrsc.xfirst]);
  ifghdr.yfirst=max([ifgrsc.yfirst]);
  xlast=max([ifgrsc.xlast]);
  ylast=min([ifgrsc.ylast]);
elseif opt==3 %customize extension
  ifghdr.xfirst = getpar('ifgxfirst:',parmat,'n');
  ifghdr.yfirst = getpar('ifgyfirst:',parmat,'n');
  xlast  = getpar('ifgxlast:',parmat,'n');
  ylast  = getpar('ifgylast:',parmat,'n');
else
  error('ERROR: not such options!');
end

ifghdr.width  = floor((xlast-ifghdr.xfirst)/ifghdr.xstep) + 1;
ifghdr.length = floor((ylast-ifghdr.yfirst)/ifghdr.ystep) + 1;
xlast=ifghdr.xfirst+(ifghdr.width-1)*ifghdr.xstep;
ylast=ifghdr.yfirst+(ifghdr.length-1)*ifghdr.ystep;

%calculate approximate pixel size using utm projection, 09/09/2009, HW
origin=[ifghdr.xfirst;ylast];   %bottom-left corner
llh=[xlast;ifghdr.yfirst];      %top-right corner
xy=llh2local(llh,origin);
ifghdr.xpsize=abs(xy(1))/(ifghdr.width-1);
ifghdr.ypsize=abs(xy(2))/(ifghdr.length-1);

fprintf('output data position: xfirst = %12.9f, yfirst = %12.9f, xlast = %12.9f, ylast = %12.9f\n',ifghdr.xfirst,ifghdr.yfirst,xlast,ylast);
fprintf('output data size: width = %5d, length = %5d \n',ifghdr.width,ifghdr.length);

%-------------------------------------------------------------------
%import unwrapped igrams
%the matrix is too large, read each data and then multilooked

%incidence filename
if prjflag~=3
    [incnml] = getextnml_para(ifg_nml,'_incidence');
else % create dummy variables so parallel processing will work
    incnml=NaN(ifghdr.length,ifghdr.width,nifgs,'single');
    inc=zeros(ifghdr.length,ifghdr.width,1,'single');
end

phsout=NaN(ifghdr.length,ifghdr.width,nifgs,'single');
ccout=NaN(ifghdr.length,ifghdr.width,nifgs,'single');
ampout=NaN(ifghdr.length,ifghdr.width,nifgs,'single');

parfor i=1:nifgs
  %calculate look number for each ifg
  if lksx0==0 || lksy0==0
    lksx=round(ifghdr.xstep/ifgrsc(i).xstep);
    lksy=round(ifghdr.ystep/ifgrsc(i).ystep);
  else
    lksx=lksx0;
    lksy=lksy0;
  end

  % Look for existing files (previously processed)
  
  %filenames
  ifgname1 = char(strcat(obsdir,ifg_nml(i)));
  ifgname=char(ifg_nml(i));
  surfix = max(strfind(ifgname,'.'));
  dir1=pwd;
  ifgfillname = char(strcat(dir1,'\obs\',ifgname(1:surfix-1),'_',num2str(lksx),'rlks_fill',ifgname(surfix:length(ifgname))));  
  if ccflag==1
    f1=strfind(ifgname1,'utm');
    f2=strfind(ifgname,'utm');
    ccname1 = char(strcat(ifgname1(1:f1-1),'flat_',ifgname1(f1:f1+3),'cc'));
    ccname = char(strcat(ifgname(1:f2-1),'flat_',ifgname(f2:surfix),'cc'));    
    ccfillname = char(strcat(dir1,'\obs\',ccname(1:surfix),'_utm_',num2str(lksx),'rlks_fill','.cc'));
  end  
  
  %check date and size of the cropped ifgs
  if exist(ifgfillname,'file')
    dir_org=dir(ifgname1);
    dir_fil=dir(ifgfillname);
    date_diff=datenum(dir_fil.date)-datenum(dir_org.date);
    %date
    if date_diff>0
      %size
      nbands=dir_fil.bytes/ifghdr.length/ifghdr.width/4;
      if nbands==1
        %fprintf('file exists, loading: %3d/%-3d - %s ... \n',i,nifgs,char(ifg_nml(i)));
        phsout(:,:,i)=readmat(ifgfillname,ifghdr.length,ifghdr.width,1,'real');
      elseif nbands==2 
        unw=readmat(ifgfillname,ifghdr.length,ifghdr.width,1,'rmg');
        phsout(:,:,i)=unw(:,:,2);
        ampout(:,:,i)=unw(:,:,1);
      end
    end
  else 
     dir_org=dir(ifgname1);      
     new_ifg_list{i,1}=dir_org.name;
  end

  % cc file
  if exist(ccfillname,'file')
    dir_org1=dir(ccname1);
    dir_fil1=dir(ccfillname);
    date_diff1=datenum(dir_fil1.date)-datenum(dir_org1.date);
    %date
    if date_diff1>0
        ccout(:,:,i)=readmat(ccfillname,ifghdr.length,ifghdr.width,1,'real');      
    end
  else
    dir_org1=dir(ccname1);      
    new_cc_list{i,1}=dir_org1.name;
  end
  
end

% list of new files to be processed
for j=1:nifgs
    new_ifg_list{j,2}=j;
    new_cc_list{j,2}=j;    
end

new_ifg_list( cellfun( @(C) isnumeric(C) && isempty(C), new_ifg_list(:,1) ), :) = [];
new_cc_list( cellfun( @(C) isnumeric(C) && isempty(C), new_cc_list(:,1) ), :) = [];


% new ifg files to process
[new_ifg,~]=size(new_ifg_list);

if new_ifg > 0
    %split cell array
    for k=1:new_ifg
        num{k}=new_ifg_list{k,2};
    end    
    [~,num_col]=size(num);
    num2=reshape(num,num_col,1);
    num3=cell2mat(num2);
    ifg_char=num2str(num3);
    
    for l=1:new_ifg
        new_ifg2{l}=new_ifg_list{l,1};
    end
    [~,ifg_col]=size(new_ifg2);
    new_ifg3=reshape(new_ifg2,ifg_col,1);
    new_ifg4=cell2mat(new_ifg3);    

    name1=strcat(new_ifg4,32,ifg_char); %32 indicates ASCII space
    
    parfor m=1:new_ifg
        
       %calculate look number for each ifg
       if lksx0==0 || lksy0==0
           lksx=round(ifghdr.xstep/ifgrsc(m).xstep);
           lksy=round(ifghdr.ystep/ifgrsc(m).ystep);
       else
           lksx=lksx0;
           lksy=lksy0;
       end
        
       name=name1(m,:);
       fprintf('processing new ifg data: %s/%-3d ... \n',name,nifgs);
       ifgname = char(strcat(obsdir,new_ifg3(m)));
       surfix = max(strfind(ifgname,'.'));
       ifgfillname = char(strcat(ifgname(1:surfix-1),'_',num2str(lksx),'rlks_fill',ifgname(surfix:length(ifgname))));       
       dir_ifg=dir(ifgname);
       nbands=dir_ifg.bytes/ifgrsc(m).length/ifgrsc(m).width/4;
      
       %if nbands==2
       %read original data in roi_pac rmg format
        %  unw=readmat(ifgname,ifgrsc(i).length,ifgrsc(i).width,1,'rmg');
       %else
       %changed for gamma
       %  unw=readmat(ifgname,ifgrsc(i).length,ifgrsc(i).width,1,'real');
       %end
       unw=multibandread(ifgname,[ifgrsc(m).length ifgrsc(m).width 1],'real*4',0,'bsq','ieee-be');
       unw(unw==0)=NaN; %zero means NaN in roipac

       %project phase from los to horizontal or vertical
       if prjflag~=3
           inc=readmat(char(strcat(obsdir,incnml(m))),ifgrsc(m).length,ifgrsc(m).width,1,'rmg');
           inc(inc==0)=nan;
           unw(:,:,nbands)=los2hv(unw(:,:,nbands),inc(:,:,1),1,prjflag);
           %clear inc;
       end
       
       %get new dimensions for the output data
       %note: using original pixel spacing, otherwise it may be wrong
       %width/length in original resolution

       orgwidth=ifghdr.width*lksx;
       orglength=ifghdr.length*lksy;
       dnx0 = floor((ifghdr.xfirst-ifgrsc(m).xfirst)/ifgrsc(m).xstep);
       if dnx0>0
           mx0 = dnx0+1;
           x0 = 1;
       else
           mx0 = 1;
           x0 = -dnx0+1;
       end       

       dny0 = floor((ifghdr.yfirst-ifgrsc(m).yfirst)/ifgrsc(m).ystep);
       if dny0>0
           my0 = dny0+1;
           y0 = 1;
       else
           my0 = 1;
           y0 = -dny0+1;
       end

       dnx1 = floor((xlast-ifgrsc(m).xlast)/ifgrsc(m).xstep);
       if dnx1>0
           mx1 = ifgrsc(m).width;
           x1 = orgwidth-dnx1;
       else
           mx1 = ifgrsc(m).width+dnx1;
           x1 = orgwidth;
       end

       dny1=floor((ylast-ifgrsc(m).ylast)/ifgrsc(m).ystep);
       if dny1>0
           my1 = ifgrsc(m).length;
           y1 = orglength - dny1;
       else
           my1 = ifgrsc(m).length + dny1;
           y1 = orglength;
       end      
       
       %it will ocassionally go wrong due to multi-look processing
       %update nx,ny will make the program more stable
       nx = min(x1-x0,mx1-mx0);
       ny = min(y1-y0,my1-my0);
       x1 = x0+nx;
       y1 = y0+ny;
       mx1 = mx0+nx;
       my1 = my0+ny;

       ifgfill=NaN(orglength,orgwidth,'single');%HW, 27/04/2011, use 'single' to save space
       ifgfill(y0:y1,x0:x1)=unw(my0:my1,mx0:mx1,nbands);%get unwrapped phase, assume the last band is phase       
       
       %multilook processing
       phsfill_mlk=looks_para(ifgfill,lksx,lksy);
       
       %unit conversion
       if convflag==1
           phsfill_mlk=(phsfill_mlk*ifgrsc(m).wvl*1000)/(4*pi); %unit convert from rad to mm
       elseif convflag==2
           phsfill_mlk=(phsfill_mlk*4*pi)/ifgrsc(m).wvl;      %unit convert from m to rad
       end
       phsout(:,:,m)=phsfill_mlk;

       %if ampflag==0  %write phase only  % TURNED OFF, PARFOR WON'T WORK WITH RMGDATA SETUP
           writemat(ifgfillname,phsfill_mlk);
       %else  %write amplitude/phase in rmg format
           %ifgfill=NaN(orglength,orgwidth,'single');
           %ifgfill(y0:y1,x0:x1)=unw(my0:my1,mx0:mx1,1); %assume the first band as amplitude data
           %rmgdata(:,:,1)=looks_para(ifgfill,lksx,lksy);
           %rmgdata(:,:,2)=phsfill_mlk;
           %writemat(ifgfillname,rmgdata,1,'rmg');
           %ampout(:,:,m)=rmgdata(:,:,1);
       %end
       %clear rmgdata; 
    end
    
    %save as rsc for sarview
    fprintf('*** %d of %d ifg files have been updated *** \n',new_ifg,nifgs);
    hdr2rsc(ifghdr,char(strcat(obsdir,'ifg.rsc')));
end

    
   

% new cc files to process
[new_cc,~]=size(new_cc_list);

if new_cc > 0
    %split cell array
    for k=1:new_cc
        num{k}=new_cc_list{k,2};
    end    
    [~,num_col]=size(num);
    num2=reshape(num,num_col,1);
    num3=cell2mat(num2);
    cc_char=num2str(num3);
    
    for l=1:new_cc
        new_cc2{l}=new_cc_list{l,1};
    end
    [~,cc_col]=size(new_cc2);
    new_cc3=reshape(new_cc2,cc_col,1);
    new_cc4=cell2mat(new_cc3);    

    name1=strcat(new_cc4,32,cc_char); %32 indicates ASCII space
    
    parfor n=1:new_cc    
        
       %calculate look number for each cc
       if lksx0==0 || lksy0==0
           lksx=round(ifghdr.xstep/ifgrsc(n).xstep);
           lksy=round(ifghdr.ystep/ifgrsc(n).ystep);
       else
           lksx=lksx0;
           lksy=lksy0;
       end
        
       name=name1(n,:);
       fprintf('processing new cc data: %s/%-3d ... \n',name,nifgs);
       ccname = char(strcat(obsdir,new_cc3(n)));
       surfix = max(strfind(ccname,'.'));
       ccfillname = char(strcat(ccname(1:surfix-1),'_',num2str(lksx),'rlks_fill',ccname(surfix:length(ccname))));       
       dir_ifg=dir(ccname);        
       
       if ccflag==1
           cc=multibandread(ccname,[ifgrsc(n).length ifgrsc(n).width 1],'real*4',0,'bsq','ieee-be');
       end     
    
       %get new dimensions for the output data
       %note: using original pixel spacing, otherwise it may be wrong
       %width/length in original resolution

       orgwidth=ifghdr.width*lksx;
       orglength=ifghdr.length*lksy;
       dnx0 = floor((ifghdr.xfirst-ifgrsc(n).xfirst)/ifgrsc(n).xstep);
       if dnx0>0
           mx0 = dnx0+1;
           x0 = 1;
       else
           mx0 = 1;
           x0 = -dnx0+1;
       end       

       dny0 = floor((ifghdr.yfirst-ifgrsc(n).yfirst)/ifgrsc(n).ystep);
       if dny0>0
           my0 = dny0+1;
           y0 = 1;
       else
           my0 = 1;
           y0 = -dny0+1;
       end

       dnx1 = floor((xlast-ifgrsc(n).xlast)/ifgrsc(n).xstep);
       if dnx1>0
           mx1 = ifgrsc(n).width;
           x1 = orgwidth-dnx1;
       else
           mx1 = ifgrsc(n).width+dnx1;
           x1 = orgwidth;
       end

       dny1=floor((ylast-ifgrsc(n).ylast)/ifgrsc(n).ystep);
       if dny1>0
           my1 = ifgrsc(n).length;
           y1 = orglength - dny1;
       else
           my1 = ifgrsc(n).length + dny1;
           y1 = orglength;
       end      
       
       %it will ocassionally go wrong due to multi-look processing
       %update nx,ny will make the program more stable
       nx = min(x1-x0,mx1-mx0);
       ny = min(y1-y0,my1-my0);
       x1 = x0+nx;
       y1 = y0+ny;
       mx1 = mx0+nx;
       my1 = my0+ny;  
       
        if ccflag==1
            ccfill=NaN(orglength,orgwidth,'single');
            ccfill(y0:y1,x0:x1)=cc(my0:my1,mx0:mx1);

            %multilook processing
            ccfill_mlk=looks_para(ccfill,lksx,lksy);
            writemat(ccfillname,ccfill_mlk);
            ccout(:,:,n)=ccfill_mlk;
        end        
    end

    fprintf('*** %d of %d cc files have been updated *** \n',new_cc,nifgs);
end
end