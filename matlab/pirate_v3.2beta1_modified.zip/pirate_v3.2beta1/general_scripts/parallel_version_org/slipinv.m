function [s,stds,ratemap,resmap]=slipinv(stackmap,errormap,vcm,refpt,ifghdr,modelpar,vcmpar,orbdegree,dem)
%=====================================================================
%function [s,stds,ratemap,resmap]=slipinv(stackmap,errormap,vcm,refpt,ifghdr,modelpar,vcmpar,orbdegree,dem)
%                                                                     
% Interseismic fault slip rate inversion using the stacked rate map     
%   rate map and its covariance matrix.           
%                                                                     
% INPUT:                                                              
%   stackmap:  stacked interferogram
%   errormap:  error map (std) for the stacked interferogram
%   vcm_line:  spatial vcm for the first line of the stackmap
%   refpt:     coordinate of the reference point
%   ifghdr:    ifg header for pixel size of the full resolution stackmap
%   modelpar:  initial interseismic deformation model assuming
%              1 mm/yr slip rate
%   vcmpar:    vcm calculation parameters
%   orbdegree: polynominal degree for orbital error correction
%   dem:       input DEM data (optional)
%                                                                   
% OUTPUT:                                                           
%   s:         inverted parameters, including slip rate, tilt,
%              atm correction coefficient, offset.
%   stds:      std of the above parameters
%   ratemap:   rate map
%   resmap:    residual map
%                                                                     
% NB: model                                                           
%     d =   sum(s_i*fmodel_i)
%         + tiltx*(x-refx) + tilty*(y-refy)
%         + c_h*(H-H_ref)
%         + offset                                                    
% Hua Wang @ Uni Leeds, 02/02/2008
%
% TODO:
%   1. downsampling pixels instead of multi-look processing?
%                                                                     
% 10/09/2009 HW: multiple initial models supported
%                quandratic orbital error correction
% 09/09/2009 HW: change input argument from psize to xpsize & ypsize
% 26/08/2009 HW: change dem as an optional parameter and rename slipinvdem.m as slipinv.m
%
%=====================================================================

%---------------------------------------------
%    multi-look processing
%---------------------------------------------
%calculate multi-look number by the dimension of stackmap and vcm_line
lksx=vcmpar.lksx;
lksy=vcmpar.lksy;
[rows,cols]=size(stackmap);
rows_lowres=floor(rows/lksy);
cols_lowres=floor(cols/lksx);
n_lowres=rows_lowres*cols_lowres;
if n_lowres~=size(vcm,2)
  error('wrong input vcm dimension!');
end

% multi-look to the save resolution with vcm_line
[stackmap_lowres] = looks(stackmap,lksx,lksy);
[errormap_lowres] = looks(errormap,lksx,lksy);    %not exactly correct, should use least-squares?
for i=1:modelpar.nmodels
  [fmodel_lowres(:,:,i)] = looks(modelpar.fmodel(:,:,i),lksx,lksy);
end
refx_lowres=floor(refpt.x/lksx);
refy_lowres=floor(refpt.y/lksy);

%---------------------------------------------
%    observations
%---------------------------------------------
%HW: added the following line on 30/10/2009, in case there are some NaNs which do not exist in the ratemap
stackmap_lowres(isnan(fmodel_lowres(:,:,1)))=nan;

datav=reshape(stackmap_lowres',n_lowres,1);
dnan=isnan(datav);
datav(dnan)=[];

%---------------------------------------------
%    design matrix
%---------------------------------------------

[xx,yy]=meshgrid(1:cols_lowres,1:rows_lowres);
xxv=reshape(xx',n_lowres,1);
yyv=reshape(yy',n_lowres,1);
xxv=(xxv-refx_lowres)*ifghdr.xpsize*lksx/100;  %using 100km as unit
yyv=(yyv-refy_lowres)*ifghdr.ypsize*lksy/100;  %using 100km as unit
if orbdegree==1
  tiltsetup=[xxv yyv ones(n_lowres,1)];
else                              %degree == 2
  xxv2 = xxv.*xxv;
  yyv2 = yyv.*yyv;
  xyv  = xxv.*yyv;
  tiltsetup=[xxv2  yyv2  xyv  xxv  yyv ones(n_lowres,1)];
  clear('xxv2','yyv2','xyv');
end
clear('xx','yy','xxv','yyv');

modelv=reshape(permute(fmodel_lowres,[2,1,3]),n_lowres,modelpar.nmodels,1);
B=[modelv tiltsetup];

if nargin>8
  dem=(dem-dem(refpt.y,refpt.x))/1000; %using 1km as unit for dem
  [dem_lowres] = looks(dem,lksx,lksy);
  demv=reshape(dem_lowres',n_lowres,1);
  B=[B demv];
  clear('demv');
end

B(dnan,:)=[];
clear('tiltsetup','modelv');

%---------------------------------------------
%re-calculate the full covariance matrix of the rate map
%---------------------------------------------
if vcmpar.vcmsmethod==2
  vcm = make_vcms_ratemap(vcm,stackmap_lowres,errormap_lowres);
else
  sig = reshape(errormap_lowres',n_lowres,1);
  vcm = (sig*sig').*vcm;
  vcm(dnan,:)=[];
  vcm(:,dnan)=[];
end

%---------------------------------------------
% solve system equation using least-squares
%---------------------------------------------

[nobs,npar]=size(B);

%%% pcg method, by JB,
%%% HW comment, (1) too slow;(2) same result with s=(B*(vcm\B))\(B'*(vcm\datav));
%tol=1e-6;
%maxit=1000;
%y=pcg(vcm,datav,tol,maxit);
%for i=1:npar
%  zn(:,:,i)=[pcg(vcm,B(:,i),tol,maxit)];
%end
%z=reshape(zn,nobs,npar,1);
%s=pcg(B'*z,B'*y,tol,maxit);

%pcg modified by Hua
%tol=1e-6;
%maxit=5000;
%d = B'*(vcm\datav);
%hfun = @(x) B'*(vcm\(B*x));
%s=pcg(hfun,d,tol,maxit);
%v=B*s-datav;
%sigma0=sqrt(v'*(vcm\v)/(nobs-npar));
%stds=sqrt(diag(inv(B'*(vcm\B)))).*sigma0;

%%%calculate the slip rate using least squares
[s,stds,mse]=lscov(double(B),double(datav),double(vcm));

%---------------------------------------------
% output data
%---------------------------------------------

% full resolution orbital errors
n=cols*rows;
[xx,yy]=meshgrid(1:cols,1:rows);
xxv=reshape(xx',n,1);
yyv=reshape(yy',n,1);
xxv=(xxv-refpt.x)*ifghdr.xpsize/100;  %using 100km as unit
yyv=(yyv-refpt.y)*ifghdr.ypsize/100;  %using 100km as unit
if orbdegree==1
  tiltsetup=[xxv yyv ones(n,1)];
else                              %degree == 2
  xxv2 = xxv.*xxv;
  yyv2 = yyv.*yyv;
  xyv  = xxv.*yyv;
  tiltsetup=[xxv2  yyv2  xyv  xxv  yyv ones(n,1)];
  clear('xxv2','yyv2','xyv');
end
clear('xx','yy','xxv','yyv');
tiltpar=s(modelpar.nmodels+1:npar-1);
tiltmap = tiltsetup*tiltpar;
tiltmap = (reshape(tiltmap,cols,rows))';
tiltmap(isnan(stackmap))=NaN;

% full resolution atm errors
if nargin>8
  atmmap = dem.*s(npar);
  atmmap(isnan(stackmap))=NaN;
end

% full resolution models
modelmap=zeros(rows,cols);
for i=1:modelpar.nmodels
  modelmap=modelmap+modelpar.fmodel(:,:,i)*s(i);
end

% full resolution residues (v=Bx-L)
resmap = modelmap+tiltmap+atmmap-stackmap;

% full resolution ratemap
ratemap = stackmap-tiltmap-atmmap;
