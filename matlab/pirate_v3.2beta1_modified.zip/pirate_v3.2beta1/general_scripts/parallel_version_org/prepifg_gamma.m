function [phsout,ifghdr,ccout,ampout] = prepifg(obsdir,ifg_nml,parmat,convflag,ampflag,prjflag,ccflag)
%===================================================================
%function [phsout,ifghdr,ampout] = prepifg(obsdir,ifg_nml,parmat,convflag,ampflag,prjflag)
%                                                                   
% Prepare a serial of data by filling NaN for smaller ifgs.
%
% INPUT:
%   obsdir: directory of the input data
%   ifg_nml: input data namelist, the first 17 characters my be                      
%                format: geo_yymmdd_yymmdd....
%                        (4c)(mas)  (slv) (others)
%   parmat: a two column matrix to save all the configure parameters (optional)
%   convflag: unit conversion flag (optional, default 1)
%           (1: radius -> mm, 2: metre -> radius, 3: no conversion)
%   ampflag: calculate amplitude (optional, 1-calculate, default 0)
%   prjflag: projection flag (optional, default 3)
%           (1: los->vertical, 2: los -> horizontal, 3: no projection)
%
% OUTPUT:
%   phsout: output phase data
%   ifghdr: header parameters for the output data
%   ampout: output amplitude data
%
% Note: Assuming the last band is unwrapped phase
%
% Hua Wang @ Uni Leeds, 06/02/2009
%
% 24/09/2012 HW: read 'real' data for gamma outputs
% 10/02/2012 HW: make all output optional to save memory
% 06/01/2012 HW: project los to h/v for multi-tracks/-satellites processing
% 16/07/2011 HW: replace ifghdr.mat as ifg.rsc
% 16/07/2011 HW: check date and size of the cropped ifgs instead of using ifghdr.mat
% 10/05/2011 HW: make parmat as optional
% 27/04/2011 HW: replace 'multibandread' by 'readmat' to save space
% 30/01/2010 HW: calculate mean amplitude
% 09/09/2009 HW: calculate approximate pixel size (km) using utm projection
%===================================================================
%load mask.mat
%unit conversion, added on 19/08/2009 by HW to be compatible with baseline file
if nargin<4
  convflag=1;
end

%calculate amplitude data
if nargin<5
  ampflag=0;
end

%projection, added on 06/01/2012 for multiple tracks processing
if nargin<6
  prjflag=3;
end

%coherence flag added by MG on 5/8/2015 for coherence analysis
if nargin<7
  ccflag=0;
end

%get parameters from the configure file
%   opt: options for the output data
%        (1: minimum extension; 2: maximum extension; 3: customize)
if nargin<3 
  parmat=[];
end
if isempty(parmat)
  opt=2;
  lksx0=1;
  lksy0=1;
else
  opt = getpar('ifgcropopt:',parmat,'n');
  lksx0 = getpar('ifglksx:',parmat,'n',0);
  lksy0 = getpar('ifglksy:',parmat,'n',0);
end

%read the data file list
nifgs = length(ifg_nml);

%-------------------------------------------------------------------
%import parameters in the resource file for each data
%only compatible for roi_pac format
%X_FIRST: topleft east
%Y_FIRST: topleft north
  %rscname = char(strcat(obsdir,ifg_nml(i),'.rsc'));
  parfile=getpar('parfile:',parmat,'s');
  [rscmat] = readparfile_gamma(parfile);
for i=1:nifgs
  ifgrsc(i).width  = getpar('width:',rscmat,'n');
  ifgrsc(i).length = getpar('nlines:',rscmat,'n');
  ifgrsc(i).xfirst = getpar('corner_lon:',rscmat,'n'); 
  ifgrsc(i).xstep  = getpar('post_lon:',rscmat,'n');
  ifgrsc(i).yfirst = getpar('corner_lat:',rscmat,'n');
  ifgrsc(i).ystep  = getpar('post_lat:',rscmat,'n');
  %ifgrsc(i).wvl    = getpar('WAVELENGTH',rscmat,'n');
  ifgrsc(i).xlast  = ifgrsc(i).xfirst + (ifgrsc(i).width-1)*ifgrsc(i).xstep;
  ifgrsc(i).ylast  = ifgrsc(i).yfirst + (ifgrsc(i).length-1)*ifgrsc(i).ystep;
  %clear rscmat;
end

%check xstep, ystep
xsteps=abs([ifgrsc.xstep]);
ysteps=abs([ifgrsc.ystep]);
minxstep=min(xsteps);
minystep=min(ysteps);
remstep=nnz(abs(xsteps-round(xsteps/minxstep)*minxstep)>1e-6)+nnz(abs(ysteps-round(ysteps/minystep)*minystep)>1e-6);
if remstep>0
  error('pixel size of input files are not consistent');
end

if lksx0==0 | lksy0==0  %using x/y-step if the pixel sizes are different for the original ifgs
  ifghdr.xstep = getpar('xstep:',parmat,'n');
  ifghdr.ystep = getpar('ystep:',parmat,'n');
  ifghdr.xstep = round(ifghdr.xstep/minxstep)*minxstep; %more precise to be integer times of mininum step
  ifghdr.ystep = round(ifghdr.ystep/minystep)*minystep;
else %using looks number if the pixel sizes are the same for all the data
  ifghdr.xstep = ifgrsc(1).xstep*lksx0;
  ifghdr.ystep = ifgrsc(1).ystep*lksy0;
end

%-------------------------------------------------------------------
%find new data locations
if opt==1    %minimum extension
  ifghdr.xfirst=max([ifgrsc.xfirst]);
  ifghdr.yfirst=min([ifgrsc.yfirst]);
  xlast=min([ifgrsc.xlast]);
  ylast=max([ifgrsc.ylast]);
elseif opt==2  %maximum extension
  ifghdr.xfirst=min([ifgrsc.xfirst]);
  ifghdr.yfirst=max([ifgrsc.yfirst]);
  xlast=max([ifgrsc.xlast]);
  ylast=min([ifgrsc.ylast]);
elseif opt==3 %customize extension
  ifghdr.xfirst = getpar('ifgxfirst:',parmat,'n');
  ifghdr.yfirst = getpar('ifgyfirst:',parmat,'n');
  xlast  = getpar('ifgxlast:',parmat,'n');
  ylast  = getpar('ifgylast:',parmat,'n');
else
  error('ERROR: not such options!');
end

ifghdr.width  = floor((xlast-ifghdr.xfirst)/ifghdr.xstep) + 1;
ifghdr.length = floor((ylast-ifghdr.yfirst)/ifghdr.ystep) + 1;
xlast=ifghdr.xfirst+(ifghdr.width-1)*ifghdr.xstep;
ylast=ifghdr.yfirst+(ifghdr.length-1)*ifghdr.ystep;

%calculate approximate pixel size using utm projection, 09/09/2009, HW
origin=[ifghdr.xfirst;ylast];   %bottom-left corner
llh=[xlast;ifghdr.yfirst];      %top-right corner
xy=llh2local(llh,origin);
ifghdr.xpsize=abs(xy(1))/(ifghdr.width-1);
ifghdr.ypsize=abs(xy(2))/(ifghdr.length-1);

fprintf('output data position: xfirst = %12.9f, yfirst = %12.9f, xlast = %12.9f, ylast = %12.9f\n',ifghdr.xfirst,ifghdr.yfirst,xlast,ylast);
fprintf('output data size: width = %5d, length = %5d \n',ifghdr.width,ifghdr.length);

%-------------------------------------------------------------------
%import unwrapped igrams
%the matrix is too large, read each data and then multilooked

%incidence filename
if prjflag~=3
 [incnml] = getextnml(ifg_nml,'_incidence');
end

inewrsc=0;
if nargout>0
  phsout=NaN(ifghdr.length,ifghdr.width,nifgs,'single');
end
if nargout>2
  ampout=NaN(ifghdr.length,ifghdr.width,nifgs,'single');
end
for i=1:1

  %calculate look number for each ifg
  if lksx0==0 | lksy0==0
    lksx=round(ifghdr.xstep/ifgrsc(i).xstep);
    lksy=round(ifghdr.ystep/ifgrsc(i).ystep);
  else
    lksx=lksx0;
    lksy=lksy0;
  end

  %filename
  ifgname = char(strcat(obsdir,ifg_nml(i)));
  surfix = max(strfind(ifgname,'.'));
  ifgfillname = char(strcat(ifgname(1:surfix-1),'_',num2str(lksx),'rlks_fill',ifgname(surfix:length(ifgname))));
  if ccflag==1
    fl=strfind(ifgname,'utm');
    ccname = char(strcat(ifgname(1:fl-1),'flat_',ifgname(fl:surfix),'cc'));
    ccfillname = char(strcat(ccname(1:surfix),'_utm_',num2str(lksx),'rlks_fill','.cc'));  
  end
  
  %check date and size of the cropped ifgs
  if exist(ifgfillname,'file')
    dir_org=dir(ifgname);
    dir_fil=dir(ifgfillname);
    date_diff=datenum(dir_fil.date)-datenum(dir_org.date);
    %date
    if date_diff>0
      %size
      nbands=dir_fil.bytes/ifghdr.length/ifghdr.width/4;
      if nbands==1
        if nargout>0
          phsout(:,:,i)=readmat(ifgfillname,ifghdr.length,ifghdr.width,1,'real');
          ccout(:,:,i)=readmat(ccfillname,ifghdr.length,ifghdr.width,1,'real');
        end
        continue
      elseif nbands==2
        unw=readmat(ifgfillname,ifghdr.length,ifghdr.width,1,'rmg');
        if nargout>0
          phsout(:,:,i)=unw(:,:,2);
        end
        if nargout>2
          ampout(:,:,i)=unw(:,:,1);
        end
        continue
      end
    end
  end

  %update newrsc
  inewrsc=inewrsc+1;
  fprintf('processing new data: %3d/%-3d - %s ... \n',i,nifgs,char(ifg_nml(i)));
  
  dir_ifg=dir(ifgname);
  nbands=dir_ifg.bytes/ifgrsc(i).length/ifgrsc(i).width/4;
  %if nbands==2
    %read original data in roi_pac rmg format
  %  unw=readmat(ifgname,ifgrsc(i).length,ifgrsc(i).width,1,'rmg');
  %else
    %changed for gamma
  %  unw=readmat(ifgname,ifgrsc(i).length,ifgrsc(i).width,1,'real');
  %end
  unw=multibandread(ifgname,[ifgrsc(i).length ifgrsc(i).width 1],'real*4',0,'bsq','ieee-be');
  unw(unw==0)=NaN; %zero means NaN in roipac
  if ccflag==1
    cc=multibandread(ccname,[ifgrsc(i).length ifgrsc(i).width 1],'real*4',0,'bsq','ieee-be');
  end
  %project phase from los to horizontal or vertical
  if prjflag~=3
    inc=readmat(char(strcat(obsdir,incnml(i))),ifgrsc(i).length,ifgrsc(i).width,1,'rmg');
    inc(inc==0)=nan;
    unw(:,:,nbands)=los2hv(unw(:,:,nbands),inc(:,:,1),1,prjflag);
    clear inc;
  end

  %get new dimensions for the output data
  %note: using original pixel spacing, otherwise it may be wrong
  %width/length in original resolution
  orgwidth=ifghdr.width*lksx;
  orglength=ifghdr.length*lksy;
  dnx0 = floor((ifghdr.xfirst-ifgrsc(i).xfirst)/ifgrsc(i).xstep);
  if dnx0>0
    ix0 = dnx0+1;
    x0 = 1;
  else
    ix0 = 1;
    x0 = -dnx0+1;
  end

  dny0 = floor((ifghdr.yfirst-ifgrsc(i).yfirst)/ifgrsc(i).ystep);
  if dny0>0
    iy0 = dny0+1;
    y0 = 1;
  else
    iy0 = 1;
    y0 = -dny0+1;
  end

  dnx1 = floor((xlast-ifgrsc(i).xlast)/ifgrsc(i).xstep);
  if dnx1>0
    ix1 = ifgrsc(i).width;
    x1 = orgwidth-dnx1;
  else
    ix1 = ifgrsc(i).width+dnx1;
    x1 = orgwidth;
  end

  dny1=floor((ylast-ifgrsc(i).ylast)/ifgrsc(i).ystep);
  if dny1>0
    iy1 = ifgrsc(i).length;
    y1 = orglength - dny1;
  else
    iy1 = ifgrsc(i).length + dny1;
    y1 = orglength;
  end

  %it will ocassionally go wrong due to multi-look processing
  %update nx,ny will make the program more stable
  nx = min(x1-x0,ix1-ix0);
  ny = min(y1-y0,iy1-iy0);
  x1 = x0+nx;
  y1 = y0+ny;
  ix1 = ix0+nx;
  iy1 = iy0+ny;

  ifgfill=NaN(orglength,orgwidth,'single');%HW, 27/04/2011, use 'single' to save space
  ifgfill(y0:y1,x0:x1)=unw(iy0:iy1,ix0:ix1,nbands);%get unwrapped phase, assume the last band is phase

  %multilook processing
  phsfill_mlk=looks(ifgfill,lksx,lksy);

  %unit conversion
  if convflag==1
    phsfill_mlk=(phsfill_mlk*ifgrsc(i).wvl*1000)/(4*pi); %unit convert from rad to mm
  elseif convflag==2
    phsfill_mlk=(phsfill_mlk*4*pi)/ifgrsc(i).wvl;      %unit convert from m to rad
  end
  
  if nargout>0
    phsout(:,:,i)=phsfill_mlk;
  end

  if ampflag==0  %write phase only
    writemat(ifgfillname,phsfill_mlk);
  else  %write amplitude/phase in rmg format
    ifgfill=NaN(orglength,orgwidth,'single');
    ifgfill(y0:y1,x0:x1)=unw(iy0:iy1,ix0:ix1,1); %assume the first band as amplitude data
    rmgdata(:,:,1)=looks(ifgfill,lksx,lksy);
    rmgdata(:,:,2)=phsfill_mlk;
    writemat(ifgfillname,rmgdata,1,'rmg');
    if nargout>3
      ampout(:,:,i)=rmgdata(:,:,1);
    end
    clear rmgdata;
  end
    
  if ccflag==1
    ccfill=NaN(orglength,orgwidth,'single');
    ccfill(y0:y1,x0:x1)=cc(iy0:iy1,ix0:ix1);

    %multilook processing
    ccfill_mlk=looks(ccfill,lksx,lksy);
    writemat(ccfillname,ccfill_mlk);
    if nargout>2
      ccout(:,:,i)=ccfill_mlk;
    end
  end
  clear('ifgfill','phsfill_mlk','unw','ccfill_mlk','cc');
end

%save as rsc for sarview
fprintf('*** %d of %d ifgs have been updated *** \n',inewrsc,nifgs);
if inewrsc>0
  hdr2rsc(ifghdr,char(strcat(obsdir,'ifg.rsc')));
end
