function [] = setparsfull(conf,realdata)
%======================================================
%function [] = setparsfull(conf,realdata)
%
% Function to set configure parameters for PIRATE  
%                                                      
% INPUT:                                               
%   conf:  configure file 
%   realdata: default 1: real data; 0: synthetic data
% OUTPUT:                                              
%   None                            
%                                                      
% Hua Wang, 12/05/2010                         
%======================================================

if nargin<1
  conf='pirate.conf';
end
if nargin<2
  realdata=1;
end

fid = fopen(conf,'w');
if fid<0
  error(['Fail to open configure file:' conf]);
end
sepstr='#------------------------------------\n';

%-------------------------
% input/output parameters
%-------------------------
fprintf(fid,sepstr);
fprintf(fid,'# input/output parameters\n');
printpar(fid,'demfile:','/home/hwang/demdata/wtibet/wtibet_5rlks.dem');

%--------------------------------
% interferogram crop paramters
%--------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# interferogram crop options\n');
fprintf(fid,'# 1: minimum 2: maximum 3: customize\n');
fprintf(fid,'# lksx,lksy: looks in x-/y-axis direction respectively\n');
fprintf(fid,'# xfirst,yfirst: x,y of top-left corner\n');
fprintf(fid,'# xlast,ylast: x,y of bottom-right corner\n');
printpar(fid,'ifgcropopt:','3');
printpar(fid,'ifglksx:','5');
printpar(fid,'ifglksy:','5');
printpar(fid,'ifgxfirst:','76.758331430');
printpar(fid,'ifgxlast:','79.669163599');
printpar(fid,'ifgyfirst:','38.0'); 
printpar(fid,'ifgylast:','32.5'); 

%------------------------------------
%% stacking parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# stacking parameters\n');
fprintf(fid,'# pthr: minimum number of coherent ifgs for each pixel\n');        
printpar(fid,'pthr:','10');

%------------------------------------
%% profile parameters
%------------------------------------
fprintf(fid,sepstr);
fprintf(fid,'# profile parameters\n');
printpar(fid,'make_prof:','1');
printpar(fid,'gmtfaultfile:','/home/hwang/catalogue/com/HimaTibetMap-1.0-gmt/asia.gmt');

fclose(fid);

%--------------------------------------------
function printpar(fid,parname,parval)
fprintf(fid,'%-25s %-25s\n',parname,parval);
