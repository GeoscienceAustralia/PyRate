function [ifm_post] = postseismic_para(ifglist,dir,filelist,ifghdr)
%===========================================================
%function [ifm_post] = postseismic(ifglist,dir,filelist,ifghdr)
%
% Function to read cumulative postseismic deformation time slices 
% in real*4 format from external code and produce corrections 
% for each interferogram
%
% Matt Garthwaite, 01/10/2012                        
%===========================================================

[list] = textread(filelist,'%s');

natm=length(list);

nifg=length(ifglist.id);

% read, crop and multilook the delay maps
parfor i=1:natm
    [in]=imagecrop(char(strcat(dir,list(i))),ifghdr,1);
    ep_ps(:,:,i)=in;
end

% from the epochal delay maps, create interferogram delay maps
parfor j=1:nifg
    diff=ep_ps(:,:,ifglist.slvnum(j))-ep_ps(:,:,ifglist.masnum(j));
    ifm_post(:,:,j)=diff;
end




