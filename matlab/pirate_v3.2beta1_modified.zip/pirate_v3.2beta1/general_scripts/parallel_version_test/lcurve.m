function [smfbest,lcv]=lcurve(ifg,ifglist,epochlist,vcm,tspar,iplot,mstmat,cbasep,tsdir,stepincr)
%=============================================================================
%function [smfbest,lcv]=lcurve(ifg,ifglist,epochlist,vcm,tspar,iplot,mstmat,cbasep,tsdir,stepincr)
%                                                                    
% Calculate L-curve and best-fitted smoothing factor for time series inversion
%
% INPUT:
%   ifg:       interferograms
%   ifglist:   interferogram list
%   epochlist: epochlist
%   vcm:       temporal covariance matrix for each pixel
%   tspar:     time series parameters, see getparsts.m for details
%   iplot:     flag to plot (1: plot, 0: no, default 1)
%   mstmat:    mst matrix to identify independent ifgs (optional)
%   cbasep:    coefficients of perpendicular baseline (optional)
%   tsdir:     output directory for the lcurve data (optional)
%   stepincr: step flag for each incremental (optional, 0: no step; 1: step)
%
% OUTPUT:
%   smfbest:   best-fitted smoothing factor
%   lcv:       smf/rough/wrss for l-curve plot
%
% Hua Wang @ Uni Leeds, 24/08/2009
%
% 14/08/2012 HW: output lcurve data for plot
% 12/09/2009 HW: automatically find best-fitted smoothing factor by lcorner.m
%=============================================================================

[rows,cols,nifgs]=size(ifg);
if nargin<5
  error('at least 5 input arguments needed')
end
if nargin<6
  iplot=1;
end

smf=(tspar.smf_min:tspar.smf_int:tspar.smf_max);
smf=10.^smf;
nsmf=length(smf);

%subsample the ifgs on a sparse regular grid
ix=(1:tspar.lcurv_lksx:cols);
iy=(1:tspar.lcurv_lksy:rows);
ifg_smp=ifg(iy,ix,:);
clear ifg;

%subsample mst matrix
if nargin<7
  mstmat=~isnan(ifg);
end
mstmat_smp=mstmat(iy,ix,:);
clear mstmat;

%subsample perpendicular baseline
if nargin<8
  cbasep=[];
end
if ~isempty(cbasep)
  cbasep_smp=cbasep(iy,ix,:);
  clear cbasep;
else
  cbasep_smp=[];
end

%output directory
if nargin<9
  tsdir=[];
end

%earthquake list
if nargin<10
  stepincr=[];
end

[rows_smp,cols_smp,nifgs]=size(ifg_smp);

%calculate wrss and roughness
for i=1:nsmf
  fprintf('processing for the %d/%-d smoothing factor...\n',i,nsmf);
  tspar.smf=smf(i);
  if tspar.method==1
    [wrss(i),rough(i)]=tsinvlap(ifg_smp,ifglist,epochlist,vcm,tspar,mstmat_smp,cbasep_smp,stepincr);
  else
    [wrss(i),rough(i)]=tsinvbsp(ifg_smp,ifglist,epochlist,vcm,tspar,mstmat_smp,cbasep_smp,stepincr);
  end
end

lcv=double([smf' rough' wrss']);
save(char(strcat(tsdir,'lcurve.dat')),'lcv','-ASCII');

%find best-fitted smoothing factor
%not well done yet, commented by HW
%[smfbest]=lcorner(rough,wrss,smf,5,iplot);

%wrss .vs. roughness plot
if iplot==1
  figure
  plot(rough,wrss,'-bo','LineWidth',1,'MarkerEdgeColor','r','MarkerFaceColor','g','MarkerSize',6);
  for i=1:nsmf
    text(double(rough(i)+0.01),double(wrss(i)+0.02),num2str(smf(i),'%5.3f'));
  end
  ylabel('weighted residual sum of squares (mm^2)','fontsize',12)
  xlabel('solution roughness (mm^2)','fontsize',12)
  smfbest = input('PLEASE INPUT SMOOTHING FACTOR:');
end
