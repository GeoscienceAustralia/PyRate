function [out] = imagecrop(infile,ifghdr,prec,interleave,nanval,iwrite)
%===================================================================
%function [out] = imagecrop(infile,ifghdr,prec,interleave,nanval,iwrite)
%                                                                   
% Crop/Fill an image to the demension defined by a header file
%
% INPUT:
%   infile:  input filename
%   ifghdr:  input header
%   prec:    precision of input file, 1: real4 (default); 2: int16; 3: int8; others: double            
%   interleave: the format in which the data is stored (default: 'real'; 'complex'; 'rmg')
%   nanval:  replace nanval as NaN 
%   iwrite: output as a file
%
% OUTPUT:
%   out:  output data
%
% Hua Wang @ Uni Leeds, 22/09/2009
%
% 10/01/2012 HW: crop in original resolution before multilook
% 24/08/2011 HW: add nanval as 0 means NaN in roipac
% 18/05/2011 HW: replace multibandread by readmat
%===================================================================
if nargin<3
  prec=1;
end

if nargin<4
  interleave='real';
end

if nargin<6
  iwrite=0;
end

%import parameters in the resource file for each data
%only compatible for roi_pac format
%X_FIRST: topleft east
%Y_FIRST: topleft north
rscname = char(strcat(infile,'.rsc'));
inrsc=rsc2hdr(rscname);
inrsc.xlast=inrsc.xfirst+(inrsc.width-1)*inrsc.xstep;
inrsc.ylast=inrsc.yfirst+(inrsc.length-1)*inrsc.ystep;

lksx = round(ifghdr.xstep/inrsc.xstep);
lksy = round(ifghdr.ystep/inrsc.ystep);
xlast=ifghdr.xfirst+(ifghdr.width-1)*ifghdr.xstep;
ylast=ifghdr.yfirst+(ifghdr.length-1)*ifghdr.ystep;

%read original data in roi_pac rmg format
unw=readmat(infile,inrsc.length,inrsc.width,prec,interleave);
nband=size(unw,3);
if nargin>4
  unw(unw==nanval)=NaN;
end

%get new dimensions for the output data
%note: using original pixel spacing, otherwise it may be wrong
orgwidth=ifghdr.width*lksx;
orglength=ifghdr.length*lksy;
dnx0 = floor((ifghdr.xfirst-inrsc.xfirst)/inrsc.xstep);
if dnx0>0
  ix0 = dnx0+1;
  x0 = 1;
else
  ix0 = 1;
  x0 = -dnx0+1;
end

dny0 = floor((ifghdr.yfirst-inrsc.yfirst)/inrsc.ystep);
if dny0>0
  iy0 = dny0+1;
  y0 = 1;
else
  iy0 = 1;
  y0 = -dny0+1;
end

dnx1 = floor((xlast-inrsc.xlast)/inrsc.xstep);
if dnx1>0
  ix1 = inrsc.width;
  x1 = orgwidth-dnx1;
else
  ix1 = inrsc.width+dnx1;
  x1 = orgwidth;
end

dny1=floor((ylast-inrsc.ylast)/inrsc.ystep);
if dny1>0
  iy1 = inrsc.length;
  y1 = orglength - dny1;
else
  iy1 = inrsc.length + dny1;
  y1 = orglength;
end

%it will ocassionally go wrong due to multi-look processing
%update nx,ny will make the program more stable
nx = min(x1-x0,ix1-ix0);
ny = min(y1-y0,iy1-iy0);
x1 = x0+nx;
y1 = y0+ny;
ix1 = ix0+nx;
iy1 = iy0+ny;

%crop in original resolution
croporg=NaN(orglength,orgwidth,nband,'single');
croporg(y0:y1,x0:x1,:)=unw(iy0:iy1,ix0:ix1,:);
clear unw;

%multilook
for i=1:nband
  out(:,:,i)=looks(croporg(:,:,i),lksx,lksy);
end

if iwrite>0
  surfix = max(strfind(inname,'.'));
  infillname = strcat(inname(1:surfix-1),'_',num2str(lksx),'rlks_fill',inname(surfix:length(inname)));
  writemat(infillname,out);
end
