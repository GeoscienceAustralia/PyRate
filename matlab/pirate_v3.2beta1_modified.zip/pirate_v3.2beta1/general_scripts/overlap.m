function[]=overlap(ifg1,ifg2,ifghdr1,ifghdr2)

% Identify overlap between two images (adjacent tracks)



% Calculate geographic coordinates of combined images
[rows1,cols1]=size(ifg1);
[rows2,cols2]=size(ifg2);

[minx]=[ifghdr1.xfirst,ifghdr2.xfirst];
min_x=min(minx);

[maxx]=[ifghdr1.xfirst+(cols1-1)*ifghdr1.xstep,ifghdr2.xfirst+(cols2-1)*ifghdr2.xstep];
max_x=max(maxx);

[miny]=[ifghdr1.yfirst,ifghdr2.yfirst];
min_y=max(miny);

[maxy]=[ifghdr1.yfirst+(rows1-1)*ifghdr1.ystep,ifghdr2.yfirst+(rows2-1)*ifghdr2.ystep];
max_y=min(maxy);

rows3=((max_y-min_y)/ifghdr1.ystep)+1;
%round to up to nearest integer (due to different no. rows in images)
rows=ceil(rows3); 


% if images not same length, then need add zeros to fill to same length
if ifghdr1.yfirst ~= min_y
    % pad top of ifg1
    A=ifg1;
    Aa1=zeros(1,(size(ifg1,2)));
    Aa1(Aa1 == 0) = NaN;
    ifg1=[Aa1 ; ifg1];
elseif ifghdr2.yfirst ~= min_y
    % pad top of ifg2
    A=ifg2;
    Aa2=zeros(1,(size(ifg2,2)));
    Aa2(Aa2 == 0) = NaN;
    ifg2=[Aa2 ; ifg2];
else
    ; % do nothing(already same length)
end

x_diff=minx(1)-minx(2);
y_diff=max_y;

% calculate geographic coordinates for centre pixel and square
x11=ifghdr2.xfirst;
y11=ifghdr2.yfirst;
dx=ifghdr2.xstep;
dy=ifghdr2.ystep;
R=makerefmat(x11, y11, dx, dy);
[row_lat, col_lon] = latlon2pix(R,y_diff,x_diff);
temp=col_lon/360;
cols_lon=ceil(temp);

% need to make ifg1 same width as out
A1=ifg1;
A11=zeros(rows,cols_lon);
A11(A11 == 0) = NaN;
ifg1=horzcat(A11,A1);
ifg1(ifg1 == 0) = NaN;

% need to make ifg2 same width as out
A2=ifg2;
A22=zeros(rows,cols_lon);
A22(A22 == 0) = NaN;
ifg2=horzcat(A2,A22);
ifg2(ifg2 == 0) = NaN;

% Plot figures
figure

[rows1,cols1]=size(ifg1);

% modify ifghdr
ifghdr1v2=ifghdr1;
ifghdr1v2.xfirst=ifghdr1.xfirst-(ifghdr1.xstep*cols_lon);
ifghdr1v2.width=cols1;

x1=[ifghdr1v2.xfirst,ifghdr1v2.xfirst+(cols1-1)*ifghdr1.xstep];
y1=[ifghdr1.yfirst,ifghdr1.yfirst+(rows1-1)*ifghdr1.ystep];

h1=imagesc(x1,y1,ifg1);
set(gca,'YDir','normal');
colormap(jet);
axis equal;
axis image;
set(h1,'alphadata',~isnan(ifg1));
hold on

h2=imagesc(x1,y1,ifg2);
set(gca,'YDir','normal');
colormap(jet);
axis equal;
axis image;
set(h2,'alphadata',~isnan(ifg2));



% Find overlap
ifg1_nan=~isnan(ifg1);
ifg2_nan=~isnan(ifg2);
ifg_comb=ifg1_nan+ifg2_nan;

%[comb_row, comb_col]=find(ifg_comb == 2);

ifg3=ifg1;
ifg3(ifg_comb~=2)=NaN;
ifg3v=reshape(ifg3,numel(ifg3),1);
ifg3v(isnan(ifg3v))=[];

%figure
%h3=imagesc(x1,y1,ifg1);
%set(gca,'YDir','normal');
%colormap(jet);
%axis equal;
%axis image;
%set(h3,'alphadata',~isnan(ifg1));

ifg4=ifg2;
ifg4(ifg_comb~=2)=NaN;
ifg4v=reshape(ifg4,numel(ifg4),1);
ifg4v(isnan(ifg4v))=[];


diff=ifg3-ifg4;
avg=(ifg3+ifg4)./ifg_comb;
%diff=ifg3+ifg4; % for working out max no. pixels

figure
h3=imagesc(x1,y1,diff);
set(gca,'YDir','normal');
colormap(jet);
axis equal;
axis image;
set(h3,'alphadata',~isnan(diff));

%figure
%h4=imagesc(x1,y1,ifg2);
%set(gca,'YDir','normal');
%colormap(jet);
%axis equal;
%axis image;
%set(h4,'alphadata',~isnan(ifg2));


diffv=reshape(diff,rows1*cols1,1);
diffv(isnan(diffv))=[];
figure
histogram(diffv,100)


% Join ifgs together into one image

%remove overlap from each ifg
ifg5=ifg1;
ifg5(ifg_comb==2)=NaN;
ifg6=ifg2;
ifg6(ifg_comb==2)=NaN;

%change NaN values in each ifg
%[x,y]=find(ifg5 == 0.00001)
val=0.00001;
ifg5(isnan(ifg5)) = val;
ifg6(isnan(ifg6)) = val;

%change NaN values in overlap
diff2=diff;
diff2(isnan(diff2)) = val;

%join all together
ifg7=ifg5+diff2+ifg6;

%change val back to NaN values
val2=val*3;
ifg7(ifg7 == val2) = NaN;







end