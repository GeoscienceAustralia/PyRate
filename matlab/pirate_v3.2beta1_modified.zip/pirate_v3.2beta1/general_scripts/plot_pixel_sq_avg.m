function[]=plot_pixel_sq_avg(ts,ifghdr,epochlist,flag,grid_size,icol,irow)
%==================================================================
%function[]=plot_pixel_sq_avg(ts,ifghdr,epochlist,flag,grid_size,icol,irow)
%
% Function to plot the average time series for a square centred on a
% single pixel that is selected by the user.
%                                                                  
% INPUT:                                                           
%   ts:        time series in 3D matrix (eg. outdata.tscum)                          
%   epochlist: epochlist   
%   ifghdr:    ifg header
%   flag:      flag for time series plot                     
%                1: plot displacements (for tscum/tsincr) 
%                2: plot velocities (for tsincr) 
%   grid_size: size of square (eg. 10 equals a square of 21x21 pixels)
%   icol/irow: column and row number (optional, can select from image)
%
% OUTPUT:                                                          
%   Text file with values for plotting in GMT                                                            
%                                                                  
% Sarah Lawrie @ GA, 24/09/2015
%
%==================================================================

% Set default flag if none identified
if nargin<4
  flag=1;
end

[nrows,ncols,nts]=size(ts);

% Identify pixel point from image (if not already identified)
if nargin<6
    figure
    image=ts(:,:,nts);
    h=imagesc(image);
    freezeColors(h);
    colormap(jet);
    colorbar;
    axis equal;
    axis image;
    z=double(~isnan(image));
    alpha(z);
    set(gcf,'Color',[1 1 1]); set(gca,'Color',[.8 .8 .8]); set(gcf,'InvertHardCopy','off');
    fprintf('\n click pixel for time-series plot, enter to end')
    [icol,irow]=getpts(gcf);
end

% If selected from image, initial values have decimals, these need to be rounded to enable data extraction
icol=round(icol); 
irow=round(irow);

% Re-order time series columns to: num, col, row
ts=permute(ts,[3,2,1]);

% Convert epoch span into year increments
span=diff(epochlist.span); %unit in year

if flag~=1
  ts=ts./repmat(span,[1,ncols,nrows]);
end

% Create pixel square grid
icol_min=icol-grid_size;
icol_max=icol+grid_size;
irow_min=irow-grid_size;
irow_max=irow+grid_size;

[Xa,Ya]=meshgrid(icol_min:icol_max,irow_min:irow_max);
[len,wid]=size(Ya);
X=reshape(Xa,len*wid,1);
Y=reshape(Ya,len*wid,1);

% Get pixel value for each cell and put into cell array
tot_pix=numel(X);
for i=1:tot_pix
    x_pt=X(i);
    y_pt=Y(i);
    data{i}=ts(:,x_pt,y_pt);%pixel results
end

% Combine pixel results into a single variable (no. ts by no. pixels)
pix_data=horzcat(data{:});

% Reshape pix_data so each column represents an epoch
[pix_rows,pix_cols]=size(pix_data);
for i=1:pix_rows
    list=pix_data(i,1:pix_cols);
    list2=reshape(list,[pix_cols,1]);
    if i == 1;
        pixel_data=horzcat(list2);
    else
        pixel_data=horzcat(pixel_data,list2);
    end
end
[p_rows,p_cols]=size(pixel_data);

% Find average value for each epoch (avg each col) ignores NaN values
M=nanmean(pixel_data);

% Calculate standard deviation for each epoch ignore NaN values
S=nanstd(pixel_data);

% Calculate the confidence interval (95%)
ci=0.95;
alpha2=1-ci;
n=p_rows;
t_multiplier=tinv(1-alpha2/2,n-1);
ci95=t_multiplier*S/sqrt(n);

% Reshape into single column with an epoch per row
M2=reshape(M,[pix_rows,1]);
E=reshape(ci95,[pix_rows,1]);

% Calculate geographic coordinates for centre pixel and square
x11=ifghdr.xfirst;
y11=ifghdr.yfirst;
dx=ifghdr.xstep;
dy=ifghdr.ystep;
R=makerefmat(x11, y11, dx, dy);

%centre pixel coordinates
[cen_lat,cen_lon]=pix2latlon(R,irow,icol);

%square corner coordinates
[ul_lat,ul_lon]=pix2latlon(R,irow_min,icol_min);
[ur_lat,ur_lon]=pix2latlon(R,irow_min,icol_max);
[lr_lat,lr_lon]=pix2latlon(R,irow_max,icol_max);
[ll_lat,ll_lon]=pix2latlon(R,irow_max,icol_min);

% Create text file with pixel values and coordinates (for plotting in GMT)
val_pix_title='Values to select in Matlab to replicate results (col, row, grid_size):';
val_pix=horzcat(num2str(icol),',',num2str(irow),',',num2str(grid_size));
cen_coord_title='Centre Pixel Coordinates (X,Y):';
cen_coord=horzcat(num2str(cen_lon),',',num2str(cen_lat));
sq_pix_title='Square Pixel Values (col,row):';
sq_pix_ul=horzcat('UL:',' ',num2str(icol_min),',',num2str(irow_min));
sq_pix_ur=horzcat('UR:',' ',num2str(icol_min),',',num2str(irow_max));
sq_pix_lr=horzcat('LR:',' ',num2str(icol_max),',',num2str(irow_max));
sq_pix_ll=horzcat('LL:',' ',num2str(icol_max),',',num2str(irow_min));
sq_coord_title='Square Pixel Coordinates (X,Y):';
sq_coord_ul=horzcat('UL:',' ',num2str(ul_lon),',',num2str(ul_lat));
sq_coord_ur=horzcat('UR:',' ',num2str(ur_lon),',',num2str(ur_lat));
sq_coord_lr=horzcat('LR:',' ',num2str(lr_lon),',',num2str(lr_lat));
sq_coord_ll=horzcat('LL:',' ',num2str(ll_lon),',',num2str(ll_lat));
year=epochlist.span(2:nts+1);
h1='Year';
h2='Pixel_Mean';
h3='Error';

fid=fopen(char(strcat('pixel_avg_values_',(num2str(grid_size)),'_',(num2str(icol)),'c',(num2str(irow)),'r.txt')),'w');
fprintf(fid, [val_pix_title '\n']);
fprintf(fid, [val_pix '\n']);
fprintf(fid, [cen_coord_title '\n']);
fprintf(fid, [cen_coord '\n']);
fprintf(fid, [sq_pix_title '\n']);
fprintf(fid, [sq_pix_ul '\n']);
fprintf(fid, [sq_pix_ur '\n']);
fprintf(fid, [sq_pix_lr '\n']);
fprintf(fid, [sq_pix_ll '\n']);
fprintf(fid, [sq_coord_title '\n']);
fprintf(fid, [sq_coord_ul '\n']);
fprintf(fid, [sq_coord_ur '\n']);
fprintf(fid, [sq_coord_lr '\n']);
fprintf(fid, [sq_coord_ll '\n']);
fprintf(fid,'%f \n','');
fprintf(fid, [ h1 ' ' h2 ' ' h3 '\n']);
fprintf(fid, '%f %f %f \n', [year M2 E]');
fclose(fid);

% Plot graph results in Matlab
figure
npt=length(M);
for i=1:npt
  data1=M(i);
  date=year(i);
  error=S(i);
  plot(date,data1,'-bo','LineWidth',1,'MarkerEdgeColor','r','MarkerFaceColor','g','MarkerSize',6);
  hold on
  errorbar(date,data1,error,'-bo','LineWidth',1);
end
axis square
grid on

hold off





