function bp_coef=caldemcoef(unwrscfile,bsrscfile,obsdir)
%==================================================================
% function caldemcoef(unwrscfile,bsrscfile,obsdir)
%
% calculate coefficient for the conversion from height to phase
%
% INPUT:
%   unwrscfile:  rsc file for unwrapped phase in radar coordinate
%   bsrscfile:   baseline rsc file
%   obsdir:      observation file directory (optional)
%
% OUTPUT:
%   NONE                                           
%
% Hua Wang @ Uni Leeds, 18/08/2009
%==================================================================
surfix = strfind(unwrscfile,'.');
outfile=unwrscfile(1:surfix(1)-1);
bpfile=strcat(outfile,'.basep');  %rmg format

if nargin>2
 bpfile=strcat(obsdir,bpfile);
 unwrscfile=strcat(obsdir,unwrscfile);
 bsrscfile=strcat(obsdir,bsrscfile);
end

[unwparmat]=readparfile(unwrscfile);
width    =getpar('WIDTH',unwparmat,'n');
nlines   =getpar('FILE_LENGTH',unwparmat,'n');
da       =getpar('AZIMUTH_PIXEL_SIZE',unwparmat,'n');
dr       =getpar('RANGE_PIXEL_SIZE',unwparmat,'n');
alks     =getpar('ALOOKS',unwparmat,'n');
rlks     =getpar('RLOOKS',unwparmat,'n');
rho0     =getpar('STARTING_RANGE1',unwparmat,'n');
r        =getpar('EARTH_RADIUS',unwparmat,'n');
h0       =getpar('HEIGHT',unwparmat,'n');
hdot     =getpar('HEIGHT_DS',unwparmat,'n');
hddt     =getpar('HEIGHT_DDS',unwparmat,'n');
ref_line =getpar('SLC_RELATIVE_YMIN',unwparmat,'n');
orb      =getpar('BASELINE_SRC',unwparmat,'s');
clear unwparmat;

[bsparmat]=readparfile(bsrscfile);
baseh=getpar(strcat('H_BASELINE_TOP_',orb),bsparmat,'n');
dbh  =getpar(strcat('H_BASELINE_RATE_',orb),bsparmat,'n');
ddbh =getpar(strcat('H_BASELINE_ACC_',orb),bsparmat,'n');
basev=getpar(strcat('V_BASELINE_TOP_',orb),bsparmat,'n');
dbv  =getpar(strcat('V_BASELINE_RATE_',orb),bsparmat,'n');
ddbv =getpar(strcat('V_BASELINE_ACC_',orb),bsparmat,'n');

clear bsparmat;

dasl=da/alks;
dr0=ref_line*dasl;

bp_coef=zeros(nlines,width,2);
one = ones(1,width);

for i=1:nlines
  r_so=dr0+(i-1)*da;
  r_disscale=1+h0/r;
  r_sg=r_so/r_disscale;
  h=(hddt*r_sg+hdot)*r_sg+h0;                   %platform height
                                                
  rho =rho0*one+dr*(0:width-1);                 %range for each pixel across the image
  hpr = (h+r)*one;                              %earth radius + platform height
  rr  = (r*r)*one;                              %earth radius * earth radius
  rhorh = rho*(h+r);                            %range * (earth radius + platform height)
                                                
  cosl=(hpr.*hpr+rho.*rho-rr)./(2*rhorh);       %cosine line-of-sight angle
  sinl=sqrt(one-cosl.*cosl);                    %sine line-of-sight angle
                                                
  bh = baseh + (dbh + ddbh*r_so)*r_so;          %horizontal baseline
  bv = basev + (dbv + ddbv*r_so)*r_so;          %vertical baseline
                                                
  bp_coef(i,:,1) = -bh*cosl+bv*sinl;            %perpendicular baseline
  bp_coef(i,:,2)=-bp_coef(i,:,1)./(rho.*sinl);  %coefficient for dem errors: -Bp/(rho*sin(theta));
end

multibandwrite(single(bp_coef),bpfile,'bil');
