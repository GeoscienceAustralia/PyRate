function [filtout,filthdr] = filt_gamma

name='20070103-20070218_HH_4rlks';
filt_name=strcat(name,'_filt_int_utm.flt');
fill_name=strcat(name,'_filt_int_utm.flt');
dat_name=strcat(name,'_filt_int_utm.dat');

%dem parameters (from *_utm.dem.par)
filthdr.width  = 14116;
filthdr.length = 16972;
filthdr.xfirst = 150.4405556; 
filthdr.xstep  = 0.000069444445;
filthdr.yfirst = -26.4391667;
filthdr.ystep  = -0.000069444445;

filthdr.xlast  = filthdr.xfirst + (filthdr.width-1)*filthdr.xstep;
filthdr.ylast  = filthdr.yfirst + (filthdr.length-1)*filthdr.ystep;
xlast=filthdr.xfirst+(filthdr.width-1)*filthdr.xstep;
ylast=filthdr.yfirst+(filthdr.length-1)*filthdr.ystep;


%calculate approximate pixel size using utm projection
origin=[filthdr.xfirst;ylast];
llh=[xlast;filthdr.yfirst];
xy=llh2local(llh,origin);
filthdr.xpsize=abs(xy(1))/(filthdr.width-1);
filthdr.ypsize=abs(xy(2))/(filthdr.length-1);

fprintf('output data position: xfirst = %12.9f, yfirst = %12.9f, xlast = %12.9f, ylast = %12.9f\n',filthdr.xfirst,filthdr.yfirst,xlast,ylast);
fprintf('output data size: width = %5d, length = %5d \n',filthdr.width,filthdr.length);


%import filtered ifm

filtout=NaN(ifghdr.length,ifghdr.width,1,'single');

filtout(:,:,1)=readmat(fill_name,filthdr.length,filthdr.width,1,'real'); 
  





end







