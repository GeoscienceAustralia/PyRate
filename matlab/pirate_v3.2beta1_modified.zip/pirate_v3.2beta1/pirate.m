function [] = pirate(cfgfile)
%===========================================================
% Poly-Interferogram Rate And Timeseries Estimator (PIRATE)
%
% INPUT:
%   cfgfile: configure file name
%
% OUTPUT:
%   None
%
% Hua Wang @ Uni Leeds, 13/03/2008                        
%===========================================================

if nargin<1
  cfgfile='pirate.conf';
end

%-------------------------------------
% pre-processing
%-------------------------------------

%read configure file

fprintf('reading configure file ...\n');
[parmat] = readparfile(cfgfile);
my_outdir = getpar('outdir:',parmat,'s');       % so uncoupled from pwd
getpars_pirate(parmat);     % this will produce "strcat(my_outdir,'pars')"
load(strcat(my_outdir,'pars'))

%open logfile
%logfile = char(strcat(iopar.auxdir,'log'));
logfile = sprintf('%s%s%s', iopar.outdir, iopar.auxdir, 'log');     % '/' or '\' will be in variables
logfid = fopen(logfile,'w');    % ensure the directory is there...

%%% get interferogram list
fprintf('making ifg and epoch namelist ...\n');
[ifglist,epochlist] = getnml(iopar.ifgfilelist,iopar.ifgname_prefix_len,iopar.ifgname_date_format);

%%% read real input interferograms
if simpar.nsets==1
  fprintf('preparing ifgs ...\n');
  %Do unit conversion after closure check
  convflag=3;
 
  [ifg,ifghdr,cc] = prepifg_gamma(iopar.obsdir,ifglist.nml,parmat,convflag,iopar.ampflag,iopar.prjflag,iopar.ccflag);
  if iopar.ampflag==1
    %[ifg,ifghdr,amp] = prepifg_gamma(iopar.obsdir,ifglist.nml,parmat,convflag,iopar.ampflag,iopar.prjflag,iopar.ccflag);
    fprintf('amplitude calibration ...\n');
    calamp(amp,char(strcat(iopar.auxdir,'amp.dat')));
    clear amp;
  end
  if iopar.ccflag==1
    fprintf('coherence masking ...\n');
    % mask phase pixels whose coherence is less than threshold
    ifg(cc<ccthr)=NaN;
    % determine time to fall below threshold coherence for each pixel
    %[decor]=decor_time(cc,ifglist,2,ccthr);
    %save decor.mat decor
    %clear cc;
  end
  if iopar.unwflag==1
    %mask phase unwrapping errors by automatic closure check
    fprintf('closure check to remove phase unwrapping errors ...\n');
    [mloop] = mst_closure(ifglist,epochlist,0);
    [ifg] = sum_closure(mloop,epochlist,ifg,0,1);
    clear mloop;
  end
  %
  if iopar.wvl~=0
      fprintf('unit conversion from rad to mm ...\n');
  nifgs=size(ifg,3);
  for i=1:nifgs
    %[rscmat] = readparfile(char(strcat(iopar.obsdir,ifglist.nml(i),'.rsc')));
    %wvl=getpar('WAVELENGTH',rscmat,'n');
    ifg(:,:,i)=(ifg(:,:,i)*iopar.wvl*1000)/(4*pi);
  end
  else
      fprintf('units are radians ...\n')
  end
end

%baseline files
if iopar.basepflag==1
  fprintf('preparing perpendicular baselines ...\n');
  [basepnml]=getextnml(ifglist.nml);
  [cbasep,ifghdr] = prepifg(iopar.obsdir,basepnml,parmat,3);
  cbasep=cbasep.*1000; % output height unit: metre
else
  cbasep=[];
end

%%% read dem data only if it will be used %%%%
if atmfit==1 || shpdemest==1 || inimodelpar.nmodels>0
  fprintf('reading dem ...\n');
  [dem]=imagecrop_gamma(iopar.demfile,ifghdr,2);
  dem(dem<-1000)=NaN;
  dem=inpaint_nans(double(dem),2);
else
  dem=[];
end

%%% read coseismic model files and produce corrections for spanning interferograms %%%
if iopar.eqflag==1
  fprintf('removing external coseismic models ...\n');
  [eqcor]=eq_correct(ifglist,epochlist,ifghdr,iopar);
  ifg=ifg+eqcor;
  clear eqcor;
end

%%% read external atm delays and produce interferogram corrections %%%
if iopar.external_delay==1
    fprintf('creating ifm corrections from external atmospheric delays ...\n');
    if ~exist('delay.mat','file')
        [delay] = external_delay(ifglist,iopar.delaydir,iopar.delayfilelist,ifghdr,wvl);
        save delay.mat delay;
    else
        load delay.mat
    end
    ifg=ifg+delay;
    clear delay;
end

%%% read external modatm delays and produce interferogram corrections %%%
if iopar.psflag==1
  fprintf('removing postseismic model ...\n');
  [psmodel] = postseismic(ifglist,iopar.psdir,iopar.psfilelist,ifghdr);
  ifg=ifg-psmodel;
  clear psmodel;
end

%%% make initial models
if inimodelpar.nmodels>0
  fprintf('reading initial models ...\n');
  for i=1:inimodelpar.nmodels
    [inimodelpar.fmodel(:,:,i)]=imagecrop(char(inimodelpar.fmodelfile(i)),ifghdr,1);
  end
  save('pars.mat','inimodelpar','-append')
  inirate=inimodelpar.rate;
end

%-------------------------------------
% iterative estimation of rate map
%-------------------------------------
for set=1:simpar.nsets

  %%% read the synthetic data here
  if (simpar.nsets>1)
    fprintf('\nreading synthetic dataset: %03d \n',set);
    setdir = strcat(simpar.simdir,'set_',num2str(set,'%03d'),'/');
    [ifg]=readifgs(setdir,ifglist.nml,ifghdr.length,ifghdr.width,0);
  end

  if set==1
    %% make mst matrix for the following analysis
    ifglist.nanfrac=ifgnanfrac(ifg);
    %mstmatfile=char(strcat(iopar.auxdir,'mstmat.mat'));
    mstmatfile = sprintf('%s%s%s', iopar.outdir, iopar.auxdir, 'mstmat.mat');
    if exist(mstmatfile,'file')
      ifghdrfile=char(strcat(iopar.obsdir,'ifg.rsc'));
      dirmst=dir(mstmatfile);
      dirhdr=dir(ifghdrfile);
      dirlist=dir(iopar.ifgfilelist);
      date_diff1=datenum(dirmst.date)-datenum(dirhdr.date);
      date_diff2=datenum(dirmst.date)-datenum(dirlist.date);
      if date_diff1>0 && date_diff2>0
        disp('loading mst matrix...');
        load(mstmatfile)
      end
    end
    % mstmat file does not exist, or it has different size from ifg
    if exist('mstmat','var')==0 || nnz(size(mstmat)~=size(ifg))>0
      disp('making mst matrix...');
      [mstmat]=make_mstmat(ifg,ifglist,1);
      save(mstmatfile,'mstmat');
    end

    % find the reference pixel coordinates, run this step only once for each set
    if (refpt.x==0 && refpt.y==0)
      [refpt]=refpix(ifg,refpar);
    end
    pars_loc = sprintf('%s%s', iopar.outdir, 'pars.mat');
    %save('pars.mat','refpt','-append')
    save(pars_loc,'refpt','-append')
  end

  for i=1:inimodelpar.nmodels
    inimodelpar.rate(i)=inirate(i);
    fprintf('initial model slip rate %d: %-6.2f \n',i,inimodelpar.rate(i));
  end

  delta=9999;                           %initial slip rate changes
  iter=1;                               %initial iterative number

  while (delta>itepar.tol && iter<itepar.maxiter)
    fprintf('loop: %-3d \n',iter);
    fprintf(logfid,'loop: %-3d \n',iter);

    %% everything is done by loop
    [fitmodelpar,ifglist,outdata]=loop(ifg,ifghdr,ifglist,epochlist,dem,mstmat,cbasep,iopar.outdir);

    %think about changes of stack map here???
    if inimodelpar.nmodels>1
      delta=fitmodelpar.rate-inimodelpar.rate;
      delta=sqrt(delta'*delta);
      inimodelpar.rate = fitmodelpar.rate;
      save('pars.mat','inimodelpar','-append')
      for i=1:inimodelpar.nmodels
        fprintf('fitted slip rate for model %d: %6.2f +- %-6.2f\n',i,fitmodelpar.rate(i),fitmodelpar.stds(i));
        fprintf(logfid,'fitted slip rate for model %d: %6.2f +- %-6.2f\n',i,fitmodelpar.rate(i),fitmodelpar.stds(i));
      end
      fprintf('fitted slip rate changes: %6.2f\n',delta);
    else
      delta=0;
    end

    iter=iter+1;
  end

  if iter>=itepar.maxiter
    fitmodelpar.rate=NaN(inimodelpar.nmodels,1);
  end

  if (simpar.nsets>1) && (inimodelpar.nmodels>0)
    sliprateset(:,set)=fitmodelpar.rate;
    for i=1:inimodelpar.nmodels
      fprintf('fitted slip rate for model %d using synthetic dataset %03d: %6.2f +- %-6.2f\n',i,set,fitmodelpar.rate(i),fitmodelpar.stds(i));
      fprintf(logfid,'fitted slip rate for model %d using synthetic dataset %03d: %6.2f +- %-6.2f\n',i,set,fitmodelpar.rate(i),fitmodelpar.stds(i));
    end
  end
end

clear('ifg','cbasep');
%-----------------------------
% output
%-----------------------------

% write fitted model parameters for simulated data
if (simpar.nsets>1) && (inimodelpar.nmodels>0)
  sliprateset(:,isnan(sliprateset(1,:)))=[]; %delete non-convergent solutions
  fitmodelpar.rate = mean(sliprateset');
  fitmodelpar.stds = std(sliprateset');

  fprintf('final convergent number is: %4d \n',size(sliprateset,2));

  for i=1:inimodelpar.nmodels
    fprintf('final slip rate for model %d: %6.2f +- %-6.2f\n',i,fitmodelpar.rate(i),fitmodelpar.stds(i));
    fprintf(logfid,'final slip rate for model %d: %6.2f +- %-6.2f\n',i,fitmodelpar.rate(i),fitmodelpar.stds(i));
  end
end

%{
% write the output binary files for real data
if simpar.nsets==1
  output(outdata,ifghdr,ifglist,epochlist,fitmodelpar,gmtfaultfile);
end
%}

fclose(logfid);
%remove pars.mat
%!rm -f pars.mat

% this used for testing matlab matrices imported into python correctly
test3dmat = [1,2,3;4,5,6];
test3dmat(:,:,2) = [7,8,9;10,11,12];
test3dmat(:,:,3) = [13,14,15;16,17,18];
test3dmat(:,:,4) = [19,20,21;22,23,24];
save(strcat(iopar.outdir, 'test3dmat.mat'), 'test3dmat');

% majority of outdata stored here
save(strcat(iopar.outdir, 'out_mt.mat'), '-struct', 'outdata')
save(strcat(iopar.outdir, 'refpt.mat'), 'refpt')

% don't want to do this. too messy
% decide if you want to write out tiffs
% 2d arrays
%grk_tiff_2d(outdata.stackmap, iopar, 'linrate_grk.tif');
%grk_tiff_2d(outdata.errormap, iopar, 'linerror_grk.tif');
% 3d arrays
%grk_tiff_3d(outdata.tsincr, iopar, 'tsincr_', epochlist.date);
%grk_tiff_3d(outdata.tsvel, iopar, 'tsvel_', epochlist.date);
%grk_tiff_3d(outdata.tscum, iopar, 'tscuml_', epochlist.date);
% Sudipta doesn't print out tserr

display('finished...')
