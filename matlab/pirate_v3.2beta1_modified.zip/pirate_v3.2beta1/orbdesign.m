function [B]=orbdesign(ifglist,orbfitpar,ifghdr,refpt)
%==================================================================== 
%function [B]=orbdesign(ifglist,orbfitpar,ifghdr,refpt)
%                                                                     
% Make design matrix for orbit correction, both ifg-by-ifg    
%  and epoch-by-epoch methods are supported              
%                                                                     
% INPUT:                                                              
%   ifglist:   master/slave image list for each interferogram       
%   orbfitpar: structure of orbit fitting parameters including
%              degree - degree of the polynomial for fitting orbital error   
%              method - orbital/atm errors fitting method                
%                       1: ifg-by-ifg method; 2: epoch-by-epoch method       
%   ifghdr:    ifg header
%   refpt:     coordinate of the reference point                    
%                                                                     
% OUTPUT:                                                             
%   B:         design matrix for orbital errors                     
%                                                                     
% Hua Wang @ Uni Leeds, 02/02/2008, following Juliet Biggs, 2006          
%
% 22/10/2011 HW: add back reference phase offset estimation
% 05/08/2011 HW: change input as structure
% 13/09/2009 HW: change reference phase offset as an optional parameter
%==================================================================== 

nifgs=size(ifglist.masnum,1);

%cofficients number for each epoch
%degree=1: x, y
%degree=2: x^2, y^2, xy, x, y
ncoef = (orbfitpar.degree+1)*(orbfitpar.degree+2)/2-1;

%epoch number
nepoch = max(max([ifglist.masnum ifglist.slvnum]));

%total parameters number (epoch parameters + offsets)
if orbfitpar.method==2
  npolypar = nepoch*ncoef; %epoch-by-epoch method
else
  npolypar = nifgs*ncoef;  %ifg by ifg method
end

npar=npolypar;
npar = npar + nifgs;

%make grid (x,y coordinates)
n=ifghdr.length*ifghdr.width;
[yy,xx]=meshgrid(1:ifghdr.length,1:ifghdr.width);
xxv=reshape(xx,n,1);
yyv=reshape(yy,n,1);
%subtract the reference coordinates
%xxv = (xxv-refpt.x)*ifghdr.xpsize/100.0;  %using 100km as unit, test 30/09/2009
%yyv = (yyv-refpt.y)*ifghdr.ypsize/100.0;  %using 100km as unit, test 30/09/2009
xxv = xxv*ifghdr.xpsize/100; %MG mod for pyrate testing 16/6/2014
yyv = yyv*ifghdr.ypsize/100;
clear('xx','yy');

B = zeros(n*nifgs,npar);
for i=1:nifgs
  %start/end line number for each interferogram in the coefficient matrix
  ib1 = (i-1)*n+1;
  ib2 = i*n;

  %epoch-by-epoch method design matrix
  if orbfitpar.method==2
    %master/slave image epoch, using it to determine the cofficient position
    im = ifglist.masnum(i);
    is = ifglist.slvnum(i);
    %coefficients for the master/slave image
    jbm=(im-1)*ncoef+1;
    jbs=(is-1)*ncoef+1;
    if orbfitpar.degree==1
      B(ib1:ib2,jbm:jbm+ncoef-1)=[-xxv -yyv];
      B(ib1:ib2,jbs:jbs+ncoef-1)=[ xxv  yyv];
    else                    %degree == 2
      xxv2 = xxv.*xxv;
      yyv2 = yyv.*yyv;
      xyv  = xxv.*yyv;
      B(ib1:ib2,jbm:jbm+ncoef-1)=[-xxv2 -yyv2 -xyv -xxv -yyv];
      B(ib1:ib2,jbs:jbs+ncoef-1)=[ xxv2  yyv2  xyv  xxv  yyv];
    end
  disp('MUST BE HERE with method==2')
  %ifg-by-ifg method design matrix
  else  % orbfitmethod method == 1
    jb1 = (i-1)*ncoef+1;
    jb2 = i*ncoef;
    if orbfitpar.degree==1
      B(ib1:ib2,jb1:jb2)=[xxv yyv];
    else                    %degree == 2
      xxv2 = xxv.*xxv;
      yyv2 = yyv.*yyv;
      xyv  = xxv.*yyv;
      B(ib1:ib2,jb1:jb2)=[xxv2 yyv2 xyv xxv yyv];
    end
  end

  %coefficients for the offsets, revised on 22/10/2011
  joff = npolypar+i;
  B(ib1:ib2,joff)=ones(n,1);
end
