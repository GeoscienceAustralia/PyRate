function[ifg_lowres]=looks_para(ifg,lksx,lksy)
%====================================================================
%function[ifg_lowres]=looks(ifg,lksx,lksy)
%                                                                    
% Multi-look for an input interferogram                     
%                                                                    
% INPUT:                                                             
%   ifg:  input interferogram                                        
%   lksx: looks number for x-component                               
%   lksy: looks number for y-component                               
% OUTPUT:                                                            
%   ifg_lowres: multi-looked interferogram                           
%                                                                    
% Hua Wang @ Uni Leeds, 04/03/2008                                       
%                                                                    
% NOTE: threshold of valid pixels is set as half of the totle number 
%       in the window                                                
%
% 27/04/2011 HW: set ifg_lowres as 'single' to save space
% 11/01/2011 HW: fix a bug while zeros are not NaNs
%====================================================================
if (lksx==1 && lksy==1)
  ifg_lowres=ifg;
else
  [rows,cols]=size(ifg);
  rows_lowres=floor(rows/lksy);
  cols_lowres=floor(cols/lksx);
  ifg_lowres=NaN(rows_lowres,cols_lowres,'single');

  %threshold of valid pixels is set as half of the totle number in the window
  psize=lksx*lksy;
  thr = floor(psize/2);
  %thr=psize;

  for r=1:rows_lowres
    for c=1:cols_lowres
      patch=ifg((r-1)*lksy+1:r*lksy,(c-1)*lksx+1:c*lksx);
      pv=reshape(patch,psize,1);
      n=sum(~isnan(pv));
      if n>=thr
        ifg_lowres(r,c)=nanmean(pv);
      end
    end
  end
end
