function grk_tiff_3d(outdata, iopar, f_name, date)
% tiffs for 2d data (linrate, error)
% rows, cols, epoch
[m, n, o] = size(outdata);

disp(m)
disp(n)
disp(o)

%disp(outdata(:,:,1))

for idx_o = 1:o
    R = zeros(m, n, 'uint8');
    B = zeros(m, n, 'uint8');
    G = zeros(m, n, 'uint8');

    % get max pixel value
    M_pix = max(max(abs(outdata(:,:,idx_o))));    % this must ignore NaNs. unlike python :@
    %disp(M_pix);

    for idx_m = 1:m
        for idx_n = 1:n
            if isnan(outdata(idx_m, idx_n, idx_o))
                % LIME
                R(idx_m, idx_n) = uint8(0);
                G(idx_m, idx_n) = uint8(127);
                B(idx_m, idx_n) = uint8(0);
            elseif outdata(idx_m, idx_n, idx_o) == 0
                % BLACK
                R(idx_m, idx_n) = uint8(0);
                B(idx_m, idx_n) = uint8(0);
                G(idx_m, idx_n) = uint8(0);
            elseif outdata(idx_m, idx_n, idx_o) < 0
                R(idx_m, idx_n) = uint8(0);
                B(idx_m, idx_n) = uint8((abs(outdata(idx_m, idx_n, idx_o))/M_pix)*255);
                G(idx_m, idx_n) = uint8(0);
            else
                R(idx_m, idx_n) = uint8((abs(outdata(idx_m, idx_n, idx_o))/M_pix)*255);
                B(idx_m, idx_n) = uint8(0);
                G(idx_m, idx_n) = uint8(0);
            end
        end
    end

    RGB_img = R;
    RGB_img(:,:,2) = G;
    RGB_img(:,:,3) = B;

    date_str = sprintf('%d', date(idx_o+1,1));   % don't want master date
    date_app = sprintf('%s-%s-%s', date_str(1:4), date_str(5:6), date_str(7:8));
    imw_2nd_par = sprintf('%s%s%s%s', iopar.outdir, f_name, date_app, '_grk.tif');
    imwrite(RGB_img, imw_2nd_par);
end

%{

    R = zeros(m, n, 'uint8');
    B = zeros(m, n, 'uint8');
    G = zeros(m, n, 'uint8');

    % get max pixel value
    M_pix = max(max(abs(outdata)));    % this must ignore NaNs. unlike python :@
    %disp(M_pix);

    for idx_m = 1:m
        for idx_n = 1:n
            if isnan(outdata(idx_m, idx_n))
                % LIME
                R(idx_m, idx_n) = uint8(0);
                G(idx_m, idx_n) = uint8(127);
                B(idx_m, idx_n) = uint8(0);
            elseif outdata(idx_m, idx_n) == 0
                % BLACK
                R(idx_m, idx_n) = uint8(0);
                B(idx_m, idx_n) = uint8(0);
                G(idx_m, idx_n) = uint8(0);
            elseif outdata(idx_m, idx_n) < 0
                R(idx_m, idx_n) = uint8(0);
                B(idx_m, idx_n) = uint8((abs(outdata(idx_m, idx_n))/M_pix)*255);
                G(idx_m, idx_n) = uint8(0);
            else
                R(idx_m, idx_n) = uint8((abs(outdata(idx_m, idx_n))/M_pix)*255);
                B(idx_m, idx_n) = uint8(0);
                G(idx_m, idx_n) = uint8(0);
            end
        end
    end

    RGB_img = R;
    RGB_img(:,:,2) = G;
    RGB_img(:,:,3) = B;

    imwrite(RGB_img, strcat(iopar.outdir, f_name));

%}