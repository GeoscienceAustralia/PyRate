function [] = getpars(parmat)
%======================================================
%function [] = getpars(parmat)
%
% Get all parameters from a two-column matrix 
%                                                      
% INPUT:                                               
%   parmat:  matrix which holds the parameters         
% OUTPUT:                                              
%   None                            
%                                                      
% Hua Wang @ Uni Leeds, 06/02/2009                         
%
% 09/03/2012 HW; fix a bug for default number (getpar)
% 26/08/2009 HW: save structures on harddisk
%======================================================

%------------------------------------
%% input/output parameters
%------------------------------------
%iopar=struct('obsdir',{'obs'},'demfile',{'dem'},'ifgfilelist',{'ifg.list'},'outdir',{'out'},'basepflag',{1});
root=pwd;
iopar.obsdir = getpar('obsdir:',parmat,'s',strcat(root,'/obs/'));
ifgfilelist = getpar('ifgfilelist:',parmat,'s','ifg.list');
iopar.ifgfilelist = strcat(iopar.obsdir,ifgfilelist);
%insar processor flag roipac/gamma added on 27/08/2012
iopar.ifgname_prefix_len = getpar('ifgname_prefix_len:',parmat,'n',4);
iopar.parfile = getpar('parfile:',parmat,'s','');
iopar.wvl = getpar('wavelength:',parmat,'n','0');
iopar.ifgname_date_format = getpar('ifgname_date_format:',parmat,'n',6);

iopar.external_delay = getpar('external_delay:',parmat,'n',0);
if iopar.external_delay==1
    iopar.delaydir = getpar('delaydir:',parmat,'s',strcat(root,'/delay/'));
    delayfilelist = getpar('delayfilelist:',parmat,'s','delay.list');
    iopar.delayfilelist = strcat(iopar.delaydir,delayfilelist);
end

iopar.psflag = getpar('psflag:',parmat,'n',0);
if iopar.psflag==1
    iopar.psdir = getpar('psdir:',parmat,'s',strcat(root,'/postseismic/'));
    psfilelist = getpar('psfilelist:',parmat,'s','postseismic.list');
    iopar.psfilelist = strcat(iopar.psdir,psfilelist);
end

iopar.demfile = getpar('demfile:',parmat,'s');
iopar.outdir = getpar('outdir:',parmat,'s',strcat(root,'/out/'));
if ~exist(char(iopar.outdir),'dir')
  %mkdir(char(iopar.outdir));
end
iopar.auxdir = getpar('auxdir:',parmat,'s');
if ~exist(char(iopar.auxdir),'dir')
  %mkdir(char(iopar.auxdir));
end
iopar.ratemapdir = getpar('ratedir:',parmat,'s');
if ~exist(char(iopar.ratemapdir),'dir')
  %mkdir(char(iopar.ratemapdir));
end

%perpendicular baseline flag, added on 04/12/09
iopar.basepflag = getpar('basepflag:',parmat,'n',1);

%amplitude image, added on 22/10/2011
iopar.ampflag = getpar('ampflag:',parmat,'n',0);

%projection to hv, added on 06/01/2012
iopar.prjflag = getpar('prjflag:',parmat,'n',3);

% closure check and mask unwrapping errors flag added on 17/09/2012
iopar.unwflag = getpar('unwflag:',parmat,'n',1);

% coherence image, added by MG on 05/08/2015
iopar.ccflag = getpar('ccflag:',parmat,'n',0);

% coherence threshold for interferogram pixel masking, added by MG on 5/8/2015
ccthr = getpar('ccthr:',parmat,'n',0.3);

% coherence threshold for interferogram pixel masking, added by SL on 2/10/2015
iopar.ccdecor = getpar('decor:',parmat,'n',0);

%coseismic model flag added on 13/09/2012
iopar.eqflag = getpar('eqflag:',parmat,'n',0);
if iopar.eqflag==1 || iopar.eqflag==2
    iopar.eqdir = getpar('eqdir:',parmat,'s');
    eqfilelist = getpar('eqfilelist:',parmat,'s');
    iopar.eqfilelist = strcat(iopar.eqdir,eqfilelist);
end
%------------------------------------
%% simulation parameters
%------------------------------------
% nsets: number of sets of data (multiple sets required for Monte Carlo error estimates)
simpar.nsets = getpar('nsets:',parmat,'n',1);
if simpar.nsets==1
  simpar.simdir = getpar('simdir:',parmat,'s',strcat(root,'/sets/'));
end

%------------------------------------
%% model parameters
%------------------------------------
inimodelpar.nmodels = getpar('nmodels:',parmat,'n',0);
for i=1:inimodelpar.nmodels
  kwd=strcat('inisliprate_m',num2str(i),':');
  inimodelpar.rate(i,1) = getpar(kwd,parmat,'n');
  kwd=strcat('fmodelfile_m',num2str(i),':');
  inimodelpar.fmodelfile(i) = cellstr(getpar(kwd,parmat,'s'));
end

%------------------------------------
%% reference point options
%------------------------------------
% refx/y: coordinates of reference points
% refest: reference phase estimation method
%   (default 1: average of the whole image; 2: average of a patch around the refpt)
% refchipsize: chip size of the reference point window
% refminfrac: minimum fraction of coherence pixels
% refnx/y: number tie points in x/y direction
refpt.x = getpar('refx:',parmat,'n',0);
refpt.y = getpar('refy:',parmat,'n',0);
refpar.refest = getpar('refest:',parmat,'n',1);
refpar.chipsize = getpar('refchipsize:',parmat,'n',21);
refpar.minfrac  = getpar('refminfrac:',parmat,'n',0.8);
if refpt.x==0 && refpt.y==0
  refpar.nx = getpar('refnx:',parmat,'n',50);
  refpar.ny = getpar('refny:',parmat,'n',50);
end

%------------------------------------
%% dem errors estimation parameters
%------------------------------------
% shpdemest - spatial high-pass dem error estimation
if iopar.basepflag==0
  shpdemest=0;
else
  shpdemest = getpar('shpdemest:',parmat,'n',0);
end

%------------------------------------
%% orbital errors fitting parameters
%------------------------------------
% orbfit: 1-fit orbital errors; 0-not
% orbfitmethod = 1: interferogram by interferogram; orbatmfitmethod = 2, epoch by epoch
% polynomial degrees for the orbital error fitting
%  degree = 1: planar; degree = 2, quadratic
orbfit = getpar('orbfit:',parmat,'n',1);
orbfitpar.method = getpar('orbfitmethod:',parmat,'n',2);
orbfitpar.degree = getpar('orbfitdegrees:',parmat,'n',1);
orbfitpar.lksx = getpar('orbfitlksx:',parmat,'n',10);
orbfitpar.lksy = getpar('orbfitlksy:',parmat,'n',10);
%orbfitpar.maskflag = getpar('orbmaskflag:',parmat,'n',0);

%------------------------------------
%% atmospheric delay errors fitting parameters
%------------------------------------
% atmfit: 1-fit topo-correlated atm errors; 0-not
% atmfitmethod = 1: interferogram by interferogram; atmfitmethod = 2, epoch by epoch
% polynomial degrees for the atm error fitting
atmfit = getpar('atmfit:',parmat,'n',1);
atmfitpar.method = getpar('atmfitmethod:',parmat,'n',2);
atmfitpar.lksx = getpar('atmfitlksx:',parmat,'n',10);
atmfitpar.lksy = getpar('atmfitlksy:',parmat,'n',10);
%atmfitpar.maskflag = getpar('atmmaskflag:',parmat,'n',0);

%------------------------------------
%% vcm estimation parameters
%------------------------------------
% vcmtmethod = 1: general method; 2: network estimation for vcm_t;
% vcmsmethod = 1: general method; 2: sparse matrix for the first line; 3: sparse matrix for vcm_s;
% vcmslksx/y: the same looks also used for slip rate estimation
vcmpar.vcmtmethod = getpar('vcmtmethod:',parmat,'n',1);
vcmpar.vcmsmethod = getpar('vcmsmethod:',parmat,'n',2);
vcmpar.lksx = getpar('vcmslksx:',parmat,'n',10);
vcmpar.lksy = getpar('vcmslksy:',parmat,'n',10);

%------------------------------------
% APS parameters
%------------------------------------
%apsest: (1: APS estimation; 0: not)
apsest = getpar('apsest:',parmat,'n',0);

%------------------------------------
%earthquake list file to step estimation
%------------------------------------
eqlistfile = getpar('eqlistfile:',parmat,'s',strcat(root,'/eq.list'));
if ~exist(eqlistfile,'file')
  eqlistfile=[];
end

%------------------------------------
%% stacking parameters
%------------------------------------
% nsig: for temporal low-pass filter (res/sigma < nsig)
% pthr: for temporal low-pass filter (npixel >= pthr)
% maxsig: maximum std of rate
stackpar.nsig = getpar('nsig:',parmat,'n',2);
stackpar.pthr = getpar('pthr:',parmat,'n',10);
stackpar.maxsig = getpar('maxsig:',parmat,'n',2);

%------------------------------------
%% abrupt displacement correlation parameters
%------------------------------------
% fact: n times of the atm wavelenght (default: 1)
% step: correlation step (default: 3 pixels)
% slop: slop of the smoothing fuction (like locking depth,default: 20)
% thr: correlation threshold of smoothing function (default: 0.7)
if iopar.eqflag==2
  corrpar.fact = getpar('corrfact:',parmat,'n',1);
  corrpar.step = getpar('corrstep:',parmat,'n',3);
  corrpar.slop = getpar('corrslop:',parmat,'n',20);
  corrpar.thr = getpar('corrthr:',parmat,'n',0.7);
end

%------------------------------------
%% temporal high-pass filter parameters
%------------------------------------
%thpfparmethod: 1-Gaussian 2-Triangular 3-Mean filter
%thpfcutoff: cutoff t0 for gaussian filter in year
%thpfpthr: valid pixel threshold
thpfpar.method = getpar('thpfmethod:',parmat,'n',1);
thpfpar.cutoff = getpar('thpfcutoff:',parmat,'n',4);
thpfpar.pthr = stackpar.pthr;

%------------------------------------
%% spatially correlated noise low-pass filter parameters
%------------------------------------
%slpfmethod: filter method (1: butterworth; 2: gaussian)
%slpfcutoff: cutoff d0 for both butterworth and gaussian filters in the same unit with pixel size
%slpforder: order n for butterworth filter (default 1)
slpfpar.method = getpar('slpfmethod:',parmat,'n',1);
slpfpar.cutoff = getpar('slpfcutoff:',parmat,'n',0);
if slpfpar.method==1
  slpfpar.order = getpar('slpforder:',parmat,'n',1);
end

%------------------------------------
% time series parameters
%------------------------------------
% tscal: time series calculation (1: ts calculation; 0: no)
% tsmethod: time series method (1: Laplacian smoothing, 2: SVD)
% smorder: order of smoothing operator(1: first-order difference; 2: second-order difference)
% smfactor: smoothing factor(0: calculate & plot L-curve; others: smoothing factor (10^(smf))
% smf_min/max/int: region of smoothing factors for L-curve calculation, the exact region will be calculated by 10^(smf)
% lcurve_lksx/lksy: looks number for L-curve calculation
% pthr: pixel number threshold for time series inversion
% stepest: estimate step in ts analysis
tspar.tscal = getpar('tscal:',parmat,'n',0);
if tspar.tscal==1
  iopar.tsdir=getpar('tsdir:',parmat,'s');
  if ~exist(iopar.tsdir,'dir')
    %mkdir(iopar.tsdir);
  end
end
if tspar.tscal==1 | apsest==1
  tspar.method = getpar('tsmethod:',parmat,'n',1);
  if tspar.method~=2 %the following parameters for Laplacian smoothing
    tspar.smorder = getpar('smorder:',parmat,'n',2);
    tspar.smf = getpar('smfactor:',parmat,'n',0);
    if tspar.smf==0
      tspar.smf_min = getpar('smf_min:',parmat,'n');
      tspar.smf_max = getpar('smf_max:',parmat,'n');
      tspar.smf_int = getpar('smf_int:',parmat,'n');
      tspar.lcurv_lksx = getpar('lcurv_lksx:',parmat,'n',10);
      tspar.lcurv_lksy = getpar('lcurv_lksy:',parmat,'n',10);
    else
      tspar.smf=10^tspar.smf;
    end
    tspar.interp = getpar('ts_interp:',parmat,'n',0);
  end
  tspar.pthr = getpar('ts_pthr:', parmat,'n', 10);
  tspar.stepest = getpar('stepest:',parmat,'n',0);
end

%------------------------------------
%% profile parameters
%------------------------------------
profflag=getpar('make_prof:',parmat,'n',1);
if profflag==1
  iopar.profdir=getpar('profdir:',parmat,'s');
  if ~exist(iopar.profdir,'dir')
    %mkdir(iopar.profdir);
  end

  prof.swath = getpar('profswath:',parmat,'n',15);
  prof.step = getpar('profstep:',parmat,'n',1);
  prof.overlap = getpar('profoverlap:',parmat,'n',1);
  prof.conv = getpar('profconv:',parmat,'n',0);
  
  %% faults, usually used to extract profiles
  gmtfaultfile = getpar('gmtfaultfile:',parmat,'s');
else
  gmtfaultfile = '';
end

%------------------------------------
%iterative algorithm parameters
%------------------------------------
% tol=0.2;     %tolerance for the convergence
% maxiter=10;  %maximam iterative number
itepar.tol = getpar('tol:',parmat,'n',0.2);
itepar.maxiter = getpar('maxiter:',parmat,'n',10);

%------------------------------------
% save processing parametres
%------------------------------------
clear parmat;
save (strcat(iopar.outdir,'pars'));
